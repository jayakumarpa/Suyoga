import 'package:flutter/widgets.dart';
import 'package:Kissan/api_service.dart';
import 'package:Kissan/model/product.dart';

enum LoadMoreStatus { INITIAL, LOADING, STABLE }

class ProductProvider with ChangeNotifier {
  APIService _apiService;
  List<Product> _productList;
  SortBy _sortBy;
  int pageSize = 10;

  List<Product> get allProducts => _productList;
  double get totalRecords => _productList.length.toDouble();

  LoadMoreStatus _loadMoreStatus = LoadMoreStatus.STABLE;

  getLoadMoreStatus() => _loadMoreStatus;

  ProductProvider() {
    resetStreams();
    _sortBy = SortBy("modified", "Latest", "asc");
  }

  void resetStreams() {
    _apiService = APIService();
    _productList = List<Product>();
  }

  setLoadingStatus(LoadMoreStatus loadMoreStatus) {
    _loadMoreStatus = loadMoreStatus;
    notifyListeners();
  }

  setSortOrder(SortBy sortBy) {
    _sortBy = sortBy;
    notifyListeners();
  }

  fetchProduct(pageNumber,
      {String strSearch,
      String tagName,
      int categoryId,
      String sortBy,
      String sortOrder = "asc"}) async {
    List<Product> itemModel = await _apiService.getProduct(
        cId: categoryId,
        strSearch: strSearch,
        sortBy: this._sortBy.value,
        pageNumber: pageNumber,
        pageSize: this.pageSize,
        sortOrder: this._sortBy.sortOrder);

    if (itemModel.length > 0) {
      _productList.addAll(itemModel);
    }
    setLoadingStatus(LoadMoreStatus.STABLE);
  }
}

class SortBy {
  String value;
  String text;
  String sortOrder;

  SortBy(this.value, this.text, this.sortOrder);
}
