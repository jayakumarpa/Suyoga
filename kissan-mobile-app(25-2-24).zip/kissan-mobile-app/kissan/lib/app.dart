import 'package:Kissan/pages/Wallet_page.dart';
import 'package:Kissan/pages/cart_page.dart';
import 'package:Kissan/pages/loggin.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/components/loader_provider.dart';
import 'package:Kissan/pages/MyPaymentsScreen.dart';
import 'package:Kissan/pages/TimsSlot_Page.dart';
import 'package:Kissan/pages/Order_detailsPage.dart';

import 'package:Kissan/pages/product_page.dart';
import 'package:Kissan/pages/verify_address.dart';
import 'package:Kissan/provider/product_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'style.dart';
import 'pages/home.dart';

const LocationsRoute = '/';
const LocationDetailRoute = '/location_detail';
const CityRoute = '/city_detail';
const CategoryRoute = '/category_detail';
String loginMobNumber;

class App extends StatelessWidget {
  Future<String> logindata() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    loginMobNumber = prefs.getString("LoginMobNumber");
    print(loginMobNumber);
    return loginMobNumber;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: logindata(),
        builder: (context, AsyncSnapshot snapshot) {
          if (snapshot.data == null) {
            return home();
          }
          return multi();
        });
  }

  Widget home() {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (context) => ProductProvider(),
            child: ProductPage(),
          ),
          // ChangeNotifierProvider(
          //   create: (context) => LoaderProvider(),
          //   child: BasePage(),
          // ),
          //  ChangeNotifierProvider(
          //    create: (context) => CartProvider(),
          //   child: CartCounter(),
          //)
          ChangeNotifierProvider(
            create: (context) => CartProvider(),
            child: CartPage(),
          ),
          ChangeNotifierProvider(
            create: (context) => CartProvider(),
            child: VerifyAddress(),
          ),
          ChangeNotifierProvider(
            create: (context) => LoaderProvider(),
            child: CartPage(),
          ),
          ChangeNotifierProvider(
            create: (context) => LoaderProvider(),
            //walletpage
            child: WalletUIscreen(),
          ),
          ChangeNotifierProvider(
            create: (context) => CartProvider(),
            child: OrderDetails(),
          ),
          ChangeNotifierProvider(
            create: (context) => CartProvider(),
            child: Timeslots(),
          ),
          ChangeNotifierProvider(
            create: (context) => CartProvider(),
            child: Mypayments(),
          ),
        ],
        child: MaterialApp(
          theme: _theme(),
          home: Scaffold(
            body: LoginPage(),
          ),
          debugShowCheckedModeBanner: false,
        ));
  }

  // RouteFactory _routes() {
  //   return (settings) {
  //     final Map<String, dynamic> arguments = settings.arguments;
  //     Widget screen;
  //     switch (settings.name) {
  //       case LocationsRoute:
  //         screen = SplashScreen();
  //         break;
  //       case CityRoute:
  //         //screen = LocationDetail(arguments['id']);
  //         screen = CityList();
  //         break;
  //       case CategoryRoute:
  //         //screen = LocationDetail(arguments['id']);
  //         screen = LoginPage();
  //         break;
  //       default:
  //         return null;
  //     }
  //     return MaterialPageRoute(builder: (BuildContext context) => screen);
  //   };
  // }

  ThemeData _theme() {
    return ThemeData(
        appBarTheme: AppBarTheme(textTheme: TextTheme(subtitle1: AppBarTextStyle)),
        textTheme: TextTheme(
          subtitle1: TitleTextStyle,
          bodyText1: Body1TextStyle,
        ));
  }
}

Widget multi() {
  return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => ProductProvider(),
          child: ProductPage(),
        ),
        // ChangeNotifierProvider(
        //   create: (context) => LoaderProvider(),
        //   child: BasePage(),
        // ),
        //  ChangeNotifierProvider(
        //    create: (context) => CartProvider(),
        //   child: CartCounter(),
        //)
        ChangeNotifierProvider(
          create: (context) => CartProvider(),
          child: CartPage(),
        ),
        ChangeNotifierProvider(
          create: (context) => CartProvider(),
          child: VerifyAddress(),
        ),
        ChangeNotifierProvider(
          create: (context) => LoaderProvider(),
          child: CartPage(),
        ),
        ChangeNotifierProvider(
          create: (context) => LoaderProvider(),
          //walletpage
          child: WalletUIscreen(),
        ),
        ChangeNotifierProvider(
          create: (context) => CartProvider(),
          child: OrderDetails(),
        ),
        ChangeNotifierProvider(
          create: (context) => CartProvider(),
          child: Timeslots(),
        ),
        ChangeNotifierProvider(
          create: (context) => CartProvider(),
          child: Mypayments(),
        ),
      ],
      child: MaterialApp(
        theme: _theme(),
        home: Scaffold(
          body: HomePage(),
        ),
        debugShowCheckedModeBanner: false,
      ));
}

// RouteFactory _routes() {
//   return (settings) {
//     final Map<String, dynamic> arguments = settings.arguments;
//     Widget screen;
//     switch (settings.name) {
//       case LocationsRoute:
//         screen = SplashScreen();
//         break;
//       case CityRoute:
//         //screen = LocationDetail(arguments['id']);
//         screen = CityList();
//         break;
//       case CategoryRoute:
//         //screen = LocationDetail(arguments['id']);
//         screen = HomePage();

//         break;
//       default:
//         return null;
//     }
//     return MaterialPageRoute(builder: (BuildContext context) => screen);
//   };
// }

ThemeData _theme() {
  return ThemeData(
      appBarTheme: AppBarTheme(textTheme: TextTheme(subtitle1: AppBarTextStyle)),
      textTheme: TextTheme(
        subtitle1: TitleTextStyle,
        bodyText1: Body1TextStyle,
      ));
}
