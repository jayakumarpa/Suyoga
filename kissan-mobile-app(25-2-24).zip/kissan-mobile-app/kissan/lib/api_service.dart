import 'dart:convert';
import 'dart:io';

import 'package:Kissan/model/AddmoneyToWallet.dart';
import 'package:Kissan/model/AdduserAddressModel.dart';
import 'package:Kissan/model/CityList_Model.dart';
import 'package:Kissan/model/CityName_Model.dart';
import 'package:Kissan/model/FeedbackModel.dart';
import 'package:Kissan/model/Pincode_Validation_Model.dart';
import 'package:Kissan/model/UpdatePasswordModel.dart';
import 'package:Kissan/model/UseraddressModel.dart';
import 'package:Kissan/model/Vendor_AccountModel.dart';
import 'package:Kissan/model/WalletTransacDetailsModel.dart';
import 'package:Kissan/model/Walletbalance.dart';
import 'package:Kissan/model/WithdrawModel.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:Kissan/model/ForgotPassword_model.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/model/MyPayments_Model.dart';
import 'package:Kissan/model/Order_details_Model.dart';
import 'package:Kissan/model/PlaceOrder_model.dart';
import 'package:Kissan/model/TimeSlot_Model.dart';
import 'package:Kissan/model/Update_mobileNumber_model.dart';
import 'package:Kissan/model/User_Signup_Model.dart';
import 'config.dart';
import 'package:Kissan/model/category.dart';
import 'package:Kissan/model/product.dart';
import 'package:Kissan/components/globals.dart' as globals;

import 'model/BankTransactionDetails.dart';

String universaltoken;

class APIService {
  Future<LoginResponse> Otplogin(String username, String accessCode) async {
    LoginResponse model;
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    String url = Config.loginUrl + Config.login;
    try {
      final response = await Dio().post(
        url,
        data: {"username": username, "acessCode": accessCode},
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 200) {
        model = LoginResponse.fromJson(response.data);
        if (model != null && model.roleDetails.length == 0) {
          LoginResponse model = new LoginResponse();
          // model.roleDetails[0].name = "Role not assigned";
          // model.roleDetails[0].id = 0;
          // print("role name>>>>>>>>>" + model.roleDetails[0].name);
          prefs.setString("ROLE", "Role not assigned");
          globals.role = prefs.getString("ROLE");
        } else {
          prefs.setString("ROLE", model.roleDetails[0].name);
          globals.role = model.roleDetails[0].name;
        }
      } else {
        LoginResponse model = new LoginResponse();
        prefs.setString("ROLE", "Role not assigned");
        globals.role = prefs.getString("ROLE");
      }
    } on DioError catch (e) {
      print(e.message);
      LoginResponse model = new LoginResponse();
      model.statusCode = 400;
    }
    return model;
  }

  Future<List<BankTrascationModel>> getBanktHistorydetails(
      String mobileNumber, String token) async {
    List<BankTrascationModel> data = new List<BankTrascationModel>();
    // universaltoken = token;
    try {
      String url = Config.paymentservice +
          Config.accountHistory +
          "?userId=$mobileNumber";
      print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data = (response.data as List)
            .map((i) => BankTrascationModel.fromJson(i))
            .toList();
      }
      print(response.data);
    } on DioError catch (e) {
      print(e.response);
    }

    return data;
  }

  Future<bool> loginOTP(String mobileNumber) async {
    bool ret = false;
    String url = Config.loginUrl + Config.loginOtp;
    print(url);
    try {
      final response = await Dio().post(
        url,
        data: {
          "mobileNumber": mobileNumber,
        },
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 201) {
        ret = true;
        //LoginResponse.fromJson(response.data);

        // print(response.data);
      }
    } on DioError catch (e) {
      ret = false;
      print(e.message);
    }
    return ret;
  }

  final dbHelper = DBProvider.instance;
  Future<List<Category>> getBuyCategory() async {
    List<Category> data = new List<Category>();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String Location = prefs.getString('Location');
    // print("Bangalore@@@@@@@@@@@@@@@@@@@@@@ " + Location);
    if (Location == null || Location.contains('Mountain View')) {
      Location = 'Bengaluru';
    }
    try {
      String url = Config.url + Config.kissancategories + "?type=BUY";
      var response = await Dio().get(url,
          options: new Options(
              headers: {HttpHeaders.contentTypeHeader: 'application/json'}));
      if (response.statusCode == 200) {
        //  print(url);
        data =
            (response.data as List).map((i) => Category.fromJson(i)).toList();
      }
    } on DioError catch (e) {
      //  print(e.response);
    }
    return data;
  }

  Future<List<Category>> getSellCategory() async {
    List<Category> data = new List<Category>();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String Location = prefs.getString('Location');
    // print("Bangalore@@@@@@@@@@@@@@@@@@@@@@ " + Location);
    if (Location == null || Location.contains('Mountain View')) {
      Location = 'Bengaluru';
    }
    try {
      String url = Config.url + Config.kissancategories + "?type=SELL";
      print(url);
      var response = await Dio().get(url,
          options: new Options(
              headers: {HttpHeaders.contentTypeHeader: 'application/json'}));
      if (response.statusCode == 200) {
        //  print(url);
        data =
            (response.data as List).map((i) => Category.fromJson(i)).toList();
      }
    } on DioError catch (e) {
      //  print(e.response);
    }
    return data;
  }

  Future<List<CityListModel>> getCityList() async {
    List<CityListModel> data = new List<CityListModel>();
    try {
      String url = Config.url + Config.cityList;
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            // HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        // print(url);
        // print(response.data);
        data = (response.data as List)
            .map((i) => CityListModel.fromJson(i))
            .toList();
      }
    } on DioError catch (e) {
      // print(e.response);
    }
    return data;
  }

  Future<List<Product>> getOfferProduct(int cId) async {
    List<Product> data = new List<Product>();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String Location = prefs.getString('Location');
    // print("@@@@@@@@@@@@@@@@@@@@@@ " + Location);
    if (Location == null || Location.contains('Mountain View')) {
      Location = 'Bengaluru';
    }
    try {
      String url =
          Config.url + Config.product + "?cId=$cId&search=&cityName=$Location";
      var response = await Dio().get(url,
          options: new Options(
              headers: {HttpHeaders.contentTypeHeader: 'application/json'}));
      if (response.statusCode == 200) {
        // print(url);
        data = (response.data as List).map((i) => Product.fromJson(i)).toList();
      }
    } on DioError catch (e) {
      // print(e.response);
    }

    return data;
  }

  Future<List<Product>> getTopsellingProduct(int cId) async {
    final coutnt = await dbHelper.getCount();
    List<Product> data = new List<Product>();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt("Count", coutnt);
    String Location = prefs.getString('Location');
    //print("@@@@@@@@@@@@@@@@@@@@@@ " + Location);
    if (Location == null || Location.contains('Mountain View')) {
      Location = 'Bengaluru';
    }
    try {
      String url =
          Config.url + Config.topSelling + "?cId=$cId&cityName=$Location";
      var response = await Dio().get(url,
          options: new Options(
              headers: {HttpHeaders.contentTypeHeader: 'application/json'}));
      if (response.statusCode == 200) {
        // print(url);
        data = (response.data as List).map((i) => Product.fromJson(i)).toList();
      }
    } on DioError catch (e) {
      // print(e.response);
    }

    return data;
  }

  Future<List<Product>> getTopsavingProduct(int cId) async {
    List<Product> data = new List<Product>();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String Location = prefs.getString('Location');
    // print("@@@@@@@@@@@@@@@@@@@@@@ " + Location);
    if (Location == null || Location.contains('Mountain View')) {
      Location = 'Bengaluru';
    }
    try {
      String url =
          Config.url + Config.topSaving + "?cId=$cId&cityName=$Location";
      var response = await Dio().get(url,
          options: new Options(
              headers: {HttpHeaders.contentTypeHeader: 'application/json'}));
      if (response.statusCode == 200) {
        data = (response.data as List).map((i) => Product.fromJson(i)).toList();
      }
    } on DioError catch (e) {
      // print(e.response);
    }

    return data;
  }

  Future<List<OrderModel>> getorderdetails(
      String mobileNumber, String token) async {
    List<OrderModel> data = new List<OrderModel>();
    universaltoken = token;
    try {
      String url = Config.url +
          Config.getOrderDetails +
          "?customerId=$mobileNumber&type=SELL";
// print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data =
            (response.data as List).map((i) => OrderModel.fromJson(i)).toList();
      }
      // print(response.data);
    } on DioError catch (e) {
      // print(e.response);
    }

    return data;
  }

  Future<List<OrderModel>> getbuyorderdetails(
      String mobileNumber, String token) async {
    List<OrderModel> data = new List<OrderModel>();
    universaltoken = token;
    try {
      String url = Config.url +
          Config.getOrderDetails +
          "?customerId=$mobileNumber&type=BUY";
// print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data =
            (response.data as List).map((i) => OrderModel.fromJson(i)).toList();
      }
      // print(response.data);
    } on DioError catch (e) {
      // print(e.response);
    }

    return data;
  }

  Future<List<MyPaymentsModel>> myPaymentsList(
      String mobileNumber, String token) async {
    List<MyPaymentsModel> data = new List<MyPaymentsModel>();
    try {
      String url =
          Config.url + Config.getPayments + "?mobileNumber=$mobileNumber";
      // print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        // print(token);
        data = (response.data as List)
            .map((i) => MyPaymentsModel.fromJson(i))
            .toList();
      }
      // print(response.data);
    } on DioError catch (e) {
      // print(e.response);
    }

    return data;
  }

  Future<Pincodevalidation> pincodeValidation(String pincode) async {
    Pincodevalidation data;
    // bool ret = false;
    try {
      String url = Config.url + Config.validatePincode + "?postalCode=$pincode";
      // print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            //HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        // print(response.data);
        data = Pincodevalidation.fromJson(response.data);
        // return ret = true;
      }
      // print(token);
    } on DioError catch (e) {
      // print(e.response);
      //  return ret = false;
    }

    return data;
  }

  Future<List<Timeslot>> getTimeslot(String token) async {
    List<Timeslot> data = new List<Timeslot>();
    try {
      String url = Config.url + Config.timeslot;
      // print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data =
            (response.data as List).map((i) => Timeslot.fromJson(i)).toList();
      }
      // print(response.data);
      // print(token);
    } on DioError catch (e) {
      print(e.response);
    }

    return data;
  }

  Future<bool> userRegister(User model) async {
    bool ret = false;
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String City = prefs.getString('Location');
    final String Pincode = prefs.getString('Pincode');
    final String Address = prefs.getString('Address');
    final String State = prefs.getString('State');
    try {
      model.state = "$State";
      model.city = "$City";
      model.location = "$City";
      model.address1 = "$Address";
      //  model.pinCode = "$Pincode";
      if (Address == null || State == null) {
        model.address1 = "XXXXXXX";
        model.state = "XXXXXXX";
      }
      String url = Config.loginUrl + Config.userRegURL;
      var response = await Dio().post(url,
          data: jsonEncode(model.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
            },
          ));
      if (response.statusCode == 201) {
        // print(response.data);
        return ret = true;
      }
    } on DioError catch (e) {
      if (e.response.statusCode == 400) {
        // print(jsonEncode(model.toJson()));
        // print(e.error.data);
        return ret = false;
      } else {
        // print(e.message);
        // print(e.request);
        return ret = false;
      }
    }
    return ret;
  }

  Future<LoginResponse> login(String username, String password) async {
    LoginResponse model;
    String url = Config.loginUrl + Config.login;
    try {
      final response = await Dio().post(
        url,
        data: {
          "username": username,
          "password": password,
        },
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 200) {
        model = LoginResponse.fromJson(response.data);

        // print(response.data);
        // print(model.token);
      }
    } on DioError catch (e) {
      // print(e.message);
    }
    return model;
  }

  Future<bool> loginWithOTP(String mobileNumber) async {
    bool ret = false;
    String url = Config.loginUrl + Config.otp;
    try {
      final response = await Dio().post(
        url,
        data: {
          "mobileNumber": mobileNumber,
        },
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 201) {
        ret = true;
        //LoginResponse.fromJson(response.data);

        // print(response.data);
      }
    } on DioError catch (e) {
      ret = false;
      // print(e.message);
    }
    return ret;
  }

  Future<bool> regWithOTP(String mobileNumber) async {
    bool ret = false;
    String url = Config.loginUrl + Config.regOtp;
    // String url = "http://192.168.43.142:8081/loginService/user/v1/Regotp";
    // print(url);
    try {
      final response = await Dio().post(
        url,
        data: {
          "mobileNumber": mobileNumber,
        },
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 201) {
        ret = true;
        //LoginResponse.fromJson(response.data);

        // print(response.data);
      }
    } on DioError catch (e) {
      ret = false;
      // print(e.message);
    }
    return ret;
  }

  Future<ForgotPasswordOTP> forgotpassword(ForgotPasswordOTP model) async {
    bool ret = false;
    ForgotPasswordOTP data;
    String url = Config.loginUrl + Config.forgotPassword;
    try {
      final response = await Dio().post(
        url,
        data: jsonEncode(model.toJson()),
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 201) {
        // ret = true;
        data = ForgotPasswordOTP.fromJson(response.data);
        //LoginResponse.fromJson(response.data);

        // print(response.data);
      }
    } on DioError catch (e) {
      // ret = false;
      data = ForgotPasswordOTP.fromJson(e.response.data);
      // print(e.message);
    }
    return data;
  }

  Future<bool> updateMobileNumber(UpdateMoblie model) async {
    bool ret = false;
    String url = Config.loginUrl + Config.updatemobNumber;
    try {
      final response = await Dio().post(
        url,
        data: jsonEncode(model.toJson()),
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 201) {
        ret = true;
        //LoginResponse.fromJson(response.data);

        // print(response.data);
      }
    } on DioError catch (e) {
      ret = false;
      // print(e.message);
    }
    return ret;
  }

  Future<bool> createOrder(CreateOrder createOrder, String token) async {
    bool isOrderCreated = false;
     print(createOrder.toJson());

    print(jsonEncode(createOrder.toJson()));

    try {
      String url = Config.url + Config.placeOrderURL;
      var response = await Dio().post(url,
          data: jsonEncode(createOrder.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Bearer $token',
            },
          ));
      if (response.statusCode == 200) {
        // print(response.data);
        // print(jsonEncode(createOrder.toJson()));

        return isOrderCreated = true;
      }
    } on DioError catch (e) {
      if (e.response.statusCode == 404) {
        // print(e.error.data);
        return isOrderCreated = false;
      } else {
        // print(e.message);
        // print(e.request);
        return isOrderCreated = false;
      }
    }
    return isOrderCreated;
  }

  Future<List<Product>> getProduct(
      {int cId,
      int pageNumber,
      int pageSize,
      String strSearch,
      String sortBy,
      String sortOrder = "asc"}) async {
    List<Product> data = new List<Product>();
    //  // final SharedPreferences prefs = await SharedPreferences.getInstance();
    // //  String Location = prefs.getString('Location');
    //   //  print("@@@@@@@@@@@@@@@@@@@@@@ " + Location);
    //   if (Location == null || Location.contains('Mountain View')) {
    //     Location = 'Bengaluru';
    //   }
    try {
      String parameter = "";
      if (strSearch != null) {
        parameter += "&search=$strSearch";
      }
      if (pageSize != null) {
        parameter += "&pageSize=$pageSize";
      }
      if (pageNumber != null) {
        parameter += "&pageNumber=$pageNumber";
      }
      if (sortBy != null) {
        parameter += "&sortBy=$sortBy";
      }
      if (sortOrder != null) {
        parameter += "&order=$sortOrder";
      }
      String url = Config.url + Config.product + "?cId=$cId&search";
      var response = await Dio().get(url,
          options: new Options(
              headers: {HttpHeaders.contentTypeHeader: 'application/json'}));
      if (response.statusCode == 200) {
        data = (response.data as List).map((i) => Product.fromJson(i)).toList();
      }
    } on DioError catch (e) {
      // print(e.response);
    }

    return data;
  }

  Future<List<WalletHistory>> getwalletHistorydetails(
      String mobileNumber, String token) async {
    List<WalletHistory> data = new List<WalletHistory>();
    // universaltoken = token;
    try {
      String url = Config.paymentservice +
          Config.wallethistory +
          "?userId=$mobileNumber";
      print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data = (response.data as List)
            .map((i) => WalletHistory.fromJson(i))
            .toList();
      }
      print(response.data);
    } on DioError catch (e) {
      print(e.response);
    }

    return data;
  }

  Future<FundAccountResponse> addfundAccount(FundAccount vendor) async {
    FundAccountResponse data;
    try {
      String username = Config.razorpaykey;
      String password = Config.apiSecret;
      String basicAuth = base64Encode(utf8.encode('$username:$password'));
      print(basicAuth);
      print(vendor);
      String url = "https://api.razorpay.com/v1/fund_accounts";
      var response = await Dio().post(url,
          data: jsonEncode(vendor.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Basic $basicAuth',
            },
          ));
      if (response.statusCode == 200 || response.statusCode == 201) {
        print(response.data);
        data = FundAccountResponse.fromJson(response.data);
      }
    } on DioError catch (e) {
     // print(e.request.data);
      if (e.response.statusCode == 400) {
        print(e.response.data);
        print(e.message);
        print(e.error);

        data = FundAccountResponse.fromJson(e.response.data);
      } else {
        data = FundAccountResponse.fromJson(e.response.data);
      }
    }
    return data;
  }

  Future<WithdrawRequest> withdrawmoney(
      WithdrawRequest request, String token) async {
    WithdrawRequest data;
    try {
      String url = Config.paymentservice + Config.withdrawmoney;
      var response = await Dio().post(url,
          data: jsonEncode(request.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Bearer $token',
            },
          ));
      if (response.statusCode == 201) {
        data = WithdrawRequest.fromJson(response.data);
      }
    } on DioError catch (e) {
      if (e.response.statusCode == 400) {
        data = WithdrawRequest.fromJson(e.response.data);
      } else {
        data = WithdrawRequest.fromJson(e.response.data);
      }
    }
    return data;
  }

  Future<BankContactadded> addbankcontact(
      BankContactadded contid, String token) async {
    BankContactadded data;
    try {
      String url = Config.paymentservice + Config.rzpbankid;
      var response = await Dio().post(url,
          data: jsonEncode(contid.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Bearer $token',
            },
          ));
      if (response.statusCode == 201) {
        data = BankContactadded.fromJson(response.data);
      }
    } on DioError catch (e) {
      // ret = false;
      data = BankContactadded.fromJson(e.response.data);
      // print(e.message);
    }
    return data;
  }

  Future<VendorAccountdetails> getVendorBankDetails(
      String mobile, String token) async {
    VendorAccountdetails data;

    try {
      String url =
          Config.paymentservice + Config.getvendorbankdata + "?userId=$mobile";
      print(url);
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data = VendorAccountdetails.fromJson(response.data);
      }
    } on DioError catch (e) {
      print(e.response);
    }
    return data;
  }

  Future<ContactResponse> createContact(CreateContact vendor) async {
    ContactResponse data;
    try {
      String username = Config.razorpaykey;
      String password = Config.apiSecret;
      String basicAuth = base64Encode(utf8.encode('$username:$password'));
      print(basicAuth);
      print(vendor);
      String url = "https://api.razorpay.com/v1/contacts";
      var response = await Dio().post(url,
          data: jsonEncode(vendor.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Basic $basicAuth',
            },
          ));
      if (response.statusCode == 200) {
        print(response.data);
        data = ContactResponse.fromJson(response.data);
      }
    } on DioError catch (e) {
      if (e.response.statusCode == 400) {
        data = ContactResponse.fromJson(e.response.data);
      } else {
        data = ContactResponse.fromJson(e.response.data);
      }
    }
    return data;
  }

  Future<Contactadded> addrzpccontact(Contactadded contid, String token) async {
    Contactadded data;
    try {
      String url = Config.paymentservice + Config.rzpContact;
      var response = await Dio().post(url,
          data: jsonEncode(contid.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Bearer $token',
            },
          ));
      if (response.statusCode == 200) {
        data = Contactadded.fromJson(response.data);
      }
    } on DioError catch (e) {
      if (e.response.statusCode == 400) {
        data = Contactadded.fromJson(e.response.data);
      } else {
        data = Contactadded.fromJson(e.response.data);
      }
    }
    return data;
  }

  Future<List<UserAddressModel>> getuseraddress(
      int userId, String token) async {
    List<UserAddressModel> data = new List<UserAddressModel>();
    try {
      String url = Config.loginUrl + Config.useraddress + "?userId=$userId";
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        // print(url);
        // print(response.data);
        data = (response.data as List)
            .map((i) => UserAddressModel.fromJson(i))
            .toList();
      }
    } on DioError catch (e) {
      // print(e.response);
    }
    return data;
  }

  Future<bool> addNewaddress(AddUserAddress model, String token) async {
    // User usermodel;
    bool ret = false;
    try {
      String url = Config.loginUrl + Config.newaddress;
      // print(url);
      // print(token);
      // print(model.userId);
      // print(jsonEncode(model.toJson()));
      var response = await Dio().post(url,
          data: model.toJson(),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Bearer $token',
            },
          ));
      if (response.statusCode == 201) {
        // print(response.data);
        return ret = true;
      }
    } on DioError catch (e) {
      if (e.response.statusCode == 404) {
        // print(e.error.data);
        return ret = false;
      } else {
        // print(e.message);
        // print(e.request);
        return ret = false;
      }
    }
    return ret;
  }

  Future<UpdatePasswordModel> updatepassword(UpdatePasswordModel model) async {
    UpdatePasswordModel data;
    String url = Config.loginUrl + Config.updatePassword;
    try {
      final response = await Dio().post(
        url,
        data: jsonEncode(model.toJson()),
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
          },
        ),
      );

      if (response.statusCode == 201) {
        // ret = true;
        data = UpdatePasswordModel.fromJson(response.data);
        //LoginResponse.fromJson(response.data);

        // print(response.data);
      }
    } on DioError catch (e) {
      // ret = false;
      data = UpdatePasswordModel.fromJson(e.response.data);
      // print(e.message);
    }
    return data;
  }

  Future<String> getCityName(String location) async {
    CityNameModel data;

    try {
      String url = Config.url + Config.cityName + "?subcity=$location";
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            // HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data = CityNameModel.fromJson(response.data);
        final SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString('Location', data.cityName);
        // print(url);
        // print(prefs.getString("Location"));
      }
    } on DioError catch (e) {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString('Location', "Bengaluru");
      // print(e.response);
    }
    return data.cityName;
  }

  Future<UserFeedback> reportFeedback(UserFeedback model, String token) async {
    UserFeedback data;
    String url = Config.url + Config.feedback;
    try {
      final response = await Dio().post(
        url,
        data: jsonEncode(model.toJson()),
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
            HttpHeaders.authorizationHeader: 'Bearer $token',
          },
        ),
      );

      if (response.statusCode == 201) {
        data = UserFeedback.fromJson(response.data);

        // print(response.data);
      }
    } on DioError catch (e) {
      data = UserFeedback.fromJson(e.response.data);
      // print(e.message);
    }
    return data;
  }

  Future<bool> Addmoneyforwallet(
      AddMoneyToWallet addMoneyToWallet, String token) async {
    bool isOrderCreated = false;
    // print(createOrder.toJson());

    // print(jsonEncode(addMoneyToWallet.toJson()));

    try {
      var response = await Dio().post(Config.url + Config.addmoney,
          data: jsonEncode(addMoneyToWallet.toJson()),
          options: new Options(
            headers: {
              HttpHeaders.contentTypeHeader: "application/json",
              HttpHeaders.authorizationHeader: 'Bearer $token',
            },
          ));
      if (response.statusCode == 201) {
        // print(response.data);
        // print(jsonEncode(addMoneyToWallet.toJson()));

        return isOrderCreated = true;
      }
    } on DioError catch (e) {
      if (e.response.statusCode == 404) {
        // print(e.error.data);
        return isOrderCreated = false;
      } else {
        // print(e.message);
        // print(e.request);
        return isOrderCreated = false;
      }
    }
    return isOrderCreated;
  }

  Future<double> getwalletBal(String mobile, String token) async {
    WalletBalancemodel data;

    try {
      String url =
          Config.paymentservice + Config.getwalbalance + "?userId=$mobile";
      var response = await Dio().get(url,
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data = WalletBalancemodel.fromJson(response.data);
        final SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setDouble('Walletamt', data.walletBalance);
        // print(url);
        // print(prefs.getDouble("Walletamt"));
      }
    } on DioError catch (e) {
      // print(e.response);
    }
    return data.walletBalance;
  }
}
