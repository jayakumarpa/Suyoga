class Config {
  static String imageurl = "http://images.suyoga.co.in/grocery/";
  //Dev
  static String url = "http://13.200.246.156:8085/kissanservice/";
  static String paymentservice = "http://13.200.246.156:8086/paymentservice/";
  static String loginUrl = "http://13.200.246.156:8081/loginService/";

  //production
  // static String url = "https://api.suyoga.app/kissanservice/";
  // static String paymentservice = "https://api.suyoga.app/paymentservice/";
  // static String loginUrl = "https://api.suyoga.app/loginService/";

  // static String url = "http://13.233.187.96:8085/kissanservice/";
  // static String paymentservice = "http://13.233.187.96:8086/paymentservice/";
  // static String loginUrl = "http://13.233.187.96:8081/loginService/";

  static String kissancategories = "category/v1/getCategories";
  static String userRegURL = "user/v1/registration";
  static String product = 'product/v1/details';
  static String topSaving = 'product/v1/topSaving';
  static String topSelling = 'product/v1/topSelling';
  static String todayoffertagId = '24';
  static String topSellingProductId = '25';

  //Testing
  // static String razorpaykey = 'rzp_test_X9fHWKNJQEDLeQ';
  // static String apiSecret = 'qKc8WdYJYmfXFXz8ewnjxryf';

  //Live Production
  static String razorpaykey = 'rzp_live_quQx2b6nphH2AP';
  static String apiSecret = 'MIi5XR0ntDzUyn9JcR4BdXs1';

  static String placeOrderURL = "product/v1/placeOrder";
  static String getOrderDetails = "product/v1/getOrderDetails";
  static String timeslot = "category/v1/timeSolt";
  static String getPayments = "product/v1/transactionDetails";
  static String dashboardImage = "http://images.suyoga.co.in/retail/";
  static String login = "authenticate";
  static String otp = "user/v1/otp";
  static String regOtp = "user/v1/Regotp";
  static String forgotPassword = "user/v1/forgotPassword";
  static String updatemobNumber = "user/v1/updateMobile";
  static String validatePincode = "category/v1/validatePostalCode";
  static String cityList = "area/v1/getCityList";
  static String cancelOrder = "product/v1/orderCancel";
  static String promocode = "promocode/v1/validate";
  static String useraddress = "user/v1/getuserAddress";
  static String newaddress = "user/v1/adduserAddress";
  static String updatePassword = "user/v1/updatePassword";
  static String cityName = "area/v1/getCityName";
  static String feedback = "feedback/v1/reportissue";
  static String addmoney = "wallet/v1/addMoney";

  static String getwalbalance = "wallet/v1/getWalletBalance";
  static String rzpContact = "vendor/v1/addContactid";
  static String rzpbankid = "vendor/v1/addbankId";

  static String withdrawmoney = "vendor/v1/WithdrawMoney";
  static String wallethistory = "vendor/v1/getWalletTrasdetails";
  static String getvendorbankdata = "vendor/v1/getaccountdetails";
  static String accountHistory = "vendor/v1/getAccountTrasdetails";

  static String loginOtp = "user/v1/loginotp";
}
