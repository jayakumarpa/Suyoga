import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/pages/Buy_orderDetailsPage.dart';
import 'package:Kissan/utils/AppExtension.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/home.dart';
import 'package:Kissan/pages/loggin.dart';
import 'package:Kissan/pages/userprofile.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/pages/Order_detailsPage.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AccountTab extends StatefulWidget {
  @override
  _AccountTabState createState() => _AccountTabState();
}

class _AccountTabState extends State<AccountTab> {
  List<UserdatafromDB> list = new List();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  double walbalance = 0;
  bool isenableappBar = true;
  final GlobalKey<AppExpansionTileState> expansionTile = new GlobalKey();
  @override
  void initState() {
    fetch();
    var caritemList = Provider.of<CartProvider>(context, listen: false);
    caritemList.getwalletbalance();
  }

  Future<double> getwalletamt() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    double walletbal = prefs.getDouble("Walletamt");
    return walletbal;
  }

  Widget getwalletdetails() {
    return FutureBuilder(
        future: getwalletamt(),
        builder: (context, AsyncSnapshot snapshot) {
          if (snapshot.data != null) {
            this.walbalance = snapshot.data;
            return gridHeader();
          }
          return gridHeader();
        });
  }
  Future<bool> _onbackpress() {
     if (this.isenableappBar == true) {
      
    // } else {
      return Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
    child:Scaffold(
      appBar: AppBar(
        centerTitle: true,
        brightness: Brightness.dark,
        elevation: 2,
        backgroundColor: Colors.green,
        automaticallyImplyLeading: true,
        leading: IconButton(
          onPressed: () async {
            final SharedPreferences prefs =
                await SharedPreferences.getInstance();
            int counter = prefs.getInt("Count");
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(
                  ccount: counter,
                ),
              ),
            );
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
        title: Text(
          'Account',
          style: TextStyle(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.blueGrey[100],
      body: Container(
        child: getwalletdetails(),
        decoration: new BoxDecoration(
          color: Colors.blueGrey[100],
          // image: new DecorationImage(
          //   fit: BoxFit.cover,
          //   colorFilter: new ColorFilter.mode(
          //       Colors.grey.withOpacity(0.3), BlendMode.dstATop),
          //   image: new AssetImage("assets/images/grocery.jpg"),
          // ),
        ),
      ),
    ),
    onWillPop: _onbackpress);
  }

  fetch() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"].toString(),
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model),
          print(model.name + model.mobileNumber),
        });
    setState(() {});
  }

  Widget gridHeader() {
    return list.length == 0
        ? Center(
            child: LoginPage(),
          )
        : Container(
            child: new ListView.builder(
                itemCount: 1,
                itemBuilder: (context, index) {
                  return new Container(
                    child: Column(
                      children: <Widget>[
                        ClipPath(
                          child:
                              Container(color: Colors.green.withOpacity(0.8)),
                          clipper: getClipper(),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Container(
                          color: Colors.transparent,
                          height: MediaQuery.of(context).size.height * 0.24,
                          width: double.infinity,
                          child: Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Column(
                                children: <Widget>[
                                  CircleAvatar(
                                    radius: 40,
                                    child: Icon(
                                      Icons.person,
                                      color: Colors.white,
                                    ),
                                    backgroundColor: Colors.green[900],
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text(
                                    list[index].name,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text(
                                    list[index].mobileNumber,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              )),
                        ),
                        ListTile(
                          leading: Icon(
                            Icons.home,
                            color: Colors.black,
                            size: 30,
                          ),
                          title: Text("   Home",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              )),
                          onTap: () async {
                            final SharedPreferences prefs =
                                await SharedPreferences.getInstance();
                            int counter = prefs.getInt("Count");
                            Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => HomePage(
                                ccount: counter,
                              ),
                            ));
                          },
                        ),
                        ListTile(
                            leading: Icon(
                              Icons.shopping_basket,
                              color: Colors.black,
                              size: 30,
                            ),
                            title: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    expansionTile.currentState.collapse();
                                  });
                                },
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      new AppExpansionTile(
                                          key: expansionTile,
                                          title: new Text('Orders',
                                              style: TextStyle(
                                                  fontSize: 22,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.black)),
                                          backgroundColor: Colors.transparent,
                                          children: <Widget>[
                                            new ListTile(
                                              title: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text('Buy Orders',
                                                        style: TextStyle(
                                                          fontSize: 22,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.black,
                                                        )),
                                                  ]),
                                              onTap: () {
                                                Navigator.of(context)
                                                    .push(MaterialPageRoute(
                                                  builder: (context) =>
                                                      BuyOrderDetails(),
                                                ));
                                              },
                                            ),
                                            new ListTile(
                                              title: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text('Sell Orders',
                                                        style: TextStyle(
                                                          fontSize: 22,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Colors.black,
                                                        )),
                                                  ]),
                                              onTap: () {
                                                Navigator.of(context)
                                                    .push(MaterialPageRoute(
                                                  builder: (context) =>
                                                      OrderDetails(),
                                                ));
                                              },
                                            ),
                                          ]),
                                    ]))),
                        ListTile(
                            leading: Icon(
                              Icons.account_balance_wallet,
                              color: Colors.black,
                              size: 30,
                            ),
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('   Wallet',
                                    style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    )),
                                Text('\u20B9' + ' ' + '${this.walbalance}',
                                    style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.green[900],
                                    )),
                              ],
                            )),
                        ListTile(
                          leading: Icon(
                            Icons.people,
                            size: 30,
                            color: Colors.black,
                          ),
                          title: Text('   Profile',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              )),
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => userprofile(
                                      profilemodel: model,
                                    )));
                          },
                        ),
                        ListTile(
                            leading: Icon(
                              Icons.access_time,
                              size: 30,
                              color: Colors.black,
                            ),
                            title: Text('   Logout',
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                )),
                            onTap: () {
                              _showDialog();
                            }),
                      ],
                    ),
                  );
                }),
          );
  }

  void _showDialog() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("Kissan"),
          content: new Text("Are you sure you want to Logout"),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            new FlatButton(
              child: new Text("No"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            new FlatButton(
              child: new Text("YES"),
              onPressed: () {
                dbHelper.userdelete();
                dbHelper.buycartdelete();
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => LoginPage(),
                ));
              },
            ),
          ],
        );
      },
    );
  }
}

class getClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = new Path();

    path.lineTo(0.0, size.height / 1.9);
    path.lineTo(size.width + 125, 0.0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    // TODO: implement shouldReclip
    return true;
  }
}
