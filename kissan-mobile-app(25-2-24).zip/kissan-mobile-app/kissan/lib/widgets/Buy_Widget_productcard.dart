import 'package:Kissan/components/Buy_Cart_counter.dart';
import 'package:Kissan/pages/BuyProductDetails.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import 'package:Kissan/model/product.dart';
import 'package:Kissan/config.dart';
import 'package:Kissan/pages/product_details.dart';

import 'package:Kissan/utils/CustomTextStyle.dart';
import 'package:Kissan/components/cart_counter.dart';

// keep this code

class BuyProductCard extends StatelessWidget {
  BuyProductCard({Key key, this.data}) : super(key: key);
  Product data;
  final dbHelper = DBProvider.instance;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final coutnt = await dbHelper.buygetCount();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BuyProductDetails(
              product: data,
            ),
          ),
        );
      },
      child: Column(
        children: <Widget>[
          Container(
            height: 175,
            margin: EdgeInsets.only(left: 10, right: 10, top: 10),
            decoration: BoxDecoration(
                color: Colors.transparent,
                border: Border.all(),
                borderRadius: BorderRadius.all(Radius.circular(16))),
            child: Row(
              children: <Widget>[
                SizedBox(height: 10),
                Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(
                          right: 0, left: 0, top: 20, bottom: 8),
                      width: 100,
                      height: 130,
                      padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
                      child: CachedNetworkImage(
                          imageUrl:
                              Config.imageurl + data.productCode + '.png'),
                      // decoration: BoxDecoration(
                      //     borderRadius: BorderRadius.all(Radius.circular(20)),
                      //     color: Colors.transparent,
                      //     image: DecorationImage(
                      //         fit: BoxFit.fill,
                      //         image: NetworkImage(
                      //           Config.imageurl + data.productCode + '.png',
                      //         )))
                    )
                  ],
                ),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Align(
                          alignment: Alignment.center,
                        ),
                        Container(
                          padding: EdgeInsets.only(right: 8, top: 4),
                          child: Text(
                            '${data.productName}',
                            maxLines: 2,
                            softWrap: true,
                            style: CustomTextStyle.textFormFieldSemiBold
                                .copyWith(fontSize: 18),
                          ),
                        ),
                        Expanded(
                            child: Text('Market Price' + ' ${data.marketPrice}',
                                style: TextStyle(
                                  height: 1.5,
                                  decoration: TextDecoration.lineThrough,
                                  fontSize: 18,
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                ))),
                        Expanded(
                            child: Text('Min Quantity' + ' ${data.quantity}',
                                style: TextStyle(
                                  height: 1.4,
                                  // decoration: TextDecoration.lineThrough,
                                  fontSize: 16,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ))),
                        Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                '\u20B9' + ' ' + '${data.price}',
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                              Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: BuyCartCounter(
                                    data: data,
                                    numOfItems: 0,
                                  ))
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  flex: 1,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
