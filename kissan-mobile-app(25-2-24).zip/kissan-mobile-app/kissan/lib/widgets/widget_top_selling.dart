import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:Kissan/api_service.dart';
import 'package:Kissan/config.dart';
import 'package:Kissan/model/product.dart';
import 'package:Kissan/pages/product_details.dart';
import 'package:Kissan/pages/product_page.dart';

class WidgetTopsellingProduct extends StatefulWidget {
  WidgetTopsellingProduct({Key key, this.levelName, this.tagId})
      : super(key: key);

  String levelName;
  int tagId;

  @override
  _WidgetTopsellingProductState createState() =>
      _WidgetTopsellingProductState();
}

class _WidgetTopsellingProductState extends State<WidgetTopsellingProduct> {
  APIService apiService;

  @override
  void initState() {
    apiService = new APIService();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xffF4F7FA),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(left: 16, top: 4),
                child: Text(
                  this.widget.levelName,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16, top: 4),
                child: FlatButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ProductPage(
                                    // categoryId: data.categoryId,
                                    categoryId: this.widget.tagId,
                                  )));
                    },
                    child: Text(
                      'View ALL',
                      style: TextStyle(color: Colors.redAccent),
                    )),
              )
            ],
          ),
          _offerProductList(),
        ],
      ),
    );
  }

  Widget _offerProductList() {
    return new FutureBuilder(
        future: apiService.getTopsellingProduct(this.widget.tagId),
        builder: (BuildContext context, AsyncSnapshot<List<Product>> model) {
          if (model.hasData) {
            return _buildList(model.data);
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  Widget _buildList(List<Product> items) {
    return Container(
      height: 200,
      alignment: Alignment.centerLeft,
      child: ListView.builder(
          shrinkWrap: true,
          physics: ClampingScrollPhysics(),
          scrollDirection: Axis.horizontal,
          itemCount: items.length,
          itemBuilder: (context, index) {
            var data = items[index];
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.all(10),
                  width: 130,
                  height: 120,
                  alignment: Alignment.center,
                  // child: Image.network(
                  //   Config.imageurl + data.productCode + '.png',
                  //   height: 120,
                  // ),

                  child: InkWell(
                    onTap: () {
                      // print("on click on image>>>>>>");
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProductDetails(
                              product: data,
                            ),
                          ));
                    },
                    child: Container(
                      child: CachedNetworkImage(
                        imageUrl: Config.imageurl + data.productCode + '.png',
                        height: 120,
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(4),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          offset: Offset(0, 5),
                          blurRadius: 15,
                        )
                      ]),
                ),
                Container(
                  width: 130,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    data.productName,
                    style: TextStyle(fontSize: 14, color: Colors.black),
                  ),
                ),
              ],
            );
          }),
    );
  }
}
