import 'package:Kissan/pages/BuyProductPage.dart';
import 'package:Kissan/pages/DrawerWidget.dart';
import 'package:Kissan/widgets/widget_cart_card.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/category.dart';
import 'package:Kissan/api_service.dart';
import 'package:Kissan/pages/product_page.dart';
import 'package:Kissan/config.dart';

class WidgetCategory extends StatefulWidget {
  @override
  _WidgetCategoryState createState() => _WidgetCategoryState();
}

class _WidgetCategoryState extends State<WidgetCategory> {
  APIService apiService;
  Category categoryModel;

  @override
  void initState() {
    apiService = new APIService();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, top: 10),
                child: Text(
                  'Sell Categories',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16, top: 10, right: 10),
                child: Text(
                  'View All',
                  style: TextStyle(color: Colors.red),
                ),
              )
            ],
          ),
          _categoryList(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16, top: 10),
                child: Text(
                  'Buy Categories',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16, top: 10, right: 10),
                child: Text(
                  'View All',
                  style: TextStyle(color: Colors.red),
                ),
              )
            ],
          ),
          _categoryBuyList()
        ],
      ),
    );
  }

  Widget _categoryList() {
    return new FutureBuilder(
        future: apiService.getSellCategory(),
        builder: (
          BuildContext context,
          AsyncSnapshot<List<Category>> model,
        ) {
          if (model.hasData) {
            return _sellbuildCategoryList(model.data);
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  Widget _categoryBuyList() {
    return new FutureBuilder(
        future: apiService.getBuyCategory(),
        builder: (
          BuildContext context,
          AsyncSnapshot<List<Category>> model,
        ) {
          if (model.hasData) {
            return _buildCategoryList(model.data);
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  Widget _buildCategoryList(List<Category> categories) {
    return Container(
      height: 250,
      alignment: Alignment.centerLeft,
      child: ListView.builder(
        shrinkWrap: true,
        physics: ClampingScrollPhysics(),
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        itemBuilder: (context, index) {
          var data = categories[index];
          return GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => BuyProductPage(
                              categoryId: data.categoryId,
                            )));
              },
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      margin: EdgeInsets.all(10),
                      width: 180,
                      height: 180,
                      alignment: Alignment.center,
                      child: CachedNetworkImage(
                        imageUrl: Config.imageurl + data.categoryCode + '.png',
                        height: 300,
                      ),
                      decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: Colors.greenAccent[100],
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 5),
                                blurRadius: 15),
                          ]),
                    ),
                  ),
                  Row(
                    children: [
                      Text(data.categoryName.toString(),
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      Icon(
                        Icons.keyboard_arrow_right,
                        size: 14,
                      )
                    ],
                  ),
                ],
              ));
        },
      ),
    );
  }
}

Widget _sellbuildCategoryList(List<Category> categories) {
  return Container(
    height: 250,
    alignment: Alignment.centerLeft,
    child: ListView.builder(
      shrinkWrap: true,
      physics: ClampingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      itemCount: categories.length,
      itemBuilder: (context, index) {
        var data = categories[index];
        return GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ProductPage(
                            categoryId: data.categoryId,
                          )));
            },
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    margin: EdgeInsets.all(10),
                    width: 180,
                    height: 180,
                    alignment: Alignment.center,
                    child: CachedNetworkImage(
                      imageUrl: Config.imageurl + data.categoryCode + '.png',
                      height: 300,
                    ),
                    decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        color: Colors.greenAccent[100],
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              offset: Offset(0, 5),
                              blurRadius: 15),
                        ]),
                  ),
                ),
                Row(
                  children: [
                    Text(data.categoryName.toString(),
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    Icon(
                      Icons.keyboard_arrow_right,
                      size: 14,
                    )
                  ],
                ),
              ],
            ));
      },
    ),
  );
}

class sidemenuCategory extends StatefulWidget {
  @override
  _sidemenuCategoryState createState() => _sidemenuCategoryState();
}

class _sidemenuCategoryState extends State<sidemenuCategory> {
  APIService apiService;
  Category categoryModel;

  @override
  void initState() {
    apiService = new APIService();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2,
        child: Scaffold(
            appBar: _buildAppBar(),
            drawer: DrawerWidget(),
            body: Container(
              color: Colors.white,
              child: Column(
                children: [_categoryList()],
              ),
            )));
  }

  Widget _buildAppBar() {
    var counter;
    return AppBar(
      bottom: TabBar(
        tabs: [
          Tab(
            text: "Buy Products",
          ),
          Tab(
            text: "Sell Products",
          ),
        ],
      ),
      leading: Builder(
        builder: (context) => GestureDetector(
          child: Icon(
            Icons.menu,
            color: Colors.white,
            size: 30,
          ),
          onTap: () {
            Scaffold.of(context).openDrawer();
          },
        ),
      ),
      centerTitle: true,
      brightness: Brightness.dark,
      elevation: 0,
      backgroundColor: Colors.green,
      automaticallyImplyLeading: false,
      title: Text(
        'KISSAN',
        style: TextStyle(color: Colors.white),
      ),
      actions: [
        Icon(
          Icons.notifications_none,
          color: Colors.white,
        ),
        SizedBox(
          width: 10,
        ),
        Container(
          // padding: EdgeInsets.only(right: 10),
          padding: EdgeInsets.only(top: 10),
          child: new Stack(
            children: <Widget>[
              new IconButton(
                  // icon: Icon(Icons.notifications),
                  icon: Icon(Icons.shopping_cart),
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => CartPageIconPress()));
                  }),
              counter != 0
                  ? new Positioned(
                      right: 4,
                      top: 6,
                      child: new Container(
                        padding: EdgeInsets.all(2),
                        decoration: new BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 14,
                          minHeight: 14,
                        ),
                        child: Text(
                          '$counter',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : new Positioned(
                      right: 4,
                      top: 6,
                      child: new Container(
                        padding: EdgeInsets.all(2),
                        decoration: new BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 14,
                          minHeight: 14,
                        ),
                        child: Text(
                          '$counter',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
            ],
          ),
        ),
      ],
    );
  }

  Widget _categoryList() {
    return new FutureBuilder(
        future: apiService.getSellCategory(),
        builder: (
          BuildContext context,
          AsyncSnapshot<List<Category>> model,
        ) {
          if (model.hasData) {
            return _buildCategoryList(model.data);
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  Widget _buildCategoryList(List<Category> categories) {
    return Container(
      height: 250,
      alignment: Alignment.centerLeft,
      child: ListView.builder(
        shrinkWrap: true,
        physics: ClampingScrollPhysics(),
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        itemBuilder: (context, index) {
          var data = categories[index];
          return GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ProductPage(
                              categoryId: data.categoryId,
                            )));
              },
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      margin: EdgeInsets.all(10),
                      width: 180,
                      height: 180,
                      alignment: Alignment.center,
                      child: CachedNetworkImage(
                        imageUrl: Config.imageurl + data.categoryCode + '.png',
                        height: 300,
                      ),
                      decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: Colors.greenAccent[100],
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 5),
                                blurRadius: 15),
                          ]),
                    ),
                  ),
                  Row(
                    children: [
                      Text(data.categoryName.toString(),
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      Icon(
                        Icons.keyboard_arrow_right,
                        size: 14,
                      )
                    ],
                  ),
                ],
              ));
        },
      ),
    );
  }
}
