// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:Kissan/components/cart_provider.dart';
// import 'package:Kissan/config.dart';
// import 'package:Kissan/model/ProductLocal.dart';
// import 'package:Kissan/utils/constants.dart';
// import 'package:Kissan/utils/dataBase.dart';
// import 'package:Kissan/utils/message_pop.dart';
// import 'package:shared_preferences/shared_preferences.dart';

// double total = 0.0;

// class BuyCartProduct extends StatefulWidget {
//   BuyCartProduct({this.data});
//   BuyProductLocal data;

//   //int numOfItems = 0;
//   //double total = 0.0;

//   @override
//   _BuyCartProductState createState() => _BuyCartProductState();
// }

// class _BuyCartProductState extends State<BuyCartProduct> {
//   final dbHelper = DBProvider.instance;
// int counter = 0;
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       elevation: 2.0,
//       margin: new EdgeInsets.symmetric(horizontal: 8.0, vertical: 6.0),
//       child: Container(
//         decoration: BoxDecoration(color: Colors.white),
//         child: makeListTitle(context),
//       ),
//     );
//   }

//   ListTile makeListTitle(BuildContext context) => ListTile(
    
//         contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
        
//         leading: Container(
//           height: 150,
//           width: 50,
//           alignment: Alignment.center,
//           child: Image.network(
//             Config.imageurl + widget.data.productCode + '.png',
//             height: 150,
//           ),
//         ),
//         title: Padding(
//           padding: EdgeInsets.all(5),
//           child: Text(
//             widget.data.productName,
//             style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
//           ),
//         ),
//         subtitle: Padding(
//           padding: EdgeInsets.all(5),
//           child: Wrap(
//             direction: Axis.vertical,
//             children: [
//               Text(
//                 // '${widget.data.price.toString()}',
//                 '${widget.data.totalPrice.toString()}',
//                 style: TextStyle(color: Colors.black),
//               ),
//             ],
//           ),
//         ),

//         // trailing: Container(
//         //   width: 120,
//         //   child: PlaceOder(
//         //     data: widget.data,
//         //     numOfItems: widget.data.numOfItems,
//         //   ),
//         // ),

//         trailing: Container(
//           // width: 120,
//            width: MediaQuery.of(context).size.width*0.300,
//           child: Row(
//             children: <Widget>[
//               buildOutlineButton(
                
//                 icon: Icons.remove,
//                 press: () {
//                   if (widget.data.numOfItems > 1) {
//                     setState(() {
//                       widget.data.numOfItems--;
//                       calculatePrice();
//                     }
//                     );
//                   } else if (widget.data.numOfItems == 0 ||
//                       widget.data.numOfItems == 1) {
//                     PopMessage.showMessage(
//                         context,
//                         'Suyoga',
//                         'Do you want to delete this item?',
//                         'Yes',
//                         () async {
//                           final coutnt = await dbHelper.buygetCount();
//                           final SharedPreferences prefs =
//                               await SharedPreferences.getInstance();
//                           prefs.setInt("Count", coutnt);

//                           int id = widget.data.productId;

//                           dbHelper.buydelete(id);

//                           Navigator.of(context).pop(setState(() {}));
//                           var caritemList =
//                               Provider.of<CartProvider>(context, listen: false);
//                           caritemList.buyupdaterecord();
//                         },
//                         buttonText2: 'No',
//                         isconformationDialog: true,
//                         onPressed2: () async {
//                           final coutnt = await dbHelper.buygetCount();
//                           final SharedPreferences prefs =
//                               await SharedPreferences.getInstance();
//                           prefs.setInt("Count", coutnt);
//                           Navigator.of(context).pop();
//                         });
//                   }
//                 },
//               ),
//               Padding(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: kDefaultPaddin / 2),
//                 child: Text(
//                   // if our item is less  then 10 then  it shows 01 02 like that
//                   widget.data.numOfItems.toString().padLeft(1, "0"),
//                   style: Theme.of(context).textTheme.headline6,
//                 ),
//               ),
//               buildOutlineButton(
//                   icon: Icons.add,
//                   press: () {
//                     setState(() {
//                       // this.widget.numOfItems++;
//                       widget.data.numOfItems++;
//                       // // _addTocart();
//                       calculatePrice();
//                       // var caritemList = Provider.of<CartProvider>(context, listen: false);
//                       // caritemList.updaterecord();
//                     });
//                   }),
//             ],
//           ),
//         ),
//       );

//   SizedBox buildOutlineButton({IconData icon, Function press}) {
//     return SizedBox(
//       width: 35.5,
//       height: 30,
//       child: OutlineButton(
//         padding: EdgeInsets.zero,
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(13),
//         ),
//         onPressed: press,
//         child: Icon(icon),
//       ),
//     );
//   }
//   cartcount() async {
//     final coutnt = await dbHelper.getCount();
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     prefs.setInt("Count", coutnt);
//     this.counter = prefs.getInt("Count");
   
//   }


//   void calculatePrice() {
//     _deleteCart();
//     BuyProductLocal cp;
//     //int pid = cp.productId;
//     cp = this.widget.data;

//     // int Quantity = this.widget.numOfItems;
//     int Quantity = widget.data.numOfItems;

//     //data.price
//     // double price = double.parse(cp.price);
//     double price = double.parse(this.widget.data.price);
//     total = Quantity * price;
//     // _addTocart(cp, total, this.widget.numOfItems);
//     _addTocart(cp, total, widget.data.numOfItems);
//     widget.data.numOfItems--;
//     // delete(pid);
//     // insert(produ, total);
//   }

//   Widget _deleteCart() {
//     BuyProductLocal deleteProd;
//     deleteProd = this.widget.data;
//     int id = deleteProd.productId;
//     dbHelper.buydelete(id);
//     // dbHelper.dbdelete(dId);
//     // Product product;
//   }

//   Widget _addTocart(cp, total, numOfItems) {
//     if (numOfItems == 0) {
//     } else {
//       double totalprice = total;
//       dbHelper.buyproductInsert(
//           cp.productId,
//           cp.productName,
//           cp.productCode,
//           cp.price,
//           totalprice,
//           cp.priceMinQuantity,
//           cp.brandname,
//           cp.priceId,
//           cp.cityId,
          
//           numOfItems);

//       // debugPrint(this.widget.data.price);
//       // debugPrint(this.widget.data.productName);
//       // debugPrint(this.widget.data.priceMinQuantity.toString());
//       var caritemList = Provider.of<CartProvider>(context, listen: false);
//       caritemList.buyupdaterecord();
//       // debugPrint(this.widget.numOfItems.toString());
//     }
//   }
  
//   OutlineButton({EdgeInsets padding, RoundedRectangleBorder shape, Function onPressed, Icon child}) {}
// }







import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/config.dart';
import 'package:Kissan/model/ProductLocal.dart';
import 'package:Kissan/utils/constants.dart';
import 'package:Kissan/utils/message_pop.dart';
import 'package:Kissan/widgets/widget_cart_card.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/dataBase.dart';

double total = 0.0;

class BuyCartProduct extends StatefulWidget {
  BuyCartProduct({this.data});
  BuyProductLocal data;

  //int numOfItems = 0;
  //double total = 0.0;

  @override
  _CartProductState createState() => _CartProductState();
}

class _CartProductState extends State<BuyCartProduct> {
  final dbHelper = DBProvider.instance;
  int counter = 0;
  @override
  Widget build(BuildContext context) {
    return Container(
     // elevation: 2.0,
    color: Colors.green,
      margin: new EdgeInsets.symmetric(horizontal: 5.0, vertical: 1.0),
      child: Container(
        decoration: BoxDecoration(color: Color(0xFFe7f2ec),),
        child: makeListTitle(context),
      ),
    );
  }

  ListTile makeListTitle(BuildContext context) => ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 1.0),
        leading: Container(
          height: 150,
          width: 50,
          alignment: Alignment.center,
          child: Image.network(
            Config.imageurl + widget.data.productCode + '.png',
            height: 150,
          ),
        ),
        title: Padding(
          padding: EdgeInsets.all(5),
          child: Text(
            widget.data.productName,
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
        subtitle: Padding(
          padding: EdgeInsets.all(5),
          child: Wrap(
            direction: Axis.vertical,
            children: [
              Text(
                // '${widget.data.price.toString()}',
                '${widget.data.totalPrice.toString()}',
                style: TextStyle(color: Colors.black),
              ),
            ],
          ),
        ),

        // title: Row(
        //     children: <Widget>[
        //       Expanded(child: Padding(
        //         padding: const EdgeInsets.only(left: 10),
        //         child:  Text(
        //     widget.data.productName,
        //     style: TextStyle(color: Colors.green[900], fontWeight: FontWeight.bold,fontSize: 15),
        //   ),
        //       )),
        //       Expanded(child: Padding(
        //         padding: const EdgeInsets.only(left: 5),
        //      child:  Text(
        //         // '${widget.data.price.toString()}',
        //         '${widget.data.totalPrice.toString()}',
        //         style: TextStyle(color: Colors.green[900],fontSize: 15,fontWeight: FontWeight.bold),
        //       ),
        //       )),
        //     ],
        //   ),
        // leading: Container(
        //   height: 150,
        //   width: 50,
        //   alignment: Alignment.center,
        //   child: Image.network(
        //     Config.imageurl + widget.data.productCode + '.png',
        //     height: 150,
        //   ),
        // ),
        // title: Padding(
        //   padding: EdgeInsets.all(5),
        //   child: Text(
        //     widget.data.productName,
        //     style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        //   ),
        // ),
        // subtitle: Padding(
        //   padding: EdgeInsets.all(5),
        //   child: Wrap(
        //     direction: Axis.vertical,
        //     children: [
        //       Text(
        //         // '${widget.data.price.toString()}',
        //         '${widget.data.totalPrice.toString()}',
        //         style: TextStyle(color: Colors.black),
        //       ),
        //     ],
        //   ),
        // ),

        

        trailing: Container(
          color: Colors.white,
          width: 120,
          
          child: Row(
            children: <Widget>[
              buildOutlineButton(
                icon: Icons.remove,
                press: () {
                  if (widget.data.numOfItems > 1) {
                    setState(() {
                      widget.data.numOfItems--;
                      calculatePrice();
                    });
                  } else if (widget.data.numOfItems == 0 ||
                      widget.data.numOfItems == 1) {
                    PopMessage.showMessage(
                        context,
                        'Suyoga',
                        'Do you want to delete this item?',
                        'Yes',
                        () async {
                          final coutnt = await dbHelper.getCount();
                          final SharedPreferences prefs =
                              await SharedPreferences.getInstance();
                          prefs.setInt("Count", coutnt);

                          int id = widget.data.productId;

                          dbHelper.buydelete(id);

                          Navigator.of(context).pop(setState(() {}));
                          var caritemList =
                              Provider.of<CartProvider>(context, listen: false);
                          caritemList.buyupdaterecord();
                          cartcount();
                        },
                        buttonText2: 'No',
                        isconformationDialog: true,
                        onPressed2: () async {
                          final coutnt = await dbHelper.getCount();
                          final SharedPreferences prefs =
                              await SharedPreferences.getInstance();
                          prefs.setInt("Count", coutnt);
                          Navigator.of(context).pop();
                        });
                  }
                },
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: kDefaultPaddin / 2),
                child: Text(
                  // if our item is less  then 10 then  it shows 01 02 like that
                  widget.data.numOfItems.toString().padLeft(1, "0"),
                 // style: Theme.of(context).textTheme.headline6,
                 style: TextStyle(color: Colors.green[900],fontWeight: FontWeight.bold,fontSize: 15),
                ),
              ),
              buildOutlineButton(
                  icon: Icons.add,
                  press: () {
                    setState(() {
                      // this.widget.numOfItems++;
                      widget.data.numOfItems++;
                      // // _addTocart();
                      calculatePrice();
                      // var caritemList = Provider.of<CartProvider>(context, listen: false);
                      // caritemList.updaterecord();
                    });
                  }),
            ],
          ),
        ),
      );

  SizedBox buildOutlineButton({IconData icon, Function press}) {
    return SizedBox(
      width: 35.5,
      height: 30,
      child: FlatButton(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        onPressed: press,
        child: Icon(icon),
      ),
    );
  }

  cartcount() async {
    final coutnt = await dbHelper.getCount();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt("Count", coutnt);
    this.counter = prefs.getInt("Count");
  }

  void calculatePrice() {
    _deleteCart();
    BuyProductLocal cp;
    //int pid = cp.productId;
    cp = this.widget.data;

    // int Quantity = this.widget.numOfItems;
    int Quantity = widget.data.numOfItems;

    //data.price
    // double price = double.parse(cp.price);
    double price = double.parse(this.widget.data.price);
    total = Quantity * price;
    // _addTocart(cp, total, this.widget.numOfItems);
    _addTocart(cp, total, widget.data.numOfItems);
    // widget.data.numOfItems--;
    //delete(pid);
    //insert(produ, total);
  }

  Widget _deleteCart() {
    BuyProductLocal deleteProd;
    deleteProd = this.widget.data;
    int id = deleteProd.productId;
    dbHelper.buydelete(id);
    // dbHelper.dbdelete(dId);
    // Product product;
  }

  Widget _addTocart(cp, total, numOfItems) {
    if (numOfItems == 0) {
    } else {
      double totalprice = total;
      dbHelper.buyproductInsert(
          cp.productId,
          cp.productName,
          cp.productCode,
          cp.price,
          totalprice,
          cp.priceMinQuantity,
          cp.brandname,
          cp.priceId,
          cp.cityId,
          
          numOfItems);

      // debugPrint(this.widget.data.price);
      // debugPrint(this.widget.data.productName);
      // debugPrint(this.widget.data.priceMinQuantity.toString());
      var caritemList = Provider.of<CartProvider>(context, listen: false);
      caritemList.buyupdaterecord();
      // debugPrint(this.widget.numOfItems.toString());
    }
  }
}
