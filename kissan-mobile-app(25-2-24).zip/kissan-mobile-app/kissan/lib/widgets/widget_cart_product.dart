import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/config.dart';
import 'package:Kissan/model/ProductLocal.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/utils/message_pop.dart';
import 'package:shared_preferences/shared_preferences.dart';

double total = 0.0;

class CartProduct extends StatefulWidget {
  CartProduct({this.data});
  ProductLocal data;

  //int numOfItems = 0;
  //double total = 0.0;

  @override
  _CartProductState createState() => _CartProductState();
}

class _CartProductState extends State<CartProduct> {
  final dbHelper = DBProvider.instance;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2.0,
      margin: new EdgeInsets.symmetric(horizontal: 8.0, vertical: 6.0),
      child: Container(
        decoration: BoxDecoration(color: Colors.white),
        child: makeListTitle(context),
      ),
    );
  }

  ListTile makeListTitle(BuildContext context) => ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
        leading: Container(
          height: 150,
          width: 50,
          alignment: Alignment.center,
          child: Image.network(
            Config.imageurl + widget.data.productCode + '.png',
            height: 150,
          ),
        ),
        title: Padding(
          padding: EdgeInsets.all(5),
          child: Text(
            widget.data.productName,
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
        subtitle: Padding(
          padding: EdgeInsets.all(5),
          child: Wrap(
            direction: Axis.vertical,
            children: [
              Text(
                // '${widget.data.price.toString()}',
                '${widget.data.quantity.toString()}',
                style: TextStyle(color: Colors.black),
              ),
            ],
          ),
        ),

        // trailing: Container(
        //   width: 120,
        //   child: PlaceOder(
        //     data: widget.data,
        //     numOfItems: widget.data.numOfItems,
        //   ),
        // ),

        trailing: Container(
          width: 120,
          child: Column(
            children: <Widget>[
              FlatButton(
                onPressed: () {
                  PopMessage.showMessage(
                      context,
                      'Kissan',
                      'Do you want to delete this item?',
                      'Yes',
                      () async {
                        final coutnt = await dbHelper.getCount();
                        final SharedPreferences prefs =
                            await SharedPreferences.getInstance();
                        prefs.setInt("Count", coutnt);

                        int id = widget.data.productId;

                        dbHelper.delete(id);

                        Navigator.of(context).pop(setState(() {}));
                        var caritemList =
                            Provider.of<CartProvider>(context, listen: false);
                        caritemList.updaterecord();
                      },
                      buttonText2: 'No',
                      isconformationDialog: true,
                      onPressed2: () async {
                        final coutnt = await dbHelper.getCount();
                        final SharedPreferences prefs =
                            await SharedPreferences.getInstance();
                        prefs.setInt("Count", coutnt);
                        Navigator.of(context).pop();
                      });
                },
                shape: StadiumBorder(),
                child: Text(
                  "Delete",
                  style: TextStyle(fontSize: 16.0),
                ),
                color: Colors.red,
                textColor: Colors.white,
              ),
            ],
          ),
        ),
      );

  SizedBox buildOutlineButton({IconData icon, Function press}) {
    return SizedBox(
      width: 35.5,
      height: 30,
      child: OutlineButton(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        onPressed: press,
        child: Icon(icon),
      ),
    );
  }

  void calculatePrice() {
    _deleteCart();
    ProductLocal cp;
    //int pid = cp.productId;
    cp = this.widget.data;

    // int Quantity = this.widget.numOfItems;
    int Quantity = widget.data.numOfItems;

    //data.price
    // double price = double.parse(cp.price);
    // double price = double.parse(this.widget.data.price);
    // total = Quantity * price;
    // _addTocart(cp, total, this.widget.numOfItems);
    _addTocart(cp, widget.data.numOfItems);
    // widget.data.numOfItems--;
    //delete(pid);
    //insert(produ, total);
  }

  Widget _deleteCart() {
    ProductLocal deleteProd;
    deleteProd = this.widget.data;
    int id = deleteProd.productId;
    dbHelper.delete(id);
    // dbHelper.dbdelete(dId);
    // Product product;
  }

  Widget _addTocart(cp, numOfItems) {
    if (numOfItems == 0) {
    } else {
      double totalprice = total;
      dbHelper.productInsert(
          cp.productId,
          cp.productName,
          cp.productCode,
          cp.price,
          cp.price,
          cp.priceMinQuantity,
          cp.brandname,
          cp.priceId,
          cp.cityId,
          cp.quantity,
          numOfItems);

      // debugPrint(this.widget.data.price);
      // debugPrint(this.widget.data.productName);
      // debugPrint(this.widget.data.priceMinQuantity.toString());
      var caritemList = Provider.of<CartProvider>(context, listen: false);
      caritemList.updaterecord();
      // debugPrint(this.widget.numOfItems.toString());
    }
  }
  
  OutlineButton({EdgeInsets padding, RoundedRectangleBorder shape, Function onPressed, Icon child}) {}
}
