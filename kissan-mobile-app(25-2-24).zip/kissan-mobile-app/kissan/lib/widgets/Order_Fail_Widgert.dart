import 'package:Kissan/pages/home.dart';
import 'package:flutter/material.dart';

class OrderFailWidget extends StatefulWidget {
  @override
  OrderFailWidgetState createState() => OrderFailWidgetState();
}

class OrderFailWidgetState extends State<OrderFailWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          brightness: Brightness.dark,
          elevation: 0,
          backgroundColor: Colors.green,
          automaticallyImplyLeading: false,
          title: Text(
            'Payment Failed',
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Container(
          margin: EdgeInsets.all(10),
          // child: _listview(context, ordermodel.allOrders),

          child: Center(
            //  margin: EdgeInsets.only(top: 100),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              // mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Container(
                      width: 150,
                      height: 150,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                              begin: Alignment.bottomLeft,
                              end: Alignment.topRight,
                              colors: [
                                Colors.orangeAccent.withOpacity(0.4),
                                Colors.orangeAccent.withOpacity(0.4),
                              ])),
                      child: Icon(
                        Icons.cancel,
                        color: Colors.red,
                        size: 60,
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                Opacity(
                    opacity: 0.6,
                    child: Text(
                      "Your Payment Has Been Falied",
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headline6,
                    )),
                SizedBox(
                  height: 20,
                ),
                FlatButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomePage(),
                      ),
                    );
                  },
                  padding: EdgeInsets.all(10),
                  color: Colors.red,
                  child: Text(
                    "Failed",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                    ),
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
