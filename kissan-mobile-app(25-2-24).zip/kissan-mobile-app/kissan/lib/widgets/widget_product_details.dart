import 'package:Kissan/components/Product_DetailsCart%20_counter.dart';
import 'package:Kissan/config.dart';
import 'package:Kissan/model/product.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/widgets/widget_home_product.dart';

class ProductDetailsWidget extends StatelessWidget {
  ProductDetailsWidget({Key key, this.data}) : super(key: key);

  Product data;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        color: Colors.white,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 40),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                    padding: EdgeInsets.only(left: 20),
                    child: productImage(data, context)),
                SizedBox(
                  height: 10,
                ),
                // Visibility(
                //     visible: data.calculateDiscount() > 0,
                //     child: Align(
                //       alignment: Alignment.topLeft,
                //       child: Container(
                //         padding: EdgeInsets.all(5),
                //         decoration: BoxDecoration(color: Colors.green),
                //         child: Text(
                //           '${data.calculateDiscount()}% OFF',
                //           style: TextStyle(
                //               color: Colors.white, fontWeight: FontWeight.bold),
                //         ),
                //       ),
                //     )),
                SizedBox(
                  height: 5,
                ),
                Text(
                  data.productName,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                      fontSize: 25,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: EdgeInsets.only(top: 3),
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.start,
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(data.quantity.toString()),
                    ],
                  ),
                ),

                Container(
                  child: Row(
                    children: [
                      RichText(
                          text: TextSpan(
                              text: "Brand name : ",
                              style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                              children: <TextSpan>[
                            TextSpan(
                                text: data.brandname,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold)),
                          ])),

                      //Text("product details"),
                    ],
                  ),
                ),

                Container(
                  child: Row(
                    children: [
                      RichText(
                          text: TextSpan(
                              text: "Min quantity  : ",
                              style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                              children: <TextSpan>[
                            TextSpan(
                                text: data.quantity,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold)),
                          ])),
                      //Text("product details"),
                    ],
                  ),
                ),
                Container(
                  height: 20,
                  child: Container(
                    child: RichText(
                      text: TextSpan(
                        text: "Product Description : ",
                        style: TextStyle(
                            color: Colors.red,
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                        children: <TextSpan>[
                          TextSpan(
                              text: data.productDescription,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Divider(
                  color: Colors.redAccent,
                  thickness: 2,
                ),

                Text(
                  "Select Product Quantity",
                  style: TextStyle(
                      color: Colors.green,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: ProductDetailsCart(
                            productdata: data,
                            numOfItems: 0,
                          )),
                    ],
                  ),
                ),
                // ProductFullDetails(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget productImage(Product product, BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 250,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          CircleAvatar(
            radius: 30,
            backgroundColor: Color(0xffE65829).withAlpha(40),
          ),
          Image.network(
            Config.imageurl + product.productCode + '.png',
            fit: BoxFit.fill,
          ),
        ],
      ),
    );
  }
}
