import 'package:Kissan/api_service.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/home.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/widgets/Order_Sucess_Widget.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/PlaceOrder_model.dart';
import 'package:Kissan/pages/checkout_base.dart';
import 'package:provider/provider.dart';
import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/model/TimeSlot_Model.dart';
import 'package:Kissan/utils/form_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Timeslots extends CheckoutBase {
  double totalamt;
  String usermoblie;
  String token;
  CreateOrder shippingaddress;

  Timeslots({
    this.shippingaddress,
    this.totalamt,
    this.usermoblie,
    this.token,
  });
  @override
  _TimeslotsState createState() => _TimeslotsState();
}

class _TimeslotsState extends CheckoutBaseState<Timeslots> {
  TextEditingController textcontroller = new TextEditingController();
  String couponcode;
  String _selectedtimeslot;
  double finalamt;
  double itemscost;
  bool _visible = false;
  bool _visiblily = true;
  APIService apiService;
  double walletbalance = 0;
  double waldiscount = 0;
  List<UserdatafromDB> list = new List();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  bool isCheck = false;
  bool ischecked = true;
  @override
  void initState() {
    super.initState();
    var orderProvider = Provider.of<CartProvider>(context, listen: false);
    orderProvider.timeslots();

    currentPage = 1;
    fetch();
    itemscost = this.widget.totalamt;
    finalamt = this.widget.totalamt;
  }

  fetch() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    walletbalance = prefs.getDouble("Walletamt");
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          print(allRows),
          model = UserdatafromDB(
            row["id"].toString(),
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    print(model.token);
    setState(() {
      build(context);
    });
  }

  // Widget build(BuildContext context) {
  //   return new Consumer<CartProvider>(builder: (context, timeslotmodel, child) {
  //     return timeslotmodel.timeslotlist == null
  //         ? Center(
  //             child: LoginPage(),
  //           )
  //         : _listview(context, timeslotmodel.timeslotlist);

  //     //
  //   });
  // }

  Widget build(BuildContext context) {
    return new Consumer<CartProvider>(builder: (context, timeslotmodel, child) {
      if (timeslotmodel.timeslotlist == null &&
          timeslotmodel.timeslotlist.length == 0) {
        return Center(
          child: Container(
            color: Colors.white,
            child: Text("Loading..."),
          ),
        );
      } else {
        return _listview(context, timeslotmodel.timeslotlist);
      }
    });
  }

  Widget _listview(BuildContext context, List<Timeslot> timeslotlist) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          centerTitle: true,
          title: Text('SUYOGA'),
          backgroundColor: Colors.green,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
        ),
        body: SafeArea(
          child: timeslotwidget(timeslotlist),
        ));
  }

  Widget timeslotwidget(List<Timeslot> timeslotlist) {
    List<String> timeslot = [
      '${timeslotlist[0].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[0].time[0].morningTime}',
      '${timeslotlist[1].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[1].time[0].morningTime}',
      '${timeslotlist[2].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[2].time[0].morningTime}',
      '${timeslotlist[3].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[3].time[0].morningTime}',
      '${timeslotlist[4].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[4].time[0].morningTime}',
    ]; //
    Size size = MediaQuery.of(context).size;
    return Container(
        height: size.height,
        child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.only(left: 1, top: 40, bottom: 3),
            children: <Widget>[
              Center(
                child: Column(
                    //crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        //color: Colors.blue,
                        padding: EdgeInsets.only(left: 1, top: 10, bottom: 3),
                        child: Text(" PICK UP DATE & TIME ",
                            style: TextStyle(
                                color: Colors.red,
                                fontSize: 24,
                                fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                          padding:
                              EdgeInsets.only(left: 10, top: 5, bottom: 3)),
                      DropdownButton(
                        hint: Text(
                          '  Select Pick up Date & Time',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            // background: Paint()..color = Colors.green,
                          ),
                        ), // Not necessary for Option 1
                        value: _selectedtimeslot,
                        iconSize: 30,
                        iconEnabledColor: Colors.green,
                        //isExpanded: true,
                        onChanged: (newValue) {
                          setState(() {
                            _selectedtimeslot = newValue;
                          });
                        },
                        items: timeslot.map((selectedtimeslot) {
                          return DropdownMenuItem(
                            child: new Text(
                              selectedtimeslot,
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                //  background: Paint()..color = Colors.blue,
                              ),
                            ),
                            value: selectedtimeslot,
                          );
                        }).toList(),
                      ),
                      SizedBox(
                        height: size.height * 0.15,
                      ),
                      new Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        color: Colors.grey,
                        child: Padding(
                          padding: EdgeInsets.all(12.0),
                          child: Container(
                              height: 150,
                              width: 500,
                              child: Column(
                                children: [
                                  Text(
                                    "As per market rates price will be increase or decrease ",
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      // background: Paint()..color = Colors.green,
                                    ),
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        " Your Items Cost",
                                        style: TextStyle(
                                            fontSize: 25,
                                            color: Colors.red,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                          '\u20B9' +
                                              ' ' +
                                              "${this.widget.totalamt}" +
                                              "   ",
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20,
                                          )),
                                    ],
                                  ),
                                ],
                              )),
                        ),
                      ),
                      SizedBox(
                        height: size.height * 0.05,
                      ),

                      Divider(
                        color: Colors.green,
                        thickness: 2.0,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          //  Padding(padding: EdgeInsets.all(10)),
                          Text(
                            "   Total Amount :",
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.red,
                                fontWeight: FontWeight.bold),
                          ),
                          Text('$finalamt' + "   ",
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              )),
                        ],
                      ),
                      SizedBox(
                        height: size.height * 0.02,
                      ),

                      // FormHelper.saveButton('Next', () {
                      //   // _myActivityResult = _myActivity;
                      //   if (_selectedLocation != null) {
                      //     //  _myActivityResult = _myActivity;
                      //     var orderProvider =
                      //         Provider.of<CartProvider>(context, listen: false);
                      //     CreateOrder setTimeslot = new CreateOrder();
                      //     setTimeslot.timeSlot = _selectedLocation;
                      //     setTimeslot.status = "Order Placed Successfully";
                      //     setTimeslot.totalAmount = totalamt;
                      //     setTimeslot.deliveryCharges = deliverycharges;
                      //     orderProvider.placetimeslotProcess(setTimeslot);
                      //     print(_selectedLocation);
                      //     Navigator.push(
                      //         context,
                      //         MaterialPageRoute(
                      //           builder: (context) => PaymentScreen(),
                      //         ));
                      //   } else {
                      //     FormHelper.showMessage(context, "SUYOGA",
                      //         "Select Delivery Date and Time", "OK", () {
                      //       Navigator.of(context).pop();
                      //     });
                      //   }
                      // }),
                    ]),
              ),
              Container(
                child: Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: Container(
                      child: Column(
                    children: [
                      // Divider(
                      //   height: size.width,
                      // ),
                      Container(
                        color: Colors.white,
                        width: MediaQuery.of(context).size.width,
                        height: 100,
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                FlatButton(
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Place Order',
                                        style: TextStyle(
                                            fontSize: 25, color: Colors.black),
                                      ),
                                      Icon(Icons.chevron_right,
                                          size: 40, color: Colors.black),
                                    ],
                                  ),
                                  onPressed: () {
                                    if (_selectedtimeslot != null &&
                                        finalamt != 0) {
                                      _showDialog();
                                    } else {
                                      FormHelper.showMessage(
                                          context,
                                          "SUYOGA",
                                          "Select Delivery Date and Time",
                                          "OK", () {
                                        Navigator.of(context).pop();
                                      });
                                    }
                                  },
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 40, vertical: 13),
                                  color: Colors.green,
                                  shape: StadiumBorder(),
                                ),
                              ]),
                        ),
                      ),
                    ],
                  )),
                ),
              )
            ]));
  }

  void _showDialog() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("Kissan"),
          content: new Text("Are you sure you want to Place Order"),
          
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
             FlatButton(
              padding: EdgeInsets.all(15),
                  color: Colors.red,
                  child: Text("DisAgree"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
             FlatButton(
              padding: EdgeInsets.all(15),
                  color: Colors.green,
                  child: Text("Agree"),
              onPressed: () {
                var orderProvider =
                    Provider.of<CartProvider>(context, listen: false);
                CreateOrder setTimeslot = new CreateOrder();
                setTimeslot.timeSlot = _selectedtimeslot;
                setTimeslot.status = "Order Placed Successfully";
                setTimeslot.totalAmount = itemscost;
                setTimeslot.paymentMethod = "COD";
                setTimeslot.paymentMethodTitle = "COD";
                setTimeslot.transactionId = "Kissan Place order";
                orderProvider.placetimeslotProcess(setTimeslot);
                orderProvider.addresstProcess(this.widget.shippingaddress);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => OrderSucessWidgetbyWallet(),
                    ));
              },
            ),
          ],
        );
      },
    );
  }
}
// Future<PromocodeModel> promocode() async {
//   PromocodeModel data;
//   // bool ret = false;
//   String token = model.token;
//   try {
//     // String url = Config.url + Config.promocode;
//     //  print(url);

//     var response = await Dio().post("url",
//         data: {
//           "userName": model.mobileNumber,
//           "promoCode": textcontroller.text,
//           "totalAmount": this.widget.totalamt,
//         },
//         options: new Options(headers: {
//           HttpHeaders.contentTypeHeader: 'application/json',
//           HttpHeaders.authorizationHeader: 'Bearer $token',
//         }));
//     if (response.statusCode == 200) {
//       //   print(response.data);
//       data = PromocodeModel.fromJson(response.data);
//       // return ret = true;
//     }
//     // print(token);
//   } on DioError catch (e) {
//     data = PromocodeModel.fromJson(e.response.data);
//     print(e.response);
//     //  return ret = false;
//   }

//   return data;
// }

class AppCheckbox extends StatelessWidget {
  final bool value;
  final bool disabled;
  final double size;
  final ValueChanged<bool> onChanged;

  const AppCheckbox({
    Key key,
    this.size = 24,
    this.value = false,
    this.disabled = true,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final backColor = Colors.transparent;
    final checkColor = Colors.red;

    return Theme(
      data: Theme.of(context).copyWith(
        disabledColor: Colors.green,
        unselectedWidgetColor: Colors.blue,
      ),
      child: SizedBox(
        width: size,
        height: size,
        child: Container(
          decoration: BoxDecoration(
            color: backColor,
            borderRadius: BorderRadius.circular(4),
          ),
          clipBehavior: Clip.hardEdge,
          child: Transform.scale(
            scale: size / Checkbox.width,
            child: Checkbox(
              hoverColor: Colors.transparent,
              focusColor: Colors.transparent,
              activeColor: Colors.red,
              checkColor: checkColor,
              value: value,
              onChanged: disabled
                  ? null
                  : (value) {
                      onChanged(value);
                    },
            ),
          ),
        ),
      ),
    );
  }
}
