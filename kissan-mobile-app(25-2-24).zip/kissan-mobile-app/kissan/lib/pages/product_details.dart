import 'package:flutter/material.dart';
import 'package:Kissan/model/product.dart';
import 'package:Kissan/pages/base_page.dart';
import 'package:Kissan/widgets/widget_product_details.dart';

class ProductDetails extends BasePage {
  ProductDetails({
    Key key,
    this.product,
  }) : super(key: key);

  Product product;

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends BasePageState<ProductDetails> {
  @override
  Widget pageUI() {
    return ProductDetailsWidget(
      data: this.widget.product,
    );
  }
}
