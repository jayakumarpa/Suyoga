import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/userprofile.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/api_service.dart';
import 'package:Kissan/model/Update_mobileNumber_model.dart';
import 'package:Kissan/pages/Update_MobileOTP.dart';
import 'package:Kissan/utils/ProgressHUD.dart';
import 'package:Kissan/utils/form_helper.dart';

class UpdateMoblieNumber extends StatefulWidget {
  @override
  _UpdateMoblieNumberState createState() => _UpdateMoblieNumberState();
}

class _UpdateMoblieNumberState extends State<UpdateMoblieNumber> {
  //String username;
  APIService apiService;
  bool isApiCallProcess = false;
  UpdateMoblie updateMoblie;
  GlobalKey<FormState> globalFormKey = GlobalKey<FormState>();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  List<UserdatafromDB> list = new List();

  @override
  void initState() {
    super.initState();
    apiService = new APIService();
    updateMoblie = new UpdateMoblie();
    fetch();
  }

  fetch() async {
    final coutnt = await dbHelper.getCount();
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"].toString(),
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
      child: _uiSetup(context),
      inAsyncCall: isApiCallProcess,
      opacity: 0.3,
    );
  }

  Widget _uiSetup(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Stack(
      children: [
        //BackgroundImage(image: 'assets/images/grocery.jpg'),
        Scaffold(
          backgroundColor: Colors.blueGrey[100],
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => userprofile(profilemodel: model),
                  ),
                );
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.black,
              ),
            ),
            title: Text(
              'Update Mobile Number',
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 24,
                  fontWeight: FontWeight.bold),
            ),
            centerTitle: true,
          ),
          body: Column(
            children: [
              Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: size.height * 0.1,
                    ),
                    Container(
                      width: size.width * 0.8,
                      child: Text(
                        'Enter your Mobile Number we will Update Your Number',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 22),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 10,
                      ),
                      child: FormHelper.textInput(
                        context,
                        updateMoblie.oldMobileNumber = model.mobileNumber,
                        (value) => {this.updateMoblie.oldMobileNumber = value},
                        onValidate: (value) => value.length < 10
                            ? "Please Enter Your Old Mobile Number"
                            : null,
                        hintText: "Enter Your Old Mobile Number",
                        hintStyle: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 20),
                        prefixIcon: Icon(
                          Icons.phone,
                          color: Colors.black,
                          size: 30,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 10,
                      ),
                      child: FormHelper.textInput(
                        context,
                        updateMoblie.newMobileNumber,
                        (value) => {this.updateMoblie.newMobileNumber = value},
                        onValidate: (value) => value.length < 10
                            ? "Please Enter Your New Mobile Number"
                            : null,
                        hintText: "Enter Your New Mobile Number",
                        hintStyle: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 20),
                        prefixIcon: Icon(
                          Icons.phone,
                          color: Colors.black,
                          size: 30,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    FlatButton(
                      padding:
                          EdgeInsets.symmetric(vertical: 18, horizontal: 110),
                      onPressed: () {
                        if (updateMoblie.oldMobileNumber.isNotEmpty &&
                            updateMoblie.newMobileNumber.isNotEmpty &&
                            updateMoblie.newMobileNumber.length >= 10) {
                          setState(() {
                            isApiCallProcess = true;
                          });
                          apiService
                              .loginWithOTP(updateMoblie.oldMobileNumber)
                              .then((value) => {
                                    if (value)
                                      {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => UpdateMobOTP(
                                                user: updateMoblie),
                                          ),
                                        ),
                                      }
                                    else
                                      {}
                                  });
                        }
                      },
                      child: Text(
                        "Continue",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                        ),
                      ),
                      color: Colors.green,
                      shape: StadiumBorder(),
                    ),
                  ],
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
