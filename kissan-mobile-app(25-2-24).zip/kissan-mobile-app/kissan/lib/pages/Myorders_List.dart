import 'package:Kissan/config.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/Report_issue.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/api_service.dart';
import 'package:Kissan/model/Order_details_Model.dart';
import 'package:Kissan/pages/base_page.dart';
import 'package:Kissan/widgets/widget_checkpoint.dart';

class MyordersProductList extends BasePage {
  String mobileNumber;

  Key key;
  MyordersProductList({
    this.mobileNumber,
    this.key,
    OrderModel orderModels,
  }) : super(key: key);
  @override
  _MyordersProductListState createState() => _MyordersProductListState();
}

class _MyordersProductListState extends BasePageState<MyordersProductList> {
  APIService apiService;
  bool isCheck = false;
  final dbHelper = DBProvider.instance;
  UserdatafromDB usermodel;
  String firstuserName;
  @override
  void initState() {
    super.initState();
    apiService = new APIService();
    fetch();
  }

  @override
  Widget pageUI() {
    List<OrderModel> ordermodel;
    return orderDetailsUI(ordermodel);
  }

  fetch() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          usermodel = UserdatafromDB(
            row["id"],
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          firstuserName = usermodel.name,
          list.add(usermodel)
        });
  }

  Widget orderDetailsUI(List<OrderModel> model) {
    final OrderModel orderModel = ModalRoute.of(context).settings.arguments;

    return SingleChildScrollView(
      padding: EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            "Order Number :"
            "${orderModel.invoiceNumber}",
            style: Theme.of(context).textTheme.labelText,
          ),
          Text(
            "Date :"
            "${orderModel.orderdate}",
            style: Theme.of(context).textTheme.labelText,
          ),
          Divider(
            color: Colors.green[300],
            thickness: 2.0,
          ),
          Text(
            "Pick up Address",
            style: Theme.of(context).textTheme.labelHeading,
          ),
          Text(
            "${orderModel.address}",
            style: Theme.of(context).textTheme.labelText,
          ),
          Text(
            "${orderModel.city}",
            style: Theme.of(context).textTheme.labelText,
          ),
          Text(
            "${orderModel.state}",
            style: Theme.of(context).textTheme.labelText,
          ),
          Text(
            "${orderModel.pincode}",
            style: Theme.of(context).textTheme.labelText,
          ),
          SizedBox(
            height: 20,
          ),
          Text(
            "Payment Method",
            style: Theme.of(context).textTheme.labelHeading,
          ),
          Text(
            "${orderModel.paymentMethod}",
            style: Theme.of(context).textTheme.labelText,
          ),
          if (orderModel.invoiceStatus == "Delivered")
            Padding(
                padding: const EdgeInsets.only(left: 260),
                child: FlatButton(
                  shape: RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(16.0)),
                  color: Colors.redAccent,
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ReportIssue(
                            username: this.firstuserName,
                            mobileNumber: this.widget.mobileNumber,
                            orderNumber: "${orderModel.invoiceNumber}"),
                      ),
                    );
                  },
                  child: Text(
                    "Report Issue",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                )),
          Divider(
            thickness: 1.5,
            color: Colors.green[300],
          ),
          CheckPoints(
            checkedTill: 0,
            checkPointFilledColor: Colors.redAccent,
            checkPoints: ["Processing", "Shipping", "Delivered"],
          ),
          Divider(
            color: Colors.grey,
          ),
          listOrderItems(model),
          Divider(
            color: Colors.green[900],
            thickness: 2.0,
          ),
          itemsTotal(
            "Items Total",
            "${orderModel.totalprice}",
          ),
          SizedBox(
            height: 30,
          ),
        ],
      ),
    );
  }

  Widget listOrderItems(List<OrderModel> orderModel) {
    final OrderModel orderModel = ModalRoute.of(context).settings.arguments;

    return ListView.builder(
      itemCount: orderModel.productList.length,
      physics: ScrollPhysics(),
      shrinkWrap: true,
      itemBuilder: (context, index) {
        return productslitsItems(orderModel.productList[index]);
      },
    );
  }

  Widget productslitsItems(ProductLists productLists) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ConstrainedBox(
              constraints: BoxConstraints(
                minWidth: 44,
                minHeight: 44,
                maxWidth: 44,
                maxHeight: 44,
              ),
              child: Image.network(
                Config.imageurl + productLists.productCode + '.png',
                fit: BoxFit.fill,
              ),
            ),
            
            SizedBox(
              width: 20,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  productLists.productName,
                  style: Theme.of(context).textTheme.productnameText,
                ),
                new Text(
                  "Qty :" + "${productLists.priceMinQuantity}",
                ),
              ],
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              productLists.price,
              style: Theme.of(context).textTheme.productnameText,
            ),
          ],
        )
      ],
    );
  }

  Widget itemsTotal(String label, String value, {TextStyle textStyle}) {
    return ListTile(
      dense: true,
      visualDensity: VisualDensity(
        horizontal: 0,
        vertical: -4,
      ),
      contentPadding: EdgeInsets.fromLTRB(2, -10, 2, -10),
      title: new Text(
        label,
        style: Theme.of(context).textTheme.labelHeading,
      ),
      trailing: new Text(
        "$value",
        style: Theme.of(context).textTheme.labelText,
      ),
    );
  }
}

extension CustomStyles on TextTheme {
  TextStyle get labelHeading {
    return TextStyle(
        fontSize: 16, color: Colors.redAccent, fontWeight: FontWeight.bold);
  }

  TextStyle get labelText {
    return TextStyle(
        fontSize: 16, color: Colors.black, fontWeight: FontWeight.bold);
  }

  TextStyle get productnameText {
    return TextStyle(
        fontSize: 14, color: Colors.black, fontWeight: FontWeight.bold);
  }
}
