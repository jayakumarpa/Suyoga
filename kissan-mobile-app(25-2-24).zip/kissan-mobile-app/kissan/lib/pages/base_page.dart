import 'package:Kissan/pages/Buy_cartPage.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/widgets/widget_cart_card.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BasePage extends StatefulWidget {
  BasePage({Key key}) : super(key: key);

  @override
  BasePageState createState() => BasePageState();
}

class BasePageState<T extends BasePage> extends State<T> {
  bool isApiCallProcess = false;
  List list = [];
  int counter = 0;
  final dbHelper = DBProvider.instance;

  cartcount() async {
    final coutnt = await dbHelper.getCount();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt("Count", coutnt);
    counter = prefs.getInt("Count");
  }

  void initState() {
    setState(() {
      cartcount();
      _buildAppBar();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: ModalProgressHUD(
        inAsyncCall: isApiCallProcess,
        child: pageUI(),
        opacity: 0.3,
      ),
    );
  }

  Widget pageUI() {
    return null;
  }

  Widget _buildAppBar() {
    return AppBar(
      centerTitle: true,
      brightness: Brightness.dark,
      elevation: 0,
      backgroundColor: Colors.green,
      automaticallyImplyLeading: false,
      leading: IconButton(
        onPressed: () async {
          final SharedPreferences prefs = await SharedPreferences.getInstance();
          int counter = prefs.getInt("Count");
          Navigator.of(context).pop();
        },
        icon: Icon(
          Icons.arrow_back_ios,
          color: Colors.white,
        ),
      ),
      title: Text(
        'KISSAN',
        style: TextStyle(color: Colors.white),
      ),
      actions: [
        Icon(
          Icons.notifications_none,
          color: Colors.white,
        ),
        SizedBox(
          width: 10,
        ),
        Container(
          // padding: EdgeInsets.only(right: 10),
          padding: EdgeInsets.only(top: 10),
          child: new Stack(
            children: <Widget>[
              new IconButton(
                  // icon: Icon(Icons.notifications),
                  icon: Icon(Icons.shopping_cart),
                  onPressed: () async {
                    final SharedPreferences prefs =
                        await SharedPreferences.getInstance();
                    counter = prefs.getInt("Count");
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => CartPageIconPress()));
                  }),
              counter != 0
                  ? new Positioned(
                      right: 4,
                      top: 6,
                      child: new Container(
                        padding: EdgeInsets.all(2),
                        decoration: new BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 14,
                          minHeight: 14,
                        ),
                        child: Text(
                          '$counter',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : new Positioned(
                      right: 4,
                      top: 6,
                      child: new Container(
                        padding: EdgeInsets.all(2),
                        decoration: new BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 14,
                          minHeight: 14,
                        ),
                        child: Text(
                          '$counter',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
            ],
          ),
        ),
      ],
    );
  }
}

class BuyBasePage extends StatefulWidget {
  BuyBasePage({Key key}) : super(key: key);

  @override
  BuyBasePageState createState() => BuyBasePageState();
}

class BuyBasePageState<T extends BuyBasePage> extends State<T> {
  bool isApiCallProcess = false;
  List list = [];
  int counter = 0;
  final dbHelper = DBProvider.instance;

  cartcount() async {
    final coutnt = await dbHelper.getCount();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt("Count", coutnt);
    counter = prefs.getInt("Count");
  }

  void initState() {
    setState(() {
      cartcount();
      _buildAppBar();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: ModalProgressHUD(
        inAsyncCall: isApiCallProcess,
        child: buypageUI(),
        opacity: 0.3,
      ),
    );
  }

  Widget buypageUI() {
    return null;
  }

  Widget _buildAppBar() {
    return AppBar(
      centerTitle: true,
      brightness: Brightness.dark,
      elevation: 0,
      backgroundColor: Colors.green,
      automaticallyImplyLeading: false,
      leading: IconButton(
        onPressed: () async {
          final SharedPreferences prefs = await SharedPreferences.getInstance();
          int counter = prefs.getInt("Count");
          Navigator.of(context).pop();
        },
        icon: Icon(
          Icons.arrow_back_ios,
          color: Colors.white,
        ),
      ),
      title: Text(
        'KISSAN',
        style: TextStyle(color: Colors.white),
      ),
      actions: [
        Icon(
          Icons.notifications_none,
          color: Colors.white,
        ),
        SizedBox(
          width: 10,
        ),
        Container(
          // padding: EdgeInsets.only(right: 10),
          padding: EdgeInsets.only(top: 10),
          child: new Stack(
            children: <Widget>[
              new IconButton(
                  // icon: Icon(Icons.notifications),
                  icon: Icon(Icons.shopping_cart),
                  onPressed: () async {
                    final SharedPreferences prefs =
                        await SharedPreferences.getInstance();
                    counter = prefs.getInt("Count");
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => BuyCartPage()));
                  }),
              counter != 0
                  ? new Positioned(
                      right: 4,
                      top: 6,
                      child: new Container(
                        padding: EdgeInsets.all(2),
                        decoration: new BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 14,
                          minHeight: 14,
                        ),
                        child: Text(
                          '$counter',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : new Positioned(
                      right: 4,
                      top: 6,
                      child: new Container(
                        padding: EdgeInsets.all(2),
                        decoration: new BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 14,
                          minHeight: 14,
                        ),
                        child: Text(
                          '$counter',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
            ],
          ),
        ),
      ],
    );
  }
}
