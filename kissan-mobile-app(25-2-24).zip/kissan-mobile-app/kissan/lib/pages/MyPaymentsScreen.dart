import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/model/MyPayments_Model.dart';

class Mypayments extends StatefulWidget {
  @override
  _MypaymentsState createState() => _MypaymentsState();
}

class _MypaymentsState extends State<Mypayments> {
  @override
  void initState() {
    super.initState();
    var orderProvider = Provider.of<CartProvider>(context, listen: false);
    orderProvider.fetchMypayments();
  }

  @override
  Widget build(BuildContext context) {
    return new Consumer<CartProvider>(builder: (context, ordermodel, child) {
      if (ordermodel.paymentslist != null &&
          ordermodel.paymentslist.length > 0) {
        _listview(context, ordermodel.paymentslist);
      }
      return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          brightness: Brightness.dark,
          elevation: 0,
          backgroundColor: Colors.green,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
          title: Text(
            'My Payments',
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Container(
          margin: EdgeInsets.all(10),
          child: _listview(context, ordermodel.paymentslist),
        ),
      );
    });
  }

  Widget _listview(BuildContext context, List<MyPaymentsModel> paymentslist) {
    return ListView(
      children: [
        ListView.builder(
            itemCount: paymentslist.length,
            physics: ScrollPhysics(),
            padding: EdgeInsets.all(8),
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(16.0)),
                child: Column(
                  children: <Widget>[
                    Text(
                      "Payment Type :" +
                          "${paymentslist[index].transactionType}",
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    Divider(color: Colors.red),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        iconData(
                            Icon(
                              Icons.edit,
                              color: Colors.red,
                              size: 14,
                            ),
                            Text(
                              "Order Number :",
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )),
                        Text("${paymentslist[index].orderNumber}",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            )),
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        iconData(
                            Icon(
                              Icons.date_range,
                              color: Colors.red,
                              size: 12,
                            ),
                            Text(
                              "Order Date :",
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )),
                        Text("${paymentslist[index].createdDate}",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            )),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        iconData(
                            Icon(
                              Icons.date_range,
                              color: Colors.red,
                              size: 12,
                            ),
                            Text(
                              "Transaction Id :",
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )),
                        Text("${paymentslist[index].transactionId}",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            )),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        iconData(
                            Icon(
                              Icons.monetization_on_outlined,
                              color: Colors.red,
                              size: 14,
                            ),
                            Text(
                              "Total Price :",
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )),
                        Text("${paymentslist[index].totalPrice}",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            )),
                      ],
                    ),
                  ],
                ),
              );
            })
      ],
    );
  }

  Widget iconData(Icon iconData, Text textdata) {
    return Row(
      children: <Widget>[
        iconData,
        SizedBox(
          width: 10,
        ),
        textdata,
      ],
    );
  }

  Widget flatButton(
    Widget iconText,
    Color color,
    Function onPressed,
  ) {
    return FlatButton(
      child: iconText,
      onPressed: onPressed,
      padding: EdgeInsets.all(5),
      color: color,
      shape: StadiumBorder(),
    );
  }

  Widget orderStatus(String status) {
    Icon icon;
    Color color;

    if (status == "P" || status == "Processing" || status == "On-Hold") {
      icon = Icon(
        Icons.timer,
        color: Colors.orange,
      );
      color = Colors.orange;
    } else if (status == "D" || status == "Deliverd") {
      icon = Icon(
        Icons.check,
        color: Colors.green,
      );
      color = Colors.green;
    } else if (status == "C" || status == "Cancelled") {
      icon = Icon(
        Icons.clear,
        color: Colors.redAccent,
      );
      color = Colors.redAccent;
    } else {
      icon = Icon(
        Icons.clear,
        color: Colors.redAccent,
      );
      color = Colors.redAccent;
    }
    return iconData(
        icon,
        Text(
          "Order Status :$status",
          style: TextStyle(
            color: color,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ));
  }
}
