import 'dart:async';

import 'package:Kissan/widgets/widget_product_card.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:Kissan/pages/base_page.dart';
import 'package:Kissan/provider/product_provider.dart';
import 'package:Kissan/model/product.dart';

class ProductPage extends BasePage {
  ProductPage({Key key, this.categoryId}) : super(key: key);

  int categoryId;

  @override
  _ProductPageState createState() => _ProductPageState();
}

class _ProductPageState extends BasePageState<ProductPage> {
  int _pageNumber = 1;
  ScrollController _scrollController = new ScrollController();

  final _searchQuery = new TextEditingController();
  Timer _debounds;

  final _sortByOptions = [
    SortBy('papularity', 'papularity', 'asc'),
    SortBy('modified', 'Latest', 'asc'),
    SortBy('price', 'Price: High to Low', 'desc'),
    SortBy('price', 'Price: Low to High', 'asc')
  ];
  @override
  void initState() {
    var productList = Provider.of<ProductProvider>(context, listen: false);
    productList.resetStreams();
    productList.setLoadingStatus(LoadMoreStatus.INITIAL);
    productList.fetchProduct(_pageNumber, categoryId: this.widget.categoryId);
    // _scrollController.addListener(() {
    //   if (_scrollController.position.pixels ==
    //       _scrollController.position.maxScrollExtent) {
    //     productList.setLoadingStatus(LoadMoreStatus.LOADING);
    //     productList.fetchProduct(++_pageNumber,
    //         categoryId: this.widget.categoryId);
    //   }
    // });
    _searchQuery.addListener(_onSearchChange);
    super.initState();
  }

  _onSearchChange() {
    var productList = Provider.of<ProductProvider>(context, listen: false);
    if (_debounds?.isActive ?? false) _debounds.cancel();
    _debounds = Timer(const Duration(milliseconds: 500), () {
      if (_searchQuery.text != null && _searchQuery.text.isNotEmpty) {
        //productList.setLoadingStatus(LoadMoreStatus.INITIAL);
        productList.resetStreams();
        //  productList.fetchSearchProduct(_searchQuery.text);
      } else {
        productList.resetStreams();
        productList.setLoadingStatus(LoadMoreStatus.INITIAL);
        productList.fetchProduct(_pageNumber,
            categoryId: this.widget.categoryId);
      }
    });
  }

  @override
  Widget pageUI() {
    return _productList();
  }

  Widget _productList() {
    return new Consumer<ProductProvider>(builder: (
      BuildContext context,
      productsModel,
      child,
    ) {
      if (productsModel.allProducts != null &&
          productsModel.allProducts.length > 0 &&
          productsModel.getLoadMoreStatus() != LoadMoreStatus.INITIAL) {
        return _buildProductList(productsModel.allProducts,
            productsModel.getLoadMoreStatus() == LoadMoreStatus.LOADING);
      }
      return Center(
        child: CircularProgressIndicator(),
      );
    });
  }

  Widget _buildProductList(List<Product> items, bool isLoadMore) {
    return Column(
      children: [
        Flexible(
          child: ListView(
            shrinkWrap: true,
            controller: _scrollController,
            //crossAxisCount: 2,
            physics: AlwaysScrollableScrollPhysics(),
            scrollDirection: Axis.vertical,
            reverse: false,
            children: items.map((Product item) {
              return ProductCard(data: item);
            }).toList(),
          ),
        ),
        Visibility(
          child: Container(
            padding: EdgeInsets.all(5),
            height: 35.0,
            width: 35.0,
            child: CircularProgressIndicator(),
          ),
          visible: isLoadMore,
        ),
      ],
    );
  }

  Widget _productFilter() {
    return Container(
      height: 51,
      margin: EdgeInsets.fromLTRB(10, 10, 10, 5),
      child: Row(
        children: [
          Flexible(
            child: TextField(
              controller: _searchQuery,
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: "Search",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15.0),
                  borderSide: BorderSide.none,
                ),
                fillColor: Color(0xffe6e6e6c),
                filled: true,
              ),
            ),
          ),
          SizedBox(
            width: 15,
          ),
          Container(
            decoration: BoxDecoration(
              color: Color(0xffe6e6ec),
              borderRadius: BorderRadius.circular(9.0),
            ),
            child: PopupMenuButton(
              onSelected: (sortBy) {
                var productList =
                    Provider.of<ProductProvider>(context, listen: false);
                productList.resetStreams();
                productList.setSortOrder(sortBy);
                productList.fetchProduct(_pageNumber,
                    categoryId: this.widget.categoryId);
              },
              itemBuilder: (BuildContext context) {
                return _sortByOptions.map((item) {
                  return PopupMenuItem(
                      value: item,
                      child: Container(
                        child: Text(item.text),
                      ));
                }).toList();
              },
              icon: Icon(Icons.tune),
            ),
          )
        ],
      ),
    );
  }
}
