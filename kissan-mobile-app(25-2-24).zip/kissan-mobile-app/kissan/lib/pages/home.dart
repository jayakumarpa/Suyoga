import 'package:Kissan/pages/Buy_cartPage.dart';
import 'package:Kissan/pages/Wallet_page.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/widgets/widget_cart_card.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/widgets/widget_Account_Page.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dashbord_page.dart';

class HomePage extends StatefulWidget {
  int index;
  int ccount;
   String location;
  HomePage({Key key, this.index, this.location, this.ccount});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int counter = 0;
  int _index;
  bool isenableappBar = true;
  final dbHelper = DBProvider.instance;

  List<Widget> _widgetList = [
    DashBordPage(),
    BuyCartPage(),
    WalletUIscreen(),
    AccountTab()
  ];
   int _selectedIndex = 0;
    final PageController _pageController = PageController();
 String mySelection;
 
  void initState() {
    cartcount();
    super.initState();
    if (this.widget.index == 1) {
      _index = 1;
      this.isenableappBar = false;
      if (this.widget.ccount == null) {
        this.counter = this.widget.ccount = 0;
      }
      this.counter = this.widget.ccount;
    }
    if (this.widget.index == 2) {
      
      if (this.widget.ccount == null) {
        this.counter = this.widget.ccount = 0;
      }
      _index = 2;
      this.counter = this.widget.ccount;
    }
    if (this.widget.index == 3) {
      _index = 3;
      if (this.widget.ccount == null) {
        this.counter = this.widget.ccount = 0;
      }
     this.counter = this.widget.ccount;
    }
     if (this.widget.index == 4) {
      _index = 4;
      if (this.widget.ccount == null) {
        this.counter = this.widget.ccount = 0;
      }
      this.counter = this.widget.ccount;
    }
    if (this.widget.index == null) {
      _index = 0;
      this.counter = this.widget.ccount;
    } else {
      if (this.widget.ccount == null && this.widget.index == null) {
         this.widget.ccount = 0;
        this.counter = this.widget.ccount = 0;
      }

      this.counter = this.widget.ccount;
    }
  }
@override
  void dispose() {
    super.dispose();
  }
  cartcount() async {
    final coutnt = await dbHelper.getCount();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setInt("Count", coutnt);
    this.widget.ccount = prefs.getInt("Count");
    this.counter = prefs.getInt("Count");
    _buildAppBar(this.isenableappBar, this.widget.location);
    if (this.widget.ccount == null) {
      this.widget.ccount = 0;
    }
  }
    Future<bool> _onbackpress() {
    if (this.isenableappBar == true) {
      return showDialog(
          context: context,
          builder: (context) => AlertDialog(
                title: Text(
                  "Do you want to close app",
                ),
                actions: <Widget>[
                  FlatButton(
                      onPressed: () {
                        Navigator.pop(context, false);
                      },
                      child: Text("No")),
                  FlatButton(
                      onPressed: () {
                        SystemChannels.platform
                            .invokeMethod('SystemNavigator.pop');
                        // Navigator.pop(context, true);
                      },
                      child: Text("Yes"))
                ],
              ));
    } else {
      return Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HomePage(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    
      return WillPopScope(
        child: Scaffold(
            appBar: _buildAppBar(this.isenableappBar, this.widget.location),
           
      //drawer: DrawerWidget(),
       bottomNavigationBar: Container(
       decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(50)),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: Colors.black,
                      // blurRadius: 10,
                    ),
                  ],
                ),
      child: BottomNavigationBar(
        currentIndex: _selectedIndex,
                  onTap: _onItemTapped,
                  backgroundColor: Colors.white,
                  items: [
        
          BottomNavigationBarItem(
              backgroundColor: Colors.blueGrey[200],
              icon: Icon(
                Icons.home,
              ),
              label: "Home",
              
              ),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.shopping_cart,
              ),
              label: 
                'My Cart',
              
              ),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.account_balance_wallet,
              ),
            label:
                'Wallet',
                
              ),
          BottomNavigationBarItem(
              icon: Icon(
                Icons.account_box,
              ),
              label: 
                "Account"
                
              ),
        ],
        selectedItemColor: Colors.red,
        unselectedItemColor: Colors.green[900],
        type: BottomNavigationBarType.shifting,
        
      ),
       ),
      body: PageView(
              controller: _pageController,
              onPageChanged: (index) {
                mySelection = this.widget.location;
                setState(() => _selectedIndex = index);
              },
              children: [
                _widgetList[_index],
              ],
            ),
    ),
     onWillPop: _onbackpress);
  }
   void _onItemTapped(int index) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      this._selectedIndex = index;
      this.widget.index = index;
      if (this.widget.index == 0) {
        this.isenableappBar = true;
        this.widget.location = prefs.getString('Location');
        mySelection = this.widget.location;

        // print(mySelection);
        //   _buildAppBar(true, this.widget.location);
      } else {
        this.isenableappBar = false;
      }
      //
      //using this page controller you can make beautiful animation effects
      _pageController.animateToPage(_selectedIndex,
          duration: Duration(milliseconds: 2000), curve: Curves.easeInOut);
    });

    final coutnt = await dbHelper.getCount();
    
    prefs.setInt("Count", coutnt);
    counter = prefs.getInt("Count");
    setState(() {
            _index = index;
            // if (_index == 3) {
            //   Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //       builder: (context) => AccountTab(),
            //     ),
            //   );
            // }
          });
  }

 Widget _buildAppBar(bool isenabled, String location) {
   if (isenabled)
      return AppBar(
        title: Text(
          'Kissan',
          style: TextStyle(color: Colors.black),
        ),
        toolbarHeight: 50.0,
        centerTitle: true,
        brightness: Brightness.dark,
        elevation: 0,
        backgroundColor: Colors.green,

        automaticallyImplyLeading: false,
      );
 }
  }
