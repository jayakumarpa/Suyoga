import 'package:Kissan/widgets/Buy_Widget_Productdetails.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/product.dart';
import 'package:Kissan/pages/base_page.dart';

class BuyProductDetails extends BuyBasePage {
  BuyProductDetails({Key key, this.product}) : super(key: key);

  Product product;

  @override
  _BuyProductDetailsState createState() => _BuyProductDetailsState();
}

class _BuyProductDetailsState extends BuyBasePageState<BuyProductDetails> {
  @override
  Widget buypageUI() {
    return BuyProductDetailsWidget(
      data: this.widget.product,
    );
  }
}
