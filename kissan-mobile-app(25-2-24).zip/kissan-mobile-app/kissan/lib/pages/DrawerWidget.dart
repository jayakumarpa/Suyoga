import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/home.dart';
import 'package:Kissan/pages/loggin.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/widgets/widget_home_category.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DrawerWidget extends StatefulWidget {
  const DrawerWidget({Key key}) : super(key: key);

  @override
  _DrawerWidgetState createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  List<UserdatafromDB> list = new List();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  @override
  void initState() {
    fetch();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250,
      child: gridHeader(),
      decoration: new BoxDecoration(
        color: Colors.white,
      ),
    );
  }

  fetch() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          print(allRows),
          // model = UserdatafromDB(
          //   row["id"].toString(),
          //   row["firstName"],
          //   row["lastName"],
          //   row["address1"],
          //   row["address2"],
          //   row["state"],
          //   row["city"],
          //   row["pinCode"],
          //   row["mobileNumber"],
          //   row["token"],
          // ),
          model = UserdatafromDB(
            row["id"],
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    setState(() {});
  }

  // List<String> listHeader = ['Student Record'];
  Widget gridHeader() {
    return ListView.builder(
        itemCount: list.length,
        itemBuilder: (context, index) {
          return new Container(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 20,
                ),
                Container(
                  color: Colors.white,
                  height: MediaQuery.of(context).size.height * 0.22,
                  width: double.infinity,
                  child: Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Column(
                        children: <Widget>[
                          CircleAvatar(
                            child: Image.asset('assets/images/icon.png',
                                width: 100, height: 100, fit: BoxFit.fill),
                            backgroundColor: Colors.white,
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            list[index].name ,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            list[index].mobileNumber,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      )),
                ),
                new Divider(
                  color: Colors.indigo,
                ),
                ListTile(
                  // leading: Icon(
                  //   Icons.border_outer_rounded,
                  //   size: 30,
                  //   color: const Color(0xff312562),
                  // ),
                  title: new Text(
                    'Home',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        color: const Color(0xff312562),
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Open Sans',
                        fontSize: 15),
                  ),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomePage(),
                      ),
                    );
                  },
                ),
                new Divider(
                  color: Colors.indigo,
                ),
                ListTile(
                  // leading: Icon(
                  //   Icons.border_outer_rounded,
                  //   size: 30,
                  //   color: const Color(0xff312562),
                  // ),
                  title: new Text(
                    'Categories',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        color: const Color(0xff312562),
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Open Sans',
                        fontSize: 15),
                  ),
                  onTap: () {
                    Navigator.of(context).pop();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => sidemenuCategory(),
                      ),
                    );
                  },
                ),
                new Divider(
                  color: Colors.indigo,
                ),
                ListTile(
                    leading: Icon(
                      Icons.logout,
                      size: 30,
                      color: Colors.black,
                    ),
                    title: Text(
                      'Logout',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          color: const Color(0xff312562),
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Open Sans',
                          fontSize: 15),
                    ),
                    onTap: () {
                      _showDialog();
                      print("Existing user details deleted");
                    }),
              ],
            ),
          );
        });
  }

  void _showDialog() {
    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("Suyoga Samarpana"),
          content: new Text("Are you sure you want to Logout"),
          actions: <Widget>[
            // usually buttons at the bottom of the dialog
            new FlatButton(
              child: new Text("No"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            new FlatButton(
              child: new Text("YES"),
              onPressed: () async {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                prefs.remove("LoginMobNumber");
                dbHelper.userdelete();
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => LoginPage(),
                ));
              },
            ),
          ],
        );
      },
    );
  }
}
