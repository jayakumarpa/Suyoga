import 'package:Kissan/model/Vendor_AccountModel.dart';
import 'package:Kissan/pages/LoginOTP.dart';
import 'package:Kissan/widgets/widget_cart_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/api_service.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/forgot-password.dart';
import 'package:Kissan/pages/home.dart';
import 'package:Kissan/utils/ProgressHUD.dart';
import 'package:Kissan/utils/already_have_an_account_acheck.dart';
import 'package:Kissan/pages/SignUp_page.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/utils/form_helper.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final dbHelper = DBProvider.instance;
  List<LoginResponse> user = [];

  bool hidePassword = true;
  bool isApiCallProcess = false;
  CreateContact createContact;
  Contactadded contactadded;
  APIService apiService;
  String password;
  String username;
  GlobalKey<FormState> globalFormKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    apiService = new APIService();
    createContact = new CreateContact();
    contactadded = new Contactadded();
  }

  @override
  Widget build(BuildContext context) {
    return ProgressHUD(
      child: _uiSetup(context),
      inAsyncCall: isApiCallProcess,
      opacity: 0.3,
    );
  }

  Widget _uiSetup(BuildContext context) {
    return Stack(
      key: scaffoldKey,
      children: [
        Scaffold(
          backgroundColor: Colors.blueGrey[100],
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Stack(
                  children: <Widget>[
                    Container(
                      width: double.infinity,
                      child: Form(
                        key: globalFormKey,
                        child: Column(
                          children: <Widget>[
                            SizedBox(height: 60),
                            Text(
                              "Welcome To Kissan",
                              style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 26),
                            ),
                            CircleAvatar(
                              backgroundColor: Colors.transparent,
                              radius: 70,
                              child: Image.asset(
                                  'assets/images/kissan_logo.jpg',
                                  width: 100,
                                  height: 100,
                                  fit: BoxFit.fill),
                            ),
                            SizedBox(height: 20),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(10.0),
                                    height: 100,
                                    child: TextFormField(
                                      inputFormatters: [
                                        new LengthLimitingTextInputFormatter(
                                            10),
                                      ],
                                      maxLines: 1,
                                      decoration: InputDecoration(
                                          prefixIcon: Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 10),
                                            child: Icon(
                                              Icons.phone,
                                              size: 26,
                                              color: Colors.black,
                                            ),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(14.0),
                                              borderSide: BorderSide(
                                                color: Color.fromRGBO(
                                                    255, 95, 167, 1),
                                              )),
                                          border: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Colors.black),
                                              borderRadius:
                                                  BorderRadius.circular(14)),
                                          hintText: "Mobile Number ",
                                          hintStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: 19,
                                          )),
                                      onSaved: (input) => username = input,
                                      validator: (input) => input.length < 10
                                          ? 'Please Enter Mobile Number'
                                          : null,
                                      style: TextStyle(color: Colors.black),
                                      keyboardType: TextInputType.number,
                                      textInputAction: TextInputAction.next,
                                      cursorColor: Colors.black,
                                    ),
                                  ),
                                  SizedBox(height: 1),
                                  // GestureDetector(
                                  //   onTap: () => Navigator.push(
                                  //     context,
                                  //     MaterialPageRoute(
                                  //       builder: (context) => ForgotPassword(),
                                  //     ),
                                  //   ),
                                  //   child: Text(
                                  //     'Forgot Password',
                                  //     style: TextStyle(
                                  //         fontSize: 20,
                                  //         color:
                                  //             Color.fromRGBO(255, 95, 167, 1),
                                  //         fontWeight: FontWeight.bold),
                                  //   ),
                                  // ),
                                  SizedBox(height: 15),
                                ],
                              ),
                            ),
                            FlatButton(
                              padding: EdgeInsets.symmetric(
                                  vertical: 18, horizontal: 60),
                              onPressed: () {
                                if (validateAndSave()) {
                                  setState(() {
                                    isApiCallProcess = true;
                                  });
                                  apiService.loginOTP(username).then((ret) {
                                    setState(() {
                                      isApiCallProcess = false;
                                    });
                                    if (ret) {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => LoginOTP(
                                            user: username,
                                          ),
                                        ),
                                      );

                                      // Navigator.push(
                                      //   context,
                                      //   MaterialPageRoute(
                                      //     builder: (context) => OTP(
                                      //       user: usersignup,
                                      //     ),
                                      //   ),
                                      // );
                                    } else {
                                      FormHelper.showMessage(
                                          context,
                                          "SUYOGA",
                                          "Mobile Number Not Registered",
                                          "OK",
                                          () {});
                                    }
                                  });
                                }
                              },
                              child: Text(
                                "Generate OTP",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 24,
                                ),
                              ),
                              color: Color.fromRGBO(123, 212, 165, 1),
                              shape: StadiumBorder(),
                            ),
                            SizedBox(height: 15),
                            AlreadyHaveAccountCheck(
                              press: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) {
                                      return SignUP();
                                    },
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        )
      ],
    );
  }

  bool validateAndSave() {
    final form = globalFormKey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    return false;
  }

  // Future<Widget> _insert(LoginResponse cp) async {
  //   final SharedPreferences prefs = await SharedPreferences.getInstance();
  //   prefs.setDouble("Walletamt", cp.walletamt);
  //   prefs.setString("LoginMobNumber", cp.mobileNumber);
  //   Map<String, dynamic> row = {
  //     DBProvider.columnId: cp.id,
  //     DBProvider.columnFirstName: cp.firstName,
  //     DBProvider.columnLastName: cp.lastName,
  //     DBProvider.columnAddress1: cp.address.address1,
  //     DBProvider.columnAddress2: cp.address.address2,
  //     DBProvider.columnCity: cp.address.city,
  //     DBProvider.columnstate: cp.address.state,
  //     DBProvider.columnPincode: cp.address.pinCode,
  //     DBProvider.columnPhoneNumber: cp.mobileNumber,
  //     DBProvider.columnToken: cp.token,
  //     DBProvider.columnEmail: cp.emailId,
  //     DBProvider.columnwalletamt: cp.walletamt,
  //   };
  //   this.createContact.contact = cp.mobileNumber;
  //   this.createContact.email = cp.emailId;
  //   this.createContact.name = cp.firstName;
  //   this.createContact.type = "vendor";
  //   this.createContact.referenceId = "KIS_USR" + cp.mobileNumber;
  //   apiService.createContact(createContact).then((value) => {
  //         if (prefs.getString("cont_refId") == null)
  //           {
  //             if (value != null)
  //               {
  //                 this.contactadded.rzpcontactid = value.id,
  //                 this.contactadded.mobileNumber = cp.mobileNumber,
  //                 print(value.id),
  //                 apiService.addrzpccontact(contactadded, cp.token),
  //                 prefs.setString("cont_refId", value.id),
  //               }
  //           }
  //         else
  //           {Text("COntact already created")}
  //       });
  //   final id = await dbHelper.userinsert(row);
  //   print("$id");
  // }
}
