import 'package:Kissan/widgets/widget_cart_card.dart';
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:Kissan/components/loader_provider.dart';
import 'package:Kissan/utils/ProgressHUD.dart';
import 'package:Kissan/widgets/widget_checkpoint.dart';

class CheckoutBase extends StatefulWidget {
  @override
  CheckoutBaseState createState() => CheckoutBaseState();
}

class CheckoutBaseState<T extends CheckoutBase> extends State<T> {
  int currentPage = 0;
  bool showBackButton = true;
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<LoaderProvider>(builder: (context, loaderModel, child) {
      return Scaffold(
        appBar: _buildAppBar(),
        backgroundColor: Colors.white,
        body: ProgressHUD(
          child: SingleChildScrollView(
            child: Column(
              children: [
                CheckPoints(
                  checkedTill: currentPage,
                  checkPoints: ["Shipping", "Payment", "Order"],
                  checkPointFilledColor: Colors.green,
                ),
                Divider(color: Colors.grey),
                pageUI(),
              ],
            ),
          ),
          inAsyncCall: loaderModel.isApiCallPocess,
          opacity: 3.0,
        ),
      );
    });
  }

  Widget pageUI() {
    return null;
  }

  Widget _buildAppBar() {
    return AppBar(
      centerTitle: true,
      brightness: Brightness.dark,
      elevation: 0,
      backgroundColor: Colors.green,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios, color: Colors.white),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CartPageIconPress(),
          ),
        ),
      ),
      title: Text(
        'Checkout',
        style: TextStyle(color: Colors.white),
      ),
      actions: <Widget>[],
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
