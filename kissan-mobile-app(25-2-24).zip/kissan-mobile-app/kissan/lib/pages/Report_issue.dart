import 'package:Kissan/api_service.dart';
import 'package:Kissan/model/FeedbackModel.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/home.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/utils/form_helper.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ReportIssue extends StatefulWidget {
  String orderNumber;
  String mobileNumber;
  String username;

  Key key;
  ReportIssue({
    this.orderNumber,
    this.mobileNumber,
    this.username,
    this.key,
  }) : super(key: key);

  @override
  _ReportIssueState createState() => _ReportIssueState();
}

class _ReportIssueState extends State<ReportIssue> {
  UserFeedback userFeedback;
  APIService apiService;
  int selectedRadio = 0;
  int selectedRadio1 = 1;
  int selectedRadio2 = 2;
  int selectedRadio3 = 3;
  int selectedRadio4 = 4;
  String comments;

  List<UserdatafromDB> list = new List();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  setSelectedRadio(int val) {
    setState(() {
      selectedRadio = val;
    });

    if (selectedRadio == 1) {
      this.userFeedback.issueType = "I didn't Recieve this Order";
    }
    if (selectedRadio == 2) {
      this.userFeedback.issueType = "This Order arrived Late";
    }
    if (selectedRadio == 3) {
      this.userFeedback.issueType = "I have a problem with Products";
    }
    if (selectedRadio == 4) {
      this.userFeedback.issueType = "Issue with Delivery Person";
    }
  }

  @override
  void initState() {
    super.initState();
    fetch();
    apiService = new APIService();
    userFeedback = new UserFeedback();
    this.userFeedback.orderId = this.widget.orderNumber;
    this.userFeedback.userMobNumber = this.widget.mobileNumber;
  }

  fetch() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    // username = prefs.getString("userfirstName");
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.green,
          centerTitle: true,
          title: Text("Issue Details" + "  [" + this.widget.orderNumber + "]"),
        ),
        body: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          SizedBox(
            height: 20,
          ),
          Text(
            "Hello " + this.widget.username + "," + " " "how may we help you ?",
            style: TextStyle(
                fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            "Please select your issue topic",
            style: TextStyle(
                fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red),
          ),
          Card(
            color: Colors.green[200],
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: new BorderRadius.circular(16.0)),
            child: Column(
              children: <Widget>[
                // orderStatus("${paymentslist[index].transactionId}"),

                Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                  Radio(
                      value: selectedRadio1,
                      groupValue: selectedRadio,
                      activeColor: Colors.red,
                      onChanged: (val) {
                        setSelectedRadio(val);
                      }),
                  Text(
                    "I didn't Recieve this Order",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  )
                ]),
                Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                  Radio(
                      value: selectedRadio2,
                      groupValue: selectedRadio,
                      activeColor: Colors.red,
                      onChanged: (val) {
                        setSelectedRadio(val);
                      }),
                  Text(
                    "This Order arrived Late",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  )
                ]),
                Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                  Radio(
                      value: selectedRadio3,
                      groupValue: selectedRadio,
                      activeColor: Colors.red,
                      onChanged: (val) {
                        setSelectedRadio(val);
                      }),
                  Text(
                    "I have a problem with Products",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  )
                ]),
                Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                  Radio(
                      value: selectedRadio4,
                      groupValue: selectedRadio,
                      activeColor: Colors.red,
                      onChanged: (val) {
                        setSelectedRadio(val);
                      }),
                  Text(
                    "Issue with Delivery Person",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                  )
                ]),
              ],
            ),
          ),
          SizedBox(
            height: 25,
          ),
          Text(
            "Additional Remarks [Optional]",
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          SizedBox(
            height: 5,
          ),
          FormHelper.textcomment(
            context,
            this.userFeedback.userComments,
            (value) => {
              this.userFeedback.userComments = value,
            },
          ),
        ]),
        bottomNavigationBar: Container(
            height: 56,
            margin: EdgeInsets.symmetric(vertical: 24, horizontal: 12),
            child: Row(children: <Widget>[
              Container(
                width: 400,
                color: Colors.green,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // Icon(Icons.chat, color: Colors.white),
                    // Text("CHAT", style: TextStyle(color: Colors.white)),
                    GestureDetector(
                      onTap: () {
                        if (selectedRadio != 0) {
                          apiService
                              .reportFeedback(userFeedback, model.token)
                              .then((value) => {
                                    if (value != null)
                                      {
                                        FormHelper.showMessage(
                                            context,
                                            "SUYOGA",
                                            " Feedback Accepted Successfully",
                                            "OK", () {
                                          Navigator.of(context).push(
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      HomePage()));
                                        })
                                      }
                                  });
                        } else {
                          FormHelper.showMessage(context, "SUYOGA",
                              " Please Select the Issue Type", "OK", () {
                            Navigator.of(context).pop();
                          });
                        }
                      },
                      child: Container(
                        alignment: Alignment.center,
                        color: Colors.green[500],
                        child: Text("Submit Complaint",
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 18)),
                      ),
                    ),
                  ],
                ),
              ),
            ])));
  }
}
