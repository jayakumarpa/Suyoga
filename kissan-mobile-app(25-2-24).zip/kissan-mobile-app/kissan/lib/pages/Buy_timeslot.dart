import 'dart:io';

import 'package:Kissan/api_service.dart';
import 'package:Kissan/config.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/model/Promocode_model.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/widgets/Order_Sucess_Widget.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/PlaceOrder_model.dart';
import 'package:Kissan/pages/checkout_base.dart';
import 'package:provider/provider.dart';
import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/model/TimeSlot_Model.dart';
import 'package:Kissan/utils/form_helper.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BuyTimeslots extends CheckoutBase {
  double totalamt;
  String usermoblie;
  String token;
  CreateOrder shippingaddress;

  BuyTimeslots({
    this.shippingaddress,
    this.totalamt,
    this.usermoblie,
    this.token,
  });
  @override
  _BuyTimeslotsState createState() => _BuyTimeslotsState();
}

class _BuyTimeslotsState extends CheckoutBaseState<BuyTimeslots> {
  TextEditingController textcontroller = new TextEditingController();
  String couponcode;
  String _selectedtimeslot;
  double finalamt;
  double itemscost;
  int deliverycharges = 0;
  bool _visible = false;
  bool _visiblily = true;
  APIService apiService;
  double _discountAmount = 0;
  double walletbalance = 0;
  double waldiscount = 0;
  List<UserdatafromDB> list = new List();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  bool isCheck = false;
  bool ischecked = true;
  @override
  void initState() {
    super.initState();
    var orderProvider = Provider.of<CartProvider>(context, listen: false);
    orderProvider.timeslots();
    if (this.widget.totalamt < 250) {
      deliverycharges = 25;
    } else {
      deliverycharges = 0;
    }
    currentPage = 1;
    fetch();
    itemscost = this.widget.totalamt + deliverycharges;
    finalamt = this.widget.totalamt + deliverycharges;
  }

  fetch() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    walletbalance = prefs.getDouble("Walletamt");
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"].toString(),
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    setState(() {
      build(context);
    });
  }

  Widget build(BuildContext context) {
    return new Consumer<CartProvider>(builder: (context, timeslotmodel, child) {
      if (timeslotmodel.timeslotlist == null &&
          timeslotmodel.timeslotlist.length == 0) {
        return Center(
          child: Container(
            child: Text("Loading..."),
          ),
        );
      }
      return _listview(context, timeslotmodel.timeslotlist);
    });
  }

  Widget _listview(BuildContext context, List<Timeslot> timeslotlist) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          centerTitle: true,
          title: Text('SUYOGA'),
          backgroundColor: Colors.green,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
        ),
        body: SafeArea(
          child: timeslotwidget(timeslotlist),
        ));
  }

  Widget timeslotwidget(List<Timeslot> timeslotlist) {
    List<String> timeslot = [
      '${timeslotlist[0].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[0].time[0].morningTime}',
      '${timeslotlist[1].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[1].time[0].morningTime}',
      '${timeslotlist[2].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[2].time[0].morningTime}',
      '${timeslotlist[3].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[3].time[0].morningTime}',
      '${timeslotlist[4].dateDay}' +
          " " +
          "@ " +
          '${timeslotlist[4].time[0].morningTime}',
    ]; //
    Size size = MediaQuery.of(context).size;
    return Container(
        height: size.height,
        child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.only(left: 1, top: 40, bottom: 3),
            children: <Widget>[
              Center(
                child: Column(
                    //crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        //color: Colors.blue,
                        padding: EdgeInsets.only(left: 1, top: 10, bottom: 3),
                        child: Text("Delivery Time Slots ",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold)),
                      ),
                      Padding(
                          padding:
                              EdgeInsets.only(left: 10, top: 5, bottom: 3)),
                      DropdownButton(
                        hint: Text(
                          '  Select Delivery Date & Time',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        value: _selectedtimeslot,
                        iconSize: 45,
                        iconEnabledColor: Colors.green,
                        //isExpanded: true,
                        onChanged: (newValue) {
                          setState(() {
                            _selectedtimeslot = newValue;
                          });
                        },
                        items: timeslot.map((selectedtimeslot) {
                          return DropdownMenuItem(
                            child: new Text(
                              selectedtimeslot,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            value: selectedtimeslot,
                          );
                        }).toList(),
                      ),
                      SizedBox(
                        height: size.height * 0.05,
                      ),
                      SizedBox(
                        height: size.height * 0.05,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 25),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            new Checkbox(
                              activeColor: Colors.red,
                              checkColor: Colors.white,
                              value: this.isCheck,
                              onChanged: (bool v) {
                                this.isCheck = v;
                                setState(() {
                                  if (this.isCheck == true &&
                                      _discountAmount != 0 &&
                                      itemscost >= this.walletbalance) {
                                    this.finalamt = this.widget.totalamt +
                                        deliverycharges -
                                        _discountAmount -
                                        this.walletbalance;
                                  } else if (_discountAmount != 0) {
                                    finalamt = this.widget.totalamt +
                                        deliverycharges -
                                        _discountAmount;
                                  } else if (this.isCheck == true &&
                                      itemscost >= this.walletbalance) {
                                    finalamt = this.widget.totalamt +
                                        deliverycharges -
                                        this.walletbalance.round();
                                    waldiscount = this.walletbalance;
                                  } else if (this.isCheck == true &&
                                      itemscost <= this.walletbalance) {
                                    waldiscount = finalamt;
                                    finalamt = this.widget.totalamt +
                                        deliverycharges -
                                        this.waldiscount;
                                  } else {
                                    finalamt =
                                        this.widget.totalamt + deliverycharges;
                                  }
                                });
                              },
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              "Wallet Balance :",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "\u20B9 " + '${this.walletbalance}',
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.green,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: size.height * 0.08,
                      ),
                      // Row(
                      //   mainAxisAlignment: MainAxisAlignment.center,
                      //   children: [
                      //     Text(
                      //       "Free delivery for all orders above ",
                      //       style: TextStyle(
                      //           fontSize: 20,
                      //           color: Colors.black,
                      //           fontWeight: FontWeight.bold),
                      //     ),
                      //     Text(
                      //       "\u20B9 250",
                      //       style: TextStyle(
                      //           fontSize: 20,
                      //           color: Colors.green,
                      //           fontWeight: FontWeight.bold),
                      //     ),
                      //   ],
                      // ),
                      SizedBox(
                        height: size.height * 0.05,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "   Items Total Cost :",
                            style: TextStyle(
                                fontSize: 17,
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          ),
                          Text("${this.widget.totalamt}" + "   ",
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              )),
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "   Delivery Charges :",
                            style: TextStyle(
                                fontSize: 17,
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          ),
                          Text('$deliverycharges' + ".0   ",
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              )),
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),

                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "   Wallet Amount :",
                            style: TextStyle(
                                fontSize: 17,
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          ),
                          if (isCheck == false)
                            Text("-" + '0.0' + "   ",
                                style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                )),
                          if (isCheck == true)
                            Text("-" + '${this.waldiscount}' + "   ",
                                style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                )),
                        ],
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Divider(color: Colors.red),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "   Total Amount :",
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.red,
                                fontWeight: FontWeight.bold),
                          ),
                          Text('$finalamt' + "   ",
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              )),
                        ],
                      ),
                      SizedBox(
                        height: size.height * 0.02,
                      ),
                    ]),
              ),
              Container(
                child: Align(
                  alignment: FractionalOffset.bottomCenter,
                  child: Container(
                      child: Column(
                    children: [
                      Container(
                        color: Colors.white,
                        width: MediaQuery.of(context).size.width,
                        height: 100,
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                FlatButton(
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        'Next',
                                        style: TextStyle(
                                            fontSize: 20, color: Colors.white),
                                      ),
                                      Icon(Icons.chevron_right,
                                          size: 30, color: Colors.white),
                                    ],
                                  ),
                                  onPressed: () {
                                    if (_selectedtimeslot != null) {
                                      var orderProvider =
                                          Provider.of<CartProvider>(context,
                                              listen: false);
                                      CreateOrder setTimeslot =
                                          new CreateOrder();
                                      setTimeslot.timeSlot = _selectedtimeslot;
                                      setTimeslot.status =
                                          "Order Placed Successfully";
                                      setTimeslot.totalAmount = finalamt;
                                      if (isCheck == true) {
                                        setTimeslot.walletamt =
                                            this.waldiscount;
                                      } else {
                                        setTimeslot.walletamt = 0;
                                      }
                                      setTimeslot.paymentMethod = "COD";
                                      setTimeslot.paymentMethodTitle =
                                          "order placed by using COD";

                                      orderProvider
                                          .placetimeslotProcess(setTimeslot);
                                      orderProvider.addresstProcess(
                                          this.widget.shippingaddress);

                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                OrderSucessWidget(),
                                          ));
                                    } else {
                                      FormHelper.showMessage(
                                          context,
                                          "SUYOGA",
                                          "Select Delivery Date and Time",
                                          "OK", () {
                                        Navigator.of(context).pop();
                                      });
                                    }
                                  },
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 40, vertical: 13),
                                  color: Colors.green,
                                  shape: StadiumBorder(),
                                ),
                              ]),
                        ),
                      ),
                    ],
                  )),
                ),
              )
            ]));
  }

  Future<PromocodeModel> promocode() async {
    PromocodeModel data;
    String token = model.token;
    try {
      String url = Config.url + Config.promocode;

      var response = await Dio().post(url,
          data: {
            "userName": model.mobileNumber,
            "promoCode": textcontroller.text,
            "totalAmount": this.widget.totalamt,
          },
          options: new Options(headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader: 'Bearer $token',
          }));
      if (response.statusCode == 200) {
        data = PromocodeModel.fromJson(response.data);
      }
    } on DioError catch (e) {
      data = PromocodeModel.fromJson(e.response.data);
    }

    return data;
  }
}

class AppCheckbox extends StatelessWidget {
  final bool value;
  final bool disabled;
  final double size;
  final ValueChanged<bool> onChanged;

  const AppCheckbox({
    Key key,
    this.size = 24,
    this.value = false,
    this.disabled = true,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final backColor = Colors.transparent;
    final checkColor = Colors.red;

    return Theme(
      data: Theme.of(context).copyWith(
        disabledColor: Colors.green,
        unselectedWidgetColor: Colors.blue,
      ),
      child: SizedBox(
        width: size,
        height: size,
        child: Container(
          decoration: BoxDecoration(
            color: backColor,
            borderRadius: BorderRadius.circular(4),
          ),
          clipBehavior: Clip.hardEdge,
          child: Transform.scale(
            scale: size / Checkbox.width,
            child: Checkbox(
              hoverColor: Colors.transparent,
              focusColor: Colors.transparent,
              activeColor: Colors.red,
              checkColor: checkColor,
              value: value,
              onChanged: disabled
                  ? null
                  : (value) {
                      onChanged(value);
                    },
            ),
          ),
        ),
      ),
    );
  }
}
