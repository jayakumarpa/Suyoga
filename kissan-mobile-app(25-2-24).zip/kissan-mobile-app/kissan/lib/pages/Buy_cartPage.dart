import 'dart:ui';

import 'package:Kissan/pages/Buy_user_address.dart';
import 'package:Kissan/pages/home.dart';
import 'package:Kissan/widgets/Buy_WidgetcartProduct.dart';
import 'package:flutter/material.dart';
import 'package:modal_progress_hud/modal_progress_hud.dart';
import 'package:provider/provider.dart';
import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/components/loader_provider.dart';
import 'package:Kissan/pages/loggin.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/utils/dataBase.dart';

class BuyCartPage extends StatefulWidget {
  @override
  _BuyCartPageState createState() => _BuyCartPageState();
}

class _BuyCartPageState extends State<BuyCartPage> {
  //Added scroll bar as Listtile inbuild not supports scrollview
  final ScrollController _scrollController = ScrollController();
  List<UserdatafromDB> list = new List();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  @override
  void initState() {
    super.initState();
    var caritemList = Provider.of<CartProvider>(context, listen: false);
    caritemList.resetSreams();
    caritemList.buyupdaterecord();
    caritemList.getuseraddress();
    fetch();
  }

  fetch() async {
   // final coutnt = await dbHelper.buygetCount();
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"].toString(),
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    setState(() {});
  }
   Future<bool> _onbackpress() async{
     final SharedPreferences prefs =
                  await SharedPreferences.getInstance();
              int counter = prefs.getInt("Count");
    return  Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => HomePage(
                    ccount: counter,
                  ),
                ),
              );
    
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<LoaderProvider>(builder: (context, loadModel, chield) {
      return WillPopScope(
      child: Scaffold(
        appBar: AppBar(
        
        centerTitle: true,
        brightness: Brightness.dark,
        elevation: 0,
        backgroundColor: Colors.green,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(),
              ),
            );
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
        title: Text(
          'Buy cart items',
          style: TextStyle(color: Colors.black),
        ),
      ),
        
        resizeToAvoidBottomInset: false,
        
        body: ModalProgressHUD(
            inAsyncCall: loadModel.isApiCallPocess,
            opacity: 0.3,
            child: _cartItemList()),
      ),
       onWillPop: _onbackpress);
    });
  }

  Widget _cartItemList() {
    return new Consumer<CartProvider>(builder: (context, cartmodel, chield) {
      if (cartmodel.buyCartItems != null && cartmodel.buyCartItems.length > 0) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                child: Scrollbar(
                  isAlwaysShown: true,
                  controller: _scrollController,
                  child: ListView.builder(
                      controller: _scrollController,
                      itemCount: cartmodel.buyCartItems.length,
                      itemBuilder: (context, index) {
                        return BuyCartProduct(
                         data: cartmodel.buyCartItems[index],
                        );
                      }),
                ),
                // child: Column(
                //   mainAxisAlignment: MainAxisAlignment.start,
                //   // children: [
                //   //   ListView.builder(
                //   //       shrinkWrap: true,
                //   //       physics: ClampingScrollPhysics(),
                //   //       scrollDirection: Axis.vertical,
                //   //       itemCount: cartmodel.CartItems.length,
                //   //       itemBuilder: (context, index) {
                //   //         return CartProduct(
                //   //           data: cartmodel.CartItems[index],
                //   //         );
                //   //       }),

                //   // ],
                // ),
              ),
            ),
            Container(
              color: Colors.greenAccent[100],
              width: MediaQuery.of(context).size.width,
              height: 85,
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          new Text(
                            'Total',
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                          new Text(
                            '${cartmodel.buytotalAmount}',
                            style: TextStyle(
                                fontSize: 25, fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                      FlatButton(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              'Check Out',
                              style: TextStyle(color: Colors.white),
                            ),
                            Icon(Icons.chevron_right, color: Colors.white),
                          ],
                        ),
                        onPressed: () async {
                          final SharedPreferences prefs =
                              await SharedPreferences.getInstance();
                          prefs.setDouble(
                              "totalAmount", cartmodel.buytotalAmount);
                          if (list.length != 0 &&
                              cartmodel.userAddressmodel != null) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => VerifyBuyuserAddress(
                                          totalamt: cartmodel.buytotalAmount,
                                        )));
                          } else {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LoginPage()));
                          }
                        },
                        padding: EdgeInsets.all(15),
                        color: Colors.redAccent,
                        shape: StadiumBorder(),
                      ),
                    ]),
              ),
            )
          ],
        );
      } else {
        return Container(
          padding: EdgeInsets.only(left: 139),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                new Text(
                  'Cart is Empty',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ]),
        );
      }
    });
  }
}
