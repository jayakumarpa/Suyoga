import 'package:Kissan/api_service.dart';
import 'package:Kissan/components/cart_provider.dart';
import 'package:Kissan/model/CityList_Model.dart';
import 'package:Kissan/pages/home.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CityList extends StatefulWidget {
  @override
  _CityListState createState() => _CityListState();
}

APIService apiService;

class _CityListState extends State<CityList> {
  @override
  void initState() {
    super.initState();
    // var orderProvider = Provider.of<CartProvider>(context, listen: false);
    //orderProvider.getcities();
  }

  @override
  Widget build(BuildContext context) {
    return new Consumer<CartProvider>(builder: (context, ordermodel, child) {
      if (ordermodel.allcities != null && ordermodel.allcities.length > 0) {
        _listview(context, ordermodel.allcities);
      }
      return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          brightness: Brightness.dark,
          elevation: 0,
          backgroundColor: Colors.green,
          automaticallyImplyLeading: false,
          title: Text(
            'My Cities',
            style: TextStyle(color: Colors.white),
          ),
        ),
        body: Container(
          margin: EdgeInsets.only(left: 40),
          child: _listview(context, ordermodel.allcities),
        ),
      );
    });
  }

  Widget _listview(BuildContext context, List<CityListModel> orders) {
    return ListView(children: [
      ListView.builder(
          itemCount: orders.length,
          physics: ScrollPhysics(),
          padding: EdgeInsets.all(16),
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return Row(children: [
              SizedBox(
                width: 328,
                child: GestureDetector(
                  onTap: () async {
                    final SharedPreferences prefs =
                        await SharedPreferences.getInstance();
                    prefs.setString('Location', orders[index].cityName);
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HomePage(),
                        ));
                  },
                  child: new Card(
                    elevation: 2,
                    color: Colors.green[400],
                    shape: RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(16.0)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Container(
                            height: 20,
                            decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(10),
                            )),
                        Text(
                          orders[index].cityName,
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          ),
                        ),
                        SizedBox(
                          height: 50,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ]);
          })
    ]);
  }
}
