import 'package:flutter/material.dart';

class OrderStatus extends StatefulWidget {
  const OrderStatus({ Key key, String status }) : super(key: key);

  @override
  State<OrderStatus> createState() => _OrderStatusState();
}

class _OrderStatusState extends State<OrderStatus> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}