import 'package:Kissan/pages/Accountpage.dart';
import 'package:Kissan/pages/UpdateMobile_Number.dart';
import 'package:Kissan/pages/Update_Password.dart';
import 'package:Kissan/widgets/widget_Account_Page.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/utils/colors.dart';

class userprofile extends StatelessWidget {
  userprofile({Key key, this.profilemodel}) : super(key: key);
  UserdatafromDB profilemodel;
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.green[900],
          elevation: 0,
          leading: IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AccountTab(),
                ),
              );
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
          title: Text(
            'Profile',
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
        ),
        body: new Stack(
          children: <Widget>[
            ClipPath(
              child: Container(color: Colors.green.withOpacity(0.8)),
              clipper: getClipper(),
            ),
            Positioned(
                width: 350.0,
                top: MediaQuery.of(context).size.height / 8,
                child: Column(
                  children: <Widget>[
                    Container(
                        width: 150.0,
                        height: 150.0,
                        decoration: BoxDecoration(
                            color: Colors.red,
                            image: DecorationImage(
                                image: NetworkImage(
                                    'https://pixel.nymag.com/imgs/daily/vulture/2017/06/14/14-tom-cruise.w700.h700.jpg'),
                                fit: BoxFit.cover),
                            borderRadius: BorderRadius.all(Radius.circular(75.0)),
                            boxShadow: [
                              BoxShadow(blurRadius: 7.0, color: Colors.black)
                            ])),
                    SizedBox(height: 10.0),
                    Text(
                      // 'Tom Cruise',
                      profilemodel.name,
                      style: TextStyle(
                        fontSize: 30.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Montserrat',
                        color: Colors.red,
                      ),
                    ),
                    SizedBox(height: 6.0),
                    Text(
                      // 'TomCruise@gmail.com',
                      profilemodel.mobileNumber,
                      style: TextStyle(
                        fontSize: 17.0,
                        //fontStyle: FontStyle.bold,
                        fontFamily: 'Montserrat',
                        color: Colors.red,
                      ),
                    ),
                    SizedBox(height: 25.0),
                    Container(
                        height: 150.0,
                        width: 340.0,
                        child: Material(
                          borderRadius: BorderRadius.circular(20.0),
                          shadowColor: Colors.greenAccent,
                          color: Colors.green,
                          elevation: 7.0,
                          child: GestureDetector(
                            onTap: () {},
                            // child: Center(
                            //   child: Text(
                            //     profilemodel.address1,
                            //     style: TextStyle(
                            //         color: Colors.white, fontFamily: 'Montserrat'),
                            //   ),

                            // ),
                            child: Container(
                              padding: EdgeInsets.only(top: 18),
                              child: Column(
                                children: [
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      " Address :",
                                      style: TextStyle(
                                          color: white,
                                          fontFamily: 'Montserrat',
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(bottom: 10),
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      " " + profilemodel.address1,
                                      style: TextStyle(
                                          color: white,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),

                                  Container(
                                    padding: EdgeInsets.only(top: 2),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        " City : " + profilemodel.city,
                                        style: TextStyle(
                                            color: white,
                                            fontFamily: 'Montserrat',
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: EdgeInsets.only(bottom: 10),
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      " PinCode : " +
                                          profilemodel.pinCode.toString(),
                                      style: TextStyle(
                                          color: white,
                                          fontFamily: 'Montserrat',
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  Container(
                                    // padding: EdgeInsets.only(bottom: 10),
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      " State : " + profilemodel.state,
                                      style: TextStyle(
                                          color: white,
                                          fontFamily: 'Montserrat',
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),

                                  //Text("product details"),
                                ],
                              ),
                            ),
                          ),
                        )),
                    ListTile(
                      leading: Icon(Icons.call, size: 30, color: Colors.black),
                      title: Text('Update Mobile Number',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          )),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => UpdateMoblieNumber(),
                        ));
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.lock, size: 30, color: Colors.black),
                      title: Text('Update Password',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          )),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => UpdatePassword(),
                        ));
                      },
                    ),
                    SizedBox(height: 25.0),
                  ],
                ))
          ],
        ));
  }
}

class getClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = new Path();

    path.lineTo(0.0, size.height / 1.9);
    path.lineTo(size.width + 125, 0.0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return true;
  }
}
