import 'dart:io';

import 'package:Kissan/config.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/pages/home.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/utils/form_helper.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/Order_details_Model.dart';
import 'package:Kissan/pages/Myorders_List.dart';
import 'package:provider/provider.dart';
import 'package:Kissan/components/cart_provider.dart';

class BuyOrderDetails extends StatefulWidget {
  BuyOrderDetails orderModel;

  BuyOrderDetails({Key key, this.orderModel}) : super(key: key);

  @override
  _BuyOrderDetailsState createState() => _BuyOrderDetailsState();
}

class _BuyOrderDetailsState extends State<BuyOrderDetails> {
  List<UserdatafromDB> list = new List();
  final dbHelper = DBProvider.instance;
  UserdatafromDB model;
  @override
  void initState() {
    super.initState();
    var orderProvider = Provider.of<CartProvider>(context, listen: false);
    orderProvider.buyOrders();
    fetch();
  }

  fetch() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"].toString(),
            row["Name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    setState(() {
      build(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return new Consumer<CartProvider>(builder: (context, ordermodel, child) {
      return ordermodel.allOrders == null || ordermodel.allOrders.length == 0
          ? Scaffold(
              body: Center(child: Container(child: Text("Loading....."))))
          : _listview(context, ordermodel.allOrders);
    });
  }

  Widget _listview(BuildContext context, List<OrderModel> orders) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        brightness: Brightness.dark,
        elevation: 0,
        backgroundColor: Colors.green,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
        ),
        title: Text(
          'My Orders',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: orderslist(context, orders),
      ),
    );
  }

  Widget orderslist(BuildContext context, List<OrderModel> orders) {
    return ListView(
      children: [
        ListView.builder(
            itemCount: orders.length,
            physics: ScrollPhysics(),
            padding: EdgeInsets.all(8),
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(16.0)),
                child: Column(
                  children: <Widget>[
                    orderStatus("${orders[index].invoiceStatus}"),
                    Divider(color: Colors.red),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        iconData(
                            Icon(
                              Icons.edit,
                              color: Colors.red,
                              size: 14,
                            ),
                            Text(
                              "Order Number :",
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )),
                        Text("${orders[index].invoiceNumber}",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            )),
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        iconData(
                            Icon(
                              Icons.date_range,
                              color: Colors.red,
                              size: 12,
                            ),
                            Text(
                              "Order Date :",
                              style: TextStyle(
                                  fontSize: 17,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )),
                        Text("${orders[index].orderdate}",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            )),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        flatButton(
                          Row(
                            children: [
                              Text(
                                "Order Details",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Icon(Icons.chevron_right),
                            ],
                          ),
                          Colors.green,
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => MyordersProductList(
                                        mobileNumber: model.mobileNumber,
                                      ),
                                  settings: RouteSettings(
                                    arguments: orders[index],
                                  )),
                            );
                          },
                        ),
                        if (orders[index].invoiceStatus == "Pending")
                          flatButton(
                            Row(
                              children: [
                                Text(
                                  "Cancel Order",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                Icon(
                                  Icons.cancel,
                                  color: Colors.white,
                                ),
                              ],
                            ),
                            Colors.deepOrange,
                            () {
                              showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    title: new Text("Kissan"),
                                    content: new Text(
                                        "Are you sure you want to Cancel"),
                                    actions: <Widget>[
                                      new FlatButton(
                                        child: new Text("No"),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      ),
                                      new FlatButton(
                                        child: new Text("YES"),
                                        onPressed: () {
                                          orderCancel(
                                            orders[index].invoiceNumber,
                                            model.token,
                                          ).then((ret) {
                                            if (ret) {
                                              FormHelper.showMessage(
                                                  context,
                                                  "SUYOGA",
                                                  "Your Order Cancelled Succesfully",
                                                  "OK", () {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        HomePage(),
                                                  ),
                                                );
                                              });
                                            } else {
                                              FormHelper.showMessage(
                                                  context,
                                                  "SUYOGA",
                                                  "Order Cancel Failed",
                                                  "OK", () {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        HomePage(),
                                                  ),
                                                );
                                              });
                                            }
                                          });
                                        },
                                      ),
                                    ],
                                  );
                                },
                              );
                            },
                          ),
                      ],
                    ),
                    Divider(color: Colors.red),
                  ],
                ),
              );
            })
      ],
    );
  }

  Future<bool> orderCancel(
    String ordernumber,
    String token,
  ) async {
    bool ret = false;
    String url = Config.url + Config.cancelOrder;
    try {
      final response = await Dio().put(
        url,
        data: {
          "orderNumber": ordernumber,
        },
        options: new Options(
          headers: {
            HttpHeaders.contentTypeHeader: "application/json",
            HttpHeaders.authorizationHeader: 'Bearer $token',
          },
        ),
      );

      if (response.statusCode == 201) {
        ret = true;
      }
    } on DioError catch (e) {
      ret = false;
    }
    return ret;
  }

  Widget iconData(Icon iconData, Text textdata) {
    return Row(
      children: <Widget>[
        iconData,
        SizedBox(
          width: 10,
        ),
        textdata,
      ],
    );
  }

  Widget flatButton(
    Widget iconText,
    Color color,
    Function onPressed,
  ) {
    return FlatButton(
      child: iconText,
      onPressed: onPressed,
      padding: EdgeInsets.all(5),
      color: color,
      shape: StadiumBorder(),
    );
  }

  Widget orderStatus(String status) {
    Icon icon;
    Color color;

    if (status == "P" || status == "Pending" || status == "On-Hold") {
      icon = Icon(
        Icons.timer,
        color: Colors.orange,
      );
      color = Colors.orange;
    } else if (status == "D" || status == "Delivered") {
      icon = Icon(
        Icons.check,
        color: Colors.green,
      );
      color = Colors.green;
    } else if (status == "C" || status == "Cancelled") {
      icon = Icon(
        Icons.clear,
        color: Colors.redAccent,
      );
      color = Colors.redAccent;
    } else {
      icon = Icon(
        Icons.clear,
        color: Colors.redAccent,
      );
      color = Colors.redAccent;
    }
    return iconData(
        icon,
        Text(
          "Order Status :$status",
          style: TextStyle(
            color: color,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ));
  }
}
