import 'dart:convert';

import 'package:Kissan/model/AddmoneyToWallet.dart';
import 'package:Kissan/model/CityList_Model.dart';
import 'package:Kissan/model/MyPayments_Model.dart';
import 'package:Kissan/model/UseraddressModel.dart';
import 'package:Kissan/model/Vendor_AccountModel.dart';
import 'package:Kissan/model/WalletTransacDetailsModel.dart';
import 'package:Kissan/pages/BankAccount_Page.dart';
import 'package:Kissan/pages/Transferpage.dart';
import 'package:flutter/widgets.dart';
import 'package:Kissan/api_service.dart';
import 'package:Kissan/model/LoginRespose.dart';
import 'package:Kissan/model/PlaceOrder_model.dart';
import 'package:Kissan/model/ProductLocal.dart';
import 'package:Kissan/model/TimeSlot_Model.dart';
import 'package:Kissan/model/User_Signup_Model.dart';
import 'package:Kissan/model/customer_detail_model.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:Kissan/model/Order_details_Model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CartProvider with ChangeNotifier {
  List<ProductLocal> _cartItems;

  List<BuyProductLocal> _buycartItems;

  CreateOrder _createOrder;
  AddMoneyToWallet addMoneyToWallet;
  CreateOrder _timeslotset;
  CreateOrder _address;
  OrderModel _orderModel;
  CustomerDetails _customerDetails;
  bool _isorderCreated = false;
  bool _ispayment = false;
  APIService apiService;
  VendorAccountdetails vendorBankDetails;
  FundAccount _fundAccount;
  BankContactadded bankContactadded;
  List<OrderModel> _orderList;
  List<CityListModel> _citylist;
  List<MyPaymentsModel> _mypayments;
  List<Timeslot> _timeslot;
  List<UserAddressModel> _useraddress;
  List<WalletHistory> _walletHistory;
  String moblieNumber;
  String email;
  String payment;
  double walletamt;

  int flagnum;
  List<ProductLocal> get CartItems => _cartItems;
  List<BuyProductLocal> get buyCartItems => _buycartItems;
  FundAccount get getbankdetailsdata => _fundAccount;
  List<WalletHistory> get allwalletdata => _walletHistory;
  double get totalRecords => _cartItems.length.toDouble();
  double get totalAmount => _cartItems != null
      ? _cartItems
          .map<double>((e) => e.totalPrice)
          .reduce((value, element) => value + element)
      : 0;

  double get buytotalRecords => _buycartItems.length.toDouble();
  double get buytotalAmount => _buycartItems != null
      ? _buycartItems
          .map<double>((e) => e.totalPrice)
          .reduce((value, element) => value + element)
      : 0;

  final dbHelper = DBProvider.instance;

  //String get idemail => model.emailId;
  String get mobNum => model.mobileNumber;
  List<UserdatafromDB> list = new List();
  UserdatafromDB model;
  User user;
  VendorAccountdetails get vendorBankDetailsdata => vendorBankDetails;
  List<OrderModel> get allOrders => _orderList;
  List<CityListModel> get allcities => _citylist;
  List<MyPaymentsModel> get paymentslist => _mypayments;
  List<Timeslot> get timeslotlist => _timeslot;
  List<UserAddressModel> get userAddressmodel => _useraddress;
  double get totalRecord => _orderList.length.toDouble();

  CreateOrder get creatingOrder => _createOrder;
  AddMoneyToWallet get walletdetails => addMoneyToWallet;
  CreateOrder get creatingtimeOrder => _timeslotset;
  CreateOrder get creatingaddressOrder => _address;

  bool get isorderCreated => _isorderCreated;
  bool get ispaymentsucess => _ispayment;

  CartProvider() {
    _cartItems = new List<ProductLocal>();
    _buycartItems = new List<BuyProductLocal>();
    list = new List<UserdatafromDB>();
    apiService = APIService();
  }
  
  get finalkg => null;
  void resetSreams() {}

  fetchOrders() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });

    String customerId = model.mobileNumber;
    String token = model.token;
    List<OrderModel> orderList =
        await apiService.getorderdetails(customerId, token);
    if (_orderList == null) {
      _orderList = new List<OrderModel>();
    }
    if (orderList.length > 0) {
      _orderList = [];
      _orderList.addAll(orderList);
    }
    notifyListeners();
  }

  buyOrders() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });

    String customerId = model.mobileNumber;
    String token = model.token;
    List<OrderModel> orderList =
        await apiService.getbuyorderdetails(customerId, token);
    if (_orderList == null) {
      _orderList = new List<OrderModel>();
    }
    if (orderList.length > 0) {
      _orderList = [];
      _orderList.addAll(orderList);
    }
    notifyListeners();
  }

  getcities() async {
    List<CityListModel> cityList = await apiService.getCityList();
    if (_citylist == null) {
      _citylist = new List<CityListModel>();
    }
    if (cityList.length > 0) {
      _citylist = [];
      _citylist.addAll(cityList);
    }
    notifyListeners();
  }

  fetchMypayments() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });

    String customerId = model.mobileNumber;
    String token = model.token;
    List<MyPaymentsModel> orderList =
        await apiService.myPaymentsList(customerId, token);
    if (_mypayments == null) {
      _mypayments = new List<MyPaymentsModel>();
    }
    if (orderList.length > 0) {
      _mypayments = [];
      _mypayments.addAll(orderList);
    }
    notifyListeners();
  }

  getaccountProcess(FundAccount order) {
    this._fundAccount = order;
    notifyListeners();
  }

  timeslots() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });

    String token = model.token;
    moblieNumber = model.mobileNumber;
    //email = model.emailId;
    List<Timeslot> timslot = await apiService.getTimeslot(token);
    if (timslot.length > 0) {
      _timeslot = [];
      _timeslot.addAll(timslot);
    }
    notifyListeners();
  }

  void fundcreate() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          print(allRows),
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    print(allRows);
    notifyListeners();

    if (_fundAccount.bankAccount != null) {
      final SharedPreferences prefs = await SharedPreferences.getInstance();

      _fundAccount.bankAccount.account_number =
          getbankdetailsdata.bankAccount.account_number;
      _fundAccount.bankAccount.name = getbankdetailsdata.bankAccount.name;
      _fundAccount.bankAccount.ifsc = getbankdetailsdata.bankAccount.ifsc;
      _fundAccount.contactId = prefs.getString("cont_refId");
      _fundAccount.accountType = "bank_account";
      await apiService.addfundAccount(_fundAccount).then((value) {
        if (value != null) {
          bankContactadded.mobileNumber = model.mobileNumber;
          bankContactadded.rzpbankid = value.id;
          apiService.addbankcontact(bankContactadded, model.token);
        }
      });
    }
  }

  void getVendorBankDetails() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    await apiService
        .getVendorBankDetails(model.mobileNumber, model.token)
        .then((value) {
      if (value.statusCode == 200) {
        vendorAccountdetails = value;

        vendorAccountdetails = new VendorAccountdetails();
        vendorAccountdetails = VendorAccountdetails.fromJson(value.toJson());

        notifyListeners();
      }
    });
  }

  getwalletTransdata() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          print(allRows),
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    print(allRows);

    String customerId = model.mobileNumber;
    String token = model.token;
    List<WalletHistory> wallettransList =
        await apiService.getwalletHistorydetails(customerId, token);
    print(customerId);
    if (_walletHistory == null) {
      _walletHistory = new List<WalletHistory>();
    }
    if (wallettransList.length > 0) {
      _walletHistory = [];
      _walletHistory.addAll(wallettransList);
    }
    notifyListeners();
  }

  getbankdetails() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    vendorBankDetails =
        await apiService.getVendorBankDetails(model.mobileNumber, model.token);

    notifyListeners();
  }

  fetch() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    notifyListeners();
  }

  updaterecord() async {
    final allRows = await dbHelper.queryAllRows();
    allRows.forEach((row) => print(row));
    List darta = allRows;
    if (darta != null) {
      _cartItems = darta
          .map((productLocal) => new ProductLocal.fromJson(productLocal))
          .toList();
    }
    notifyListeners();
  }

  buyupdaterecord() async {
    final allRows = await dbHelper.buyqueryAllRows();
    allRows.forEach((row) => print(row));
    List darta = allRows;
    if (darta != null) {
      _buycartItems = darta
          .map((productLocal) => new BuyProductLocal.fromJson(productLocal))
          .toList();
    }
    notifyListeners();
  }

  fetchShippingdetails() async {
    if (_customerDetails == null) {
      _customerDetails = new CustomerDetails();
      notifyListeners();
    }
  }

  placeOrderProcess(CreateOrder order) {
    this._createOrder = order;
    notifyListeners();
  }

  addmoneyProcess(AddMoneyToWallet wallet) {
    this.addMoneyToWallet = wallet;
    notifyListeners();
  }

  placetimeslotProcess(CreateOrder order) {
    this._timeslotset = order;
    notifyListeners();
  }

  addresstProcess(CreateOrder order) {
    this._address = order;
    notifyListeners();
  }

  void ordercreate() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    if (_address.shipping != null) {
      // _address.shipping.firstName = model.Name;
      _address.shipping.lastName = model.name;
      _address.shipping.country = "India";
      _address.customerId = model.mobileNumber.toString();
      _address.shipping.mobile = model.mobileNumber;
      // _address.shipping.email = model.emailId.toString();
    }

    if (_address.productList == null) {
      _address.productList = new List<ProductList>();
      _buycartItems.forEach((v) {
        int quantity = v.priceMinQuantity * v.numOfItems;
        double kg = quantity / 1000;
        int finalkg = kg.toInt();
        _address.productList.add(new ProductList(
          productId: v.productId,
          productCode: v.productCode,
          productName: v.productName,
          numOfItems: v.numOfItems,
          priceId: v.priceId,
          price: v.price,
          priceMinQuantity: finalkg.toString() + ' ' + 'kg',
          totalPrice: v.totalPrice,
          brandname: v.brandname,
        ));
      });
    }
    _address.shipping.address1 = creatingaddressOrder.shipping.address1;
    _address.shipping.city = creatingaddressOrder.shipping.city;
    _address.shipping.state = creatingaddressOrder.shipping.state;
    _address.shipping.postalCode =
        creatingaddressOrder.shipping.postalCode.toString();
    _address.totalAmount = creatingtimeOrder.totalAmount;
    _address.paymentMethod = "COD";
    _address.paymentMethodTitle =
        "User placed an order in Cash On Delivery method";
    _address.customerId = model.mobileNumber.toString();
    _address.timeSlot = creatingtimeOrder.timeSlot;
    if (creatingtimeOrder.walletamt != 0) {
      _address.walletamt = creatingtimeOrder.walletamt;
    }else{
      _address.walletamt = 0.0;
    }
    _address.typeofOrder = "BUY";
    _address.setPaid = true;
    _address.status = "Order Initiate";
    DateTime now = new DateTime.now();
    DateTime date = new DateTime(now.year, now.month, now.day);
    _address.transactionId = "COD" + date.toString();
    String token = model.token;
    await apiService.createOrder(_address, token).then((value) {
      if (value) {
        _isorderCreated = true;
        double oldamt = prefs.getDouble("Walletamt");
        prefs.setDouble(
            "Walletamt", oldamt - creatingtimeOrder.walletamt.round());
        prefs.getDouble("Walletamt").round();
        dbHelper.buycartdelete();
        notifyListeners();
      }
    });
  }
 


  void walletpayment() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    if (_address.shipping != null) {
      // _address.shipping.firstName = model.firstName;
      _address.shipping.lastName = model.name;
      _address.shipping.country = "India";
      _address.customerId = model.mobileNumber.toString();
      _address.shipping.mobile = model.mobileNumber;
      // _address.shipping.email = model.emailId.toString();
    }

    if (_address.productList == null) {
      _address.productList = new List<ProductList>();
      _cartItems.forEach((v) {
        _address.productList.add(new ProductList(
          productId: v.productId,
          productCode: v.productCode,
          productName: v.productName,
          numOfItems: v.numOfItems,
          priceId: v.priceId,
          price: v.price,
          totalPrice: v.totalPrice,
          priceMinQuantity: v.quantity,
          brandname: v.brandname,
        ));
      });
    }
    _address.shipping.address1 = creatingaddressOrder.shipping.address1;
    _address.shipping.city = creatingaddressOrder.shipping.city;
    _address.shipping.state = creatingaddressOrder.shipping.state;
    _address.shipping.postalCode =
        creatingaddressOrder.shipping.postalCode.toString();
    _address.totalAmount = creatingtimeOrder.totalAmount;
    _address.paymentMethod = "Wallet";
    _address.paymentMethodTitle = "This amount needs to send Kissan User";
    _address.typeofOrder = "SELL";
    if (prefs.getString("latitude") != null) {
      _address.latitude = prefs.getString("latitude");
      _address.longitude = prefs.getString("longitude");
    } else {
      _address.latitude = "0.00.000";
      _address.longitude = "0.00.000";
    }
    _address.timeSlot = creatingtimeOrder.timeSlot;
    DateTime now = new DateTime.now();
    DateTime date = new DateTime(now.year, now.month, now.day);
    _address.transactionId = "COD" + date.toString();
    _address.setPaid = true;

    String token = model.token;
    await apiService.createOrder(_address, token).then((value) {
      if (value) {
        _isorderCreated = true;

        dbHelper.cartdelete();
        notifyListeners();
      }
    });
  }


  
  

  getuseraddress() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    List<UserAddressModel> timslot =
        await apiService.getuseraddress(model.id, model.token);

    if (timslot.length > 0) {
      _useraddress = [];
      _useraddress.addAll(timslot);
      bool result =
          await prefs.setString('useraddressdata', jsonEncode(_useraddress));
    }
    notifyListeners();
  }

  void addmoney() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });

    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String token = model.token;
    moblieNumber = model.mobileNumber;
    // email = model.emailId;
    addMoneyToWallet.userId = model.mobileNumber;
    addMoneyToWallet.transactionid = walletdetails.transactionid;

    addMoneyToWallet.transType = "Credit";
    await apiService.Addmoneyforwallet(walletdetails, token).then((value) {
      if (value == true) {
        _ispayment = true;
        double oldamt = prefs.getDouble("Walletamt");
        prefs.setDouble(
            "Walletamt", oldamt + double.parse(addMoneyToWallet.amount));
        prefs.getDouble("Walletamt");
        notifyListeners();
      }
    });
  }

  getwalletbalance() async {
    final allRows = await dbHelper.queryuserRows();
    allRows.forEach((row) => {
          model = UserdatafromDB(
            row["id"],
            row["name"],
            row["address1"],
            row["address2"],
            row["state"],
            row["city"],
            row["pinCode"],
            row["mobileNumber"],
            row["token"],
            row["walletamt"],
          ),
          list.add(model)
        });
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    await apiService
        .getwalletBal(model.mobileNumber, model.token)
        .then((value) => prefs.setDouble("Walletamt", value));
  }

  notifyListeners();
}
