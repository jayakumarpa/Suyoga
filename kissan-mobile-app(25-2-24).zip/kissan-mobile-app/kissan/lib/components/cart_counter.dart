import 'package:Kissan/pages/product_details.dart';
import 'package:Kissan/widgets/widget_product_details.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/product.dart';
import 'package:flutter/foundation.dart';
import 'package:Kissan/utils/dataBase.dart';

double total = 0.0;

class CartCounter extends StatefulWidget {
  CartCounter({Key key, this.data, this.numOfItems}) : super(key: key);
  Product data;
  int numOfItems = 0;
  @override
  _CartCounterState createState() => _CartCounterState();
}

class _CartCounterState extends State<CartCounter> {
  final dbHelper = DBProvider.instance;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(left: 20, right: 10),
          child: FlatButton(
            child: Text(
              'Add',
              style: TextStyle(fontSize: 15.0),
            ),
            color: Colors.red,
            textColor: Colors.white,
            onPressed: () {
              this.widget.numOfItems++;
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      ProductDetails(product: this.widget.data),
                ),
              );
              // Scaffold.of(context).showSnackBar(SnackBar(
              //   content: Text(
              //     this.widget.numOfItems.toString() +
              //         " " +
              //         "Item Total" +
              //         " " +
              //         "|"
              //             " " +
              //         total.toString(),
              //     style: TextStyle(
              //       color: Colors.white,
              //       fontSize: 16,
              //       fontWeight: FontWeight.bold,
              //     ),
              //   ),
              //   duration: Duration(seconds: 3),
              //   backgroundColor: Colors.green,
              // ));
            },
            shape: StadiumBorder(),
          ),
        )
      ],
    );
  }

  SizedBox buildOutlineButton({IconData icon, Function press}) {
    return SizedBox(
      width: 40,
      height: 32,
      child: OutlineButton(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        onPressed: press,
        child: Icon(icon),
      ),
    );
  }

  Widget _addTocart(cp, numOfItems) {
    dbHelper.productInsert(
        cp.productId,
        cp.productName,
        cp.productCode,
        cp.price,
        cp.price,
        cp.priceMinQuantity,
        cp.brandname,
        cp.priceId,
        cp.cityId,
        cp.quantity,
        numOfItems);
  }

  Widget _deleteCart() {
    Product deleteProd;
    deleteProd = this.widget.data;
    int id = deleteProd.productId;
    dbHelper.delete(id);
  }

  void calculatePrice() {
    _deleteCart();
    Product cp;
    cp = this.widget.data;

    int Quantity = this.widget.numOfItems;

    // double price = double.parse(this.widget.data.price);
    // total = Quantity * price;
    _addTocart(cp, this.widget.numOfItems);
  }

  void UpdateCart() {
    double updatedPrice = total;
    int pid = this.widget.data.productId;
    dbHelper.updateCart(updatedPrice, pid);
  }
  
  OutlineButton({EdgeInsets padding, RoundedRectangleBorder shape, Function onPressed, Icon child}) {}
}
