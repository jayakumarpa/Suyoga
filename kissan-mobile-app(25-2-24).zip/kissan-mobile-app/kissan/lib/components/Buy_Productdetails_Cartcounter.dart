import 'package:Kissan/pages/Buy_cartPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/product.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:shared_preferences/shared_preferences.dart';

double total = 0.0;

class BuyProductDetailsCart extends StatefulWidget {
  BuyProductDetailsCart({Key key, this.productdata, this.numOfItems})
      : super(key: key);
  Product productdata;

  int numOfItems = 0;
  @override
  BuyProductDetailsCartState createState() => BuyProductDetailsCartState();
}

class BuyProductDetailsCartState extends State<BuyProductDetailsCart> {
  final dbHelper = DBProvider.instance;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(left: 1),
          child: FlatButton(
            child: Text(
              'Add to cart',
              style: TextStyle(fontSize: 15.0),
            ),
            color: Colors.red,
            textColor: Colors.white,
            onPressed: () async {
              final coutnt = await dbHelper.getCount();
              final SharedPreferences prefs =
                  await SharedPreferences.getInstance();
              prefs.setInt("Count", coutnt);
              setState(() {
                this.widget.numOfItems++;
                calculatePrice();
                Scaffold.of(context).showSnackBar(SnackBar(
                  content: Text(
                    this.widget.numOfItems.toString() +
                        " " +
                        "Item Total" +
                        " " +
                        "|"
                            " " +
                        total.toString(),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  backgroundColor: Colors.green,
                ));
              });
            },
            shape: StadiumBorder(),
          ),
        ),
        Container(
          padding: EdgeInsets.only(left: 10),
          child: FlatButton(
            child: Text(
              'Buy now',
              style: TextStyle(fontSize: 15.0),
            ),
            color: Colors.red,
            textColor: Colors.white,
            onPressed: () {
              setState(() {
                this.widget.numOfItems++;
                calculatePrice();
                Scaffold.of(context).showSnackBar(SnackBar(
                  content: Text(
                    this.widget.numOfItems.toString() +
                        " " +
                        "Item Total" +
                        " " +
                        "|"
                            " " +
                        total.toString(),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  backgroundColor: Colors.green,
                ));
              });

              calculatePrice();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BuyCartPage(),
                ),
              );
            },
            shape: StadiumBorder(),
          ),
        )
      ],
    );
  }

  SizedBox buildOutlineButton({IconData icon, Function press}) {
    return SizedBox(
      width: 40,
      height: 32,
      child: OutlineButton(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        onPressed: press,
        child: Icon(icon),
      ),
    );
  }

  Widget _addTocart(cp, total, numOfItems) {
    double totalprice = total;
    dbHelper.buyproductInsert(
        cp.productId,
        cp.productName,
        cp.productCode,
        cp.price,
        totalprice,
        cp.priceMinQuantity,
        cp.brandname,
        cp.priceId,
        cp.cityId,
        numOfItems);

    // debugPrint(this.widget.productdata.price);
    // debugPrint(this.widget.productdata.productName);
    // debugPrint(this.widget.productdata.priceMinQuantity.toString());
    // debugPrint(this.widget.numOfItems.toString());
  }

  Widget _deleteCart() {
    Product deleteProd;
    deleteProd = this.widget.productdata;
    int id = deleteProd.productId;
    dbHelper.delete(id);
  }

  calculatePrice() {
    _deleteCart();
    Product cp;
    //int pid = cp.productId;
    cp = this.widget.productdata;

    int Quantity = this.widget.numOfItems;
    //data.price
    // double price = double.parse(cp.price);
    double price = double.parse(this.widget.productdata.price);
    total = Quantity * price;
    _addTocart(cp, total, this.widget.numOfItems);
    // print(total);
  }
  
  OutlineButton({EdgeInsets padding, RoundedRectangleBorder shape, Function onPressed, Icon child}) {}
}
