import 'package:flutter/material.dart';
import 'package:Kissan/model/product.dart';
import 'package:flutter/foundation.dart';
import 'package:Kissan/utils/dataBase.dart';

double total = 0.0;

class BuyCartCounter extends StatefulWidget {
  BuyCartCounter({Key key, this.data, this.numOfItems}) : super(key: key);
  Product data;
  int numOfItems = 0;
  @override
  _BuyCartCounterState createState() => _BuyCartCounterState();
}

class _BuyCartCounterState extends State<BuyCartCounter> {
  final dbHelper = DBProvider.instance;
  String textHolder = 'Add';
  changeText() {
    setState(() {
      textHolder = 'Added';
      this.widget.numOfItems++;
      calculatePrice();
      Scaffold.of(context).showSnackBar(SnackBar(
        content: Text(
          this.widget.numOfItems.toString() +
              " " +
              "Item Total" +
              " " +
              "|"
                  " " +
              total.toString(),
          style: TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        duration: Duration(seconds: 3),
        backgroundColor: Color.fromRGBO(123, 212, 165, 1),
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        if (textHolder == "Add")
          Container(
            padding: EdgeInsets.only(left: 20, right: 10),
            child: RaisedButton(
              onPressed: () => changeText(),
              child: Text(textHolder),
              textColor: Colors.white,
              color: Color.fromRGBO(255, 95, 167, 1),
              // color: Color.hex("4ad3f3"),
              padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
              shape: StadiumBorder(),
            ),

            // FlatButton(
            //   child: Text(
            //     'Add',
            //     style: TextStyle(fontSize: 15.0),
            //   ),
            //   color: Colors.red,
            //   textColor: Colors.white,
            //   onPressed: () {

            //   },
            //   shape: StadiumBorder(),
            // ),
          ),
        if (textHolder == "Added")
          Container(
            padding: EdgeInsets.only(left: 20, right: 10),
            child: RaisedButton(
              onPressed: () => changeText(),
              child: Text(textHolder),
              textColor: Colors.black,
              color: Color.fromRGBO(123, 212, 165, 1),
              padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
              shape: StadiumBorder(),
            ),

            // FlatButton(
            //   child: Text(
            //     'Add',
            //     style: TextStyle(fontSize: 15.0),
            //   ),
            //   color: Colors.red,
            //   textColor: Colors.white,
            //   onPressed: () {

            //   },
            //   shape: StadiumBorder(),
            // ),
          ),
      ],
    );
  }

  SizedBox buildOutlineButton({IconData icon, Function press}) {
    return SizedBox(
      width: 40,
      height: 32,
      child: OutlineButton(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        onPressed: press,
        child: Icon(icon),
      ),
    );
  }

  Widget _addTocart(cp, total, numOfItems) {
    double totalprice = total;
    dbHelper.buyproductInsert(
        cp.productId,
        cp.productName,
        cp.productCode,
        cp.price,
        totalprice,
        cp.priceMinQuantity,
        cp.brandname,
        cp.priceId,
        cp.cityId,
        numOfItems);
  }

  Widget _deleteCart() {
    Product deleteProd;
    deleteProd = this.widget.data;
    int id = deleteProd.productId;
    dbHelper.delete(id);
  }

  void calculatePrice() {
    _deleteCart();
    Product cp;
    cp = this.widget.data;

    int Quantity = this.widget.numOfItems;

    double price = double.parse(this.widget.data.price);
    total = Quantity * price;
    _addTocart(cp, total, this.widget.numOfItems);
  }

  void UpdateCart() {
    double updatedPrice = total;
    int pid = this.widget.data.productId;
    dbHelper.updateCart(updatedPrice, pid);
  }
  
  OutlineButton({EdgeInsets padding, RoundedRectangleBorder shape, Function onPressed, Icon child}) {}
}
