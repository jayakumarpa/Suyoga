import 'package:flutter/material.dart';
import 'package:Kissan/model/ProductLocal.dart';
import 'package:Kissan/utils/constants.dart';
import 'package:Kissan/utils/dataBase.dart';

class PlaceOder extends StatefulWidget {
  PlaceOder({Key key, this.data, this.numOfItems}) : super(key: key);
  ProductLocal data;
  int numOfItems = 0;
  double total = 0.0;
  @override
  _PlaceOderState createState() => _PlaceOderState();
}

class _PlaceOderState extends State<PlaceOder> {
  final dbHelper = DBProvider.instance;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        buildOutlineButton(
          icon: Icons.remove,
          press: () {
            if (this.widget.numOfItems > 0) {
              setState(() {
                this.widget.numOfItems--;
                calculatePrice();
              });
            } else if (this.widget.numOfItems == 0) {
              _deleteCart();
            }
          },
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: kDefaultPaddin / 2),
          child: Text(
            // if our item is less  then 10 then  it shows 01 02 like that
            this.widget.numOfItems.toString().padLeft(1, "0"),
            style: Theme.of(context).textTheme.headline6,
          ),
        ),
        buildOutlineButton(
            icon: Icons.add,
            press: () {
              setState(() {
                this.widget.numOfItems++;
                calculatePrice();
              });
            }),
      ],
    );
  }

  SizedBox buildOutlineButton({IconData icon, Function press}) {
    return SizedBox(
      width: 35.5,
      height: 30,
      child: OutlineButton(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        onPressed: press,
        child: Icon(icon),
      ),
    );
  }

  Widget _addTocart(cp, numOfItems) {
    dbHelper.productInsert(
        cp.productId,
        cp.productName,
        cp.productCode,
        cp.price,
        cp.price,
        cp.priceMinQuantity,
        cp.brandname,
        cp.priceId,
        cp.cityId,
        cp.quantity,
        numOfItems);
  }

  Widget _deleteCart() {
    ProductLocal deleteProd;
    deleteProd = this.widget.data;
    int id = deleteProd.productId;
    dbHelper.delete(id);
  }

  void calculatePrice() {
    _deleteCart();
    ProductLocal cp;
    cp = this.widget.data;

    int Quantity = this.widget.numOfItems;

    //  double price = double.parse(this.widget.data.price);
    // this.widget.total = Quantity * price;
    _addTocart(cp, this.widget.numOfItems);
  }

  void UpdateCart() {
    double updatedPrice = this.widget.total;
    int pid = this.widget.data.productId;
    dbHelper.updateCart(updatedPrice, pid);
  }
  
  OutlineButton({EdgeInsets padding, RoundedRectangleBorder shape, Function onPressed, Icon child}) {}
}
