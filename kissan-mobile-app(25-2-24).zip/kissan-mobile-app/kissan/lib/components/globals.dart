library my_prj.globals;

bool isLoggedIn = false;
int globalCounter = 0;
String username = "user";
String status = "P";
String role = "";

double placeorderTotal = 0.0;
double walletTotal = 0.0;
