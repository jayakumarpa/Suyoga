import 'package:Kissan/utils/form_helper.dart';
import 'package:Kissan/widgets/widget_cart_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:Kissan/model/product.dart';
import 'package:Kissan/utils/dataBase.dart';
import 'package:shared_preferences/shared_preferences.dart';

double total = 0.0;

class ProductDetailsCart extends StatefulWidget {
  ProductDetailsCart({Key key, this.productdata, this.numOfItems})
      : super(key: key);
  Product productdata;

  int numOfItems = 0;
  @override
  ProductDetailsCartState createState() => ProductDetailsCartState();
}

class ProductDetailsCartState extends State<ProductDetailsCart> {
  final dbHelper = DBProvider.instance;
  String _selectedLocation;
  String dropdownValue;
  @override
  Widget build(BuildContext context) {
    return Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: EdgeInsets.symmetric(horizontal: 70, vertical: 5),
            decoration: BoxDecoration(
                color: Colors.green, borderRadius: BorderRadius.circular(10)),

            // dropdown below..
            child: DropdownButton<String>(
                hint: Text(
                  'Select Quantity',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
                value: dropdownValue,
                icon: Icon(
                  Icons.arrow_drop_down,
                  color: Colors.red,
                ),
                iconSize: 42,
                underline: SizedBox(),
                onChanged: (String newValue) {
                  setState(() {
                    dropdownValue = newValue;
                  });
                },
                items: <String>[
                  '20 Kg',
                  '50 Kg',
                  '100 Kg',
                ].map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    ),
                  );
                }).toList()),
          ),
          // DropdownButton(
          //   autofocus: true,
          //   itemHeight: 50,
          //   hint: Text(
          //     'select Quantity',
          //     style: TextStyle(
          //         color: Colors.red, fontSize: 20, fontWeight: FontWeight.bold),
          //   ), // Not necessary for Option 1
          //   value: _selectedLocation,
          //   onChanged: (newValue) {
          //     setState(() {
          //       _selectedLocation = newValue;
          //     });
          //   },
          //   items: _locations.map((location) {
          //     return DropdownMenuItem(
          //       child: new Text(
          //         location,
          //         style: TextStyle(
          //             color: Colors.black,
          //             fontSize: 20,
          //             fontWeight: FontWeight.bold),
          //       ),
          //       value: location,
          //     );
          //   }).toList(),
          // ),
          SizedBox(
            height: 100,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 100),
            child: FlatButton(
              height: 60,
              minWidth: 50,
              child: Text(
                'Add To Cart',
                style: TextStyle(fontSize: 25.0),
              ),
              color: Colors.red,
              textColor: Colors.white,
              onPressed: () {
                if (dropdownValue != null) {
                  setState(() {
                    this.widget.numOfItems++;
                    calculatePrice();
                  });
                  calculatePrice();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CartPageIconPress(),
                    ),
                  );
                } else {
                  FormHelper.showMessage(
                      context, "SUYOGA", "Please add Product Quantity", "OK",
                      () {
                    Navigator.of(context).pop();
                  });
                }
              },
              shape: StadiumBorder(),
            ),
          ),
        ]);
  }

  SizedBox buildOutlineButton({IconData icon, Function press}) {
    return SizedBox(
      width: 40,
      height: 32,
      child: OutlineButton(
        padding: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(13),
        ),
        onPressed: press,
        child: Icon(icon),
      ),
    );
  }

  Widget _addTocart(cp, numOfItems) {
    dbHelper.productInsert(
        cp.productId,
        cp.productName,
        cp.productCode,
        cp.price,
        cp.marketPrice,
        cp.priceMinQuantity,
        cp.brandname,
        cp.priceId,
        cp.cityId,
        cp.quantity,
        numOfItems);

    // debugPrint(this.widget.productdata.price);
    // debugPrint(this.widget.productdata.productName);
    // debugPrint(this.widget.productdata.priceMinQuantity.toString());
    // debugPrint(this.widget.numOfItems.toString());
  }

  Widget _deleteCart() {
    Product deleteProd;
    deleteProd = this.widget.productdata;
    int id = deleteProd.productId;
    dbHelper.delete(id);
  }

  calculatePrice() {
    _deleteCart();
    Product cp;
    int quantitykg;
    //int pid = cp.productId;
    if (dropdownValue != null) {
      quantitykg =
          int.tryParse(dropdownValue.replaceAll(RegExp(r'[^0-9]'), '')) ?? 5;
      print(quantitykg);
    }
    cp = this.widget.productdata;
    cp.quantity = dropdownValue;
    cp.totalvalue = double.parse(this.widget.productdata.price) / 5;

    double myInteger = (quantitykg.toDouble() * cp.totalvalue);
    cp.marketPrice = myInteger.toString();
    print('>>>>>>>>>>' + '$myInteger');
    int Quantity = this.widget.numOfItems;
    //data.price
    // double price = double.parse(cp.price);
    /// double price = double.parse(this.widget.productdata.price);
    // total = Quantity * price;
    _addTocart(cp, this.widget.numOfItems);
    // print(total);
  }
  
  OutlineButton({EdgeInsets padding, RoundedRectangleBorder shape, Function onPressed, Icon child}) {}
}
