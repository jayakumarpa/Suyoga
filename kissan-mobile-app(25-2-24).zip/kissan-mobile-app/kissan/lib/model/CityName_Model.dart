class CityNameModel {
  CityNameModel({
    this.cityName,
  });

  String cityName;

  factory CityNameModel.fromJson(Map<String, dynamic> json) => CityNameModel(
        cityName: json["cityName"],
      );

  Map<String, dynamic> toJson() => {
        "cityName": cityName,
      };
}
