class AddMoneyToWallet {
  AddMoneyToWallet({
    this.userId,
    this.amount,
    this.transactionid,
    this.transType,
  });

  String userId;
  String amount;
  String transactionid;
  String transType;

  factory AddMoneyToWallet.fromJson(Map<String, dynamic> json) =>
      AddMoneyToWallet(
        userId: json["userId"],
        amount: json["amount"],
        transactionid: json["transactionid"],
        transType: json["transType"],
      );

  Map<String, dynamic> toJson() => {
        "userId": userId,
        "amount": amount,
        "transactionid": transactionid,
        "transType": transType,
      };
}
