class UserFeedback {
  UserFeedback({
    this.issueType,
    this.orderId,
    this.userComments,
    this.userMobNumber,
  });

  String issueType;
  String orderId;
  String userComments;
  String userMobNumber;

  factory UserFeedback.fromJson(Map<String, dynamic> json) => UserFeedback(
        issueType: json["issueType"],
        orderId: json["orderId"],
        userComments: json["userComments"],
        userMobNumber: json["userMobNumber"],
      );

  Map<String, dynamic> toJson() => {
        "issueType": issueType,
        "orderId": orderId,
        "userComments": userComments,
        "userMobNumber": userMobNumber,
      };
}
