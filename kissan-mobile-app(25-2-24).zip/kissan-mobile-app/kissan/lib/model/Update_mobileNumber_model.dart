class UpdateMoblie {
  UpdateMoblie({
    this.oldMobileNumber,
    this.newMobileNumber,
    this.accessCode,
  });

  String oldMobileNumber;
  String newMobileNumber;
  String accessCode;

  factory UpdateMoblie.fromJson(Map<String, dynamic> json) => UpdateMoblie(
        oldMobileNumber: json["oldMobileNumber"],
        newMobileNumber: json["newMobileNumber"],
        accessCode: json["accessCode"],
      );

  Map<String, dynamic> toJson() => {
        "oldMobileNumber": oldMobileNumber,
        "newMobileNumber": newMobileNumber,
        "accessCode": accessCode,
      };
}
