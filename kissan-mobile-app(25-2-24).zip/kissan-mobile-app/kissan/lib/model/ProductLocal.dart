class ProductLocal {
  int productId;
  String productCode;
  String productName;
  String price;
  double totalPrice;
  int priceMinQuantity;
  String brandname;
  int priceId;
  int cityId;
  String quantity;
  int numOfItems;

  ProductLocal(
    this.productId,
    this.productCode,
    this.productName,
    this.price,
    this.totalPrice,
    this.priceMinQuantity,
    this.brandname,
    this.priceId,
    this.cityId,
    this.quantity,
    this.numOfItems,
  );

  ProductLocal.fromJson(Map<String, dynamic> json) {
    productId = json['productId'];
    productCode = json['productCode'];
    productName = json['productName'];
    priceMinQuantity = json['priceMinQuantity'];
    totalPrice = json['totalPrice'];
    price = json["price"];
    brandname = json['brandname'];
    priceId = json['priceId'];
    cityId = json['cityId'];
    quantity = json['quantity'];

    numOfItems = json['numOfItems'];
  }
  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'productCode': productCode,
      'productName': productName,
      'price': price,
      'totalPrice': totalPrice,
      'priceMinQuantity': priceMinQuantity,
      'brandname': brandname,
      'priceId': priceId,
      'cityId': cityId,
      'quantity': quantity,
      'numOfItems': numOfItems,
    };
  }

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'productCode': productCode,
        'productName': productName,
        'price': price,
        'totalPrice': totalPrice,
        'priceMinQuantity': priceMinQuantity,
        'brandname': brandname,
        'priceId': priceId,
        'cityId': cityId,
        'quantity': quantity,
        'numOfItems': numOfItems,
      };
}

class BuyProductLocal {
  int productId;
  String productCode;
  String productName;
  String price;

  int priceMinQuantity;
  String brandname;
  int priceId;
  int cityId;
  String quantity;
  int numOfItems;
  double totalPrice;

  BuyProductLocal(
    this.productId,
    this.productCode,
    this.productName,
    this.price,
    this.priceMinQuantity,
    this.brandname,
    this.priceId,
    this.cityId,
    this.quantity,
    this.numOfItems,
    this.totalPrice,
  );

  BuyProductLocal.fromJson(Map<String, dynamic> json) {
    productId = json['productId'];
    productCode = json['productCode'];
    productName = json['productName'];
    price = json['price'].toString();

    priceMinQuantity = json['priceMinQuantity'];
    brandname = json['brandname'];
    priceId = json['priceId'];
    cityId = json['cityId'];
    quantity = json['quantity'];

    numOfItems = json['numOfItems'];
    totalPrice = json['totalPrice'];
  }
  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'productCode': productCode,
      'productName': productName,
      'price': price,
      'priceMinQuantity': priceMinQuantity,
      'brandname': brandname,
      'priceId': priceId,
      'cityId': cityId,
      'quantity': quantity,
      'numOfItems': numOfItems,
      'totalprice': totalPrice,
    };
  }

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'productCode': productCode,
        'productName': productName,
        'price': price,
        'priceMinQuantity': priceMinQuantity,
        'brandname': brandname,
        'priceId': priceId,
        'cityId': cityId,
        'quantity': quantity,
        'numOfItems': numOfItems,
        'totalprice': totalPrice,
      };
}
