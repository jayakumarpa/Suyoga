class OfferProduct {
  int productId;
  String productCode;
  String productName;
  String price;
  int priceMinQuantity;
  String brandname;
  int priceId;
  int cityId;
  String productDescription;
  OfferProduct(
    this.productId,
    this.productCode,
    this.productName,
    this.price,
    this.priceMinQuantity,
    this.brandname,
    this.priceId,
    this.cityId,
    this.productDescription,
  );

  OfferProduct.fromJson(Map<String, dynamic> json) {
    productId = json['productId'];
    productCode = json['productCode'];
    productName = json['productName'];
    price = json['price'].toString();
    priceMinQuantity = json['priceMinQuantity'];
    brandname = json['brandname'];
    priceId = json['priceId'];
    cityId = json['cityId'];
    productDescription = json['productDescription'];
  }
}
