class Timeslot {
  Timeslot({
    this.dateDay,
    this.time,
  });

  String dateDay;
  List<Time> time;

  factory Timeslot.fromJson(Map<String, dynamic> json) => Timeslot(
        dateDay: json["dateDay"],
        time: List<Time>.from(json["time"].map((x) => Time.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "dateDay": dateDay,
        "time": List<dynamic>.from(time.map((x) => x.toJson())),
      };
}

class Time {
  Time({
    this.morningTime,
    this.eveningTime,
  });

  String morningTime;
  String eveningTime;

  factory Time.fromJson(Map<String, dynamic> json) => Time(
        morningTime: json["morningTime"],
        eveningTime: json["eveningTime"],
      );

  Map<String, dynamic> toJson() => {
        "morningTime": morningTime,
        "eveningTime": eveningTime,
      };
}
