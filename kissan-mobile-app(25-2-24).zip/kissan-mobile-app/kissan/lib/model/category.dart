import 'package:flutter/material.dart';

class Category {
  int categoryId;
  String categoryName;
  String categoryDescription;
  int subId;
  String image;
  String categoryCode;

  Category(
    this.categoryId,
    this.categoryName,
    this.categoryDescription,
    this.subId,
    this.image,
    this.categoryCode,
  );
  Category.fromJson(Map<String, dynamic> json) {
    categoryId = json['id'];
    categoryName = json['categoryName'];
    categoryDescription = json['categoryDescription'];
    subId = json['subId'];
    image = json['image'];
    categoryCode = json['categoryCode'];
  }
}
