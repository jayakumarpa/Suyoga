class WalletBalancemodel {
  WalletBalancemodel({
    this.walletBalance,
  });

  double walletBalance;

  factory WalletBalancemodel.fromJson(Map<String, dynamic> json) =>
      WalletBalancemodel(
        walletBalance: json["walletBalance"],
      );

  Map<String, dynamic> toJson() => {
        "walletBalance": walletBalance,
      };
}
