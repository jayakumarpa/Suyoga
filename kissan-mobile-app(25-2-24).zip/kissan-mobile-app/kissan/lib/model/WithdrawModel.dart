class WithdrawRequest {
  WithdrawRequest({
    this.userId,
    this.contRefId,
    this.bankRefId,
    this.rzpTransacid,
    this.status,
    this.amount,
  });

  String userId;
  String contRefId;
  String bankRefId;
  String rzpTransacid;
  String status;
  double amount;

  factory WithdrawRequest.fromJson(Map<String, dynamic> json) =>
      WithdrawRequest(
        userId: json["userId"],
        contRefId: json["contRefId"],
        bankRefId: json["bankRefId"],
        rzpTransacid: json["rzpTransacid"],
        status: json["status"],
        amount: json["amount"],
      );

  Map<String, dynamic> toJson() => {
        "userId": userId,
        "contRefId": contRefId,
        "bankRefId": bankRefId,
        "rzpTransacid": rzpTransacid,
        "status": status,
        "amount": amount,
      };
}
