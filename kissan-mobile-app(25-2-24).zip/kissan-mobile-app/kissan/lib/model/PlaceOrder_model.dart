import 'package:Kissan/model/customer_detail_model.dart';

class CreateOrder {
  String customerId;
  String paymentMethod;
  String paymentMethodTitle;
  bool setPaid;
  String transactionId;
  String timeSlot;
  List<ProductList> productList;
  double totalAmount;
  String status;
  Shipping shipping;
  double walletamt;
  String typeofOrder;
  String latitude;
  String longitude;

  CreateOrder({
    this.customerId,
    this.paymentMethod,
    this.paymentMethodTitle,
    this.setPaid,
    this.transactionId,
    this.productList,
    this.status,
    this.shipping,
    this.totalAmount,
    this.timeSlot,
    this.walletamt,
    this.typeofOrder,
    this.latitude,
    this.longitude,
  });

  CreateOrder.fromJson(Map<String, dynamic> json) {
    customerId = json["customerId"];
    status = json["status"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data["customerId"] = customerId;
    data["paymentMethod"] = paymentMethod;
    data["paymentMethodTitle"] = paymentMethodTitle;
    data["setPaid"] = setPaid;
    data["timeSlot"] = timeSlot;
    data["transactionId"] = transactionId;
    data["shipping"] = shipping.toJson();
    data["totalAmount"] = totalAmount;
    data["walletamt"] = walletamt;
    data["typeofOrder"] = typeofOrder;
    data["latitude"] = latitude;
    data["longitude"] = longitude;

    if (productList != null) {
      data["productList"] = productList.map((e) => e.toJson()).toList();
    }

    return data;
  }
}

class ProductList {
  ProductList({
    this.productId,
    this.productCode,
    this.productName,
    this.priceId,
    this.price,
    this.priceMinQuantity,
    this.cityId,
    this.brandname,
    this.numOfItems,
    this.totalPrice,
  });

  int productId;
  String productCode;
  String productName;
  String price;
  String priceMinQuantity;
  String brandname;
  int priceId;
  int cityId;
  int numOfItems;
  double totalPrice;

  ProductList.fromJson(Map<String, dynamic> json) {
    productId = json['productId'];
    productCode = json['productCode'];
    productName = json['productName'];
    price = json['price'].toString();

    priceMinQuantity = json['priceMinQuantity'];
    brandname = json['brandname'];
    priceId = json['priceId'];
    cityId = json['cityId'];
    numOfItems = json['numOfItems'];
    totalPrice = json['totalPrice'];
  }

  Map<String, dynamic> toJson() {
    return {
      'productId': productId,
      'productCode': productCode,
      'productName': productName,
      'price': price,
      'priceMinQuantity': priceMinQuantity,
      'brandname': brandname,
      'priceId': priceId,
      'cityId': cityId,
      'numOfItems': numOfItems,
      'totalprice': totalPrice,
    };
  }
}
