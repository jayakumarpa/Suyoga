class CustomerDetails {
  int id;
  String firstName;
  String lastName;
  Billing billing;
  Shipping shipping;
  CustomerDetails(
      {this.id, this.firstName, this.lastName, this.billing, this.shipping});
  CustomerDetails.fromjson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    billing =
        json['billing'] != null ? new Billing.fromjson(json['billing']) : null;
    shipping = json['shipping'] != null
        ? new Shipping.fromjson(json['shipping'])
        : null;
  }
}

class Billing {
  String firstName;
  String lastName;
  String address1;
  String address2;
  String city;
  String postalCode;
  String country;
  String state;
  String email;
  String phone;
  Billing(
      {this.firstName,
      this.lastName,
      this.address1,
      this.address2,
      this.city,
      this.postalCode,
      this.country,
      this.state,
      this.email,
      this.phone});
  Billing.fromjson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    address1 = json['address1'];
    address2 = json['address2'];
    city = json['city'];
    postalCode = json['postalCode'];
    country = json['country'];
    state = json['state'];
    email = json['email'];
    phone = json['phone'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['address1'] = this.address1;
    data['address2'] = this.address2;
    data['city'] = this.city;
    data['postalCode'] = this.postalCode;
    data['country'] = this.country;
    data['state'] = this.state;
    data['email'] = this.email;
    data['phone'] = this.phone;
    return data;
  }
}

class Shipping {
  String firstName;
  String lastName;
  String address1;
  String address2;
  String city;
  String postalCode;
  String country;
  String state;
  String mobile;
  String email;
  Shipping(
      {this.firstName,
      this.lastName,
      this.address1,
      this.address2,
      this.city,
      this.country,
      this.postalCode,
      this.mobile,
      this.email,
      this.state});
  Shipping.fromjson(Map<String, dynamic> json) {
    firstName = json['firstName'];
    lastName = json['lastName'];
    address1 = json['address1'];
    address2 = json['address2'];
    city = json['city'];
    postalCode = json['postalCode'];
    country = json['country'];
    state = json['state'];
    mobile = json["mobile"];
    email = json["email"];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['address1'] = this.address1;
    data['address2'] = this.address2;
    data['city'] = this.city;
    data['postalCode'] = this.postalCode;
    data['country'] = this.country;
    data['state'] = this.state;
    data['mobile'] = this.mobile;
    data['email'] = this.email;
    return data;
  }
}
