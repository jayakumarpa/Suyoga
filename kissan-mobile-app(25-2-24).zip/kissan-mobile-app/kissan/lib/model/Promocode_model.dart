class PromocodeModel {
  PromocodeModel({
    this.userName,
    this.promoCode,
    this.totalAmount,
    this.statusCode,
    this.discountAmount,
    this.message,
  });

  String userName;
  String promoCode;
  double totalAmount;
  int statusCode;
  String message;
  double discountAmount;

  factory PromocodeModel.fromJson(Map<String, dynamic> json) => PromocodeModel(
        statusCode: json["statusCode"],
        discountAmount: double.parse(json["discountAmount"]),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "userName": userName,
        "promoCode": promoCode,
        "totalAmount": totalAmount,
      };
}
